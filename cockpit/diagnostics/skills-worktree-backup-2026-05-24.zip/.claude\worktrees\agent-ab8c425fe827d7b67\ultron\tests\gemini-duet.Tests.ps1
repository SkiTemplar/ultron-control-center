# ULTRON v9.0 - Pester unit tests for gemini-duet.ps1 helper
# Tests validation logic WITHOUT invoking Gemini (fast, deterministic, free).
#
# Run: Invoke-Pester C:\Users\Rodrigo\.claude\skills\ultron\tests\gemini-duet.Tests.ps1
#
# Pester 3.x compatible (Windows PowerShell 5.1 default).
# Mirror funcional de codex-duet.Tests.ps1 — same pattern, Gemini-specific assertions.
# Net cost: ~0 tokens, ~0.5s per full suite.

$helper = Join-Path $PSScriptRoot "..\scripts\gemini-duet.ps1"
$helper = (Resolve-Path $helper).Path

Describe "gemini-duet helper - parameter validation" {

    It "exists and is parseable PowerShell" {
        Test-Path $helper | Should Be $true
        $null = [scriptblock]::Create((Get-Content -Raw $helper))
    }

    It "rejects invalid Mode parameter" {
        { & $helper -Mode "InvalidMode" -Round 1 -Prompt "test" -ErrorAction Stop } | Should Throw
    }

    It "rejects MiniTriple with Round != 1" {
        $err = $null
        try { & $helper -Mode Mini -Round 2 -Prompt "test" 2>&1 | Out-Null } catch { $err = $_ }
        ($err -ne $null -or $LASTEXITCODE -ne 0) | Should Be $true
    }

    It "rejects Round > 1 without SessionId" {
        $err = $null
        try { & $helper -Mode Triple -Round 2 -Prompt "test" 2>&1 | Out-Null } catch { $err = $_ }
        ($err -ne $null -or $LASTEXITCODE -ne 0) | Should Be $true
    }

    It "rejects when neither -PromptFile nor -Prompt provided" {
        $err = $null
        try { & $helper -Mode Mini -Round 1 2>&1 | Out-Null } catch { $err = $_ }
        ($err -ne $null -or $LASTEXITCODE -ne 0) | Should Be $true
    }

    It "rejects non-existent PromptFile" {
        $bogus = Join-Path $env:TEMP "ultron-test-nonexistent-$(Get-Random).txt"
        $err = $null
        try { & $helper -Mode Mini -Round 1 -PromptFile $bogus 2>&1 | Out-Null } catch { $err = $_ }
        ($err -ne $null -or $LASTEXITCODE -ne 0) | Should Be $true
    }

    It "rejects invalid Model alias (only auto/pro/flash/flash-lite allowed)" {
        { & $helper -Mode Mini -Round 1 -Prompt "x" -Model "gpt-5.5" -ErrorAction Stop } | Should Throw
    }
}

Describe "gemini-duet helper - file dependencies" {

    It "Gemini schema file exists and is valid JSON" {
        $schema = Join-Path $PSScriptRoot "..\references\gemini-duet-schema.json"
        Test-Path $schema | Should Be $true
        { Get-Content -Raw $schema | ConvertFrom-Json } | Should Not Throw
    }

    It "Gemini schema declares required Triple Mode response fields" {
        $schema = Join-Path $PSScriptRoot "..\references\gemini-duet-schema.json"
        $parsed = Get-Content -Raw $schema | ConvertFrom-Json
        $parsed.required -contains "round_type" | Should Be $true
        $parsed.required -contains "verdict" | Should Be $true
        $parsed.required -contains "critique" | Should Be $true
        $parsed.required -contains "suggestions" | Should Be $true
        $parsed.required -contains "long_context_signal" | Should Be $true
        $parsed.required -contains "scope_breadth" | Should Be $true
    }

    It "triple-debate-schema.json exists for synthesis" {
        $schema = Join-Path $PSScriptRoot "..\references\triple-debate-schema.json"
        Test-Path $schema | Should Be $true
        { Get-Content -Raw $schema | ConvertFrom-Json } | Should Not Throw
    }

    It "triple-debate-schema requires divergence and synthesized_decision" {
        $schema = Join-Path $PSScriptRoot "..\references\triple-debate-schema.json"
        $parsed = Get-Content -Raw $schema | ConvertFrom-Json
        $parsed.required -contains "divergence" | Should Be $true
        $parsed.required -contains "synthesized_decision" | Should Be $true
        $parsed.required -contains "tokens_used" | Should Be $true
    }

    It "gemini binary is locatable in PATH (helper depends on it)" {
        $cmd = Get-Command gemini -ErrorAction SilentlyContinue
        $cmd | Should Not BeNullOrEmpty
    }
}

Describe "gemini-duet helper - script structure" {

    $content = Get-Content -Raw $helper

    It "uses Start-Process backend (consistent with Codex helper)" {
        $content -match 'Start-Process' | Should Be $true
    }

    It "passes --approval-mode plan for read-only equivalent" {
        $content -match "'--approval-mode'" | Should Be $true
        $content -match "'plan'" | Should Be $true
    }

    It "enforces read-only via --approval-mode plan (no separate -s sandbox needed)" {
        # v10.5: Gemini CLI's --approval-mode plan IS the read-only mode for the
        # node.exe + gemini.js direct-invocation pattern (v10.4 fix). The -s
        # sandbox flag from old wrapper-based invocation is no longer required.
        $content -match "'--approval-mode'" | Should Be $true
        $content -match "'plan'" | Should Be $true
    }

    It "uses --skip-trust to avoid Windows folder-trust hang (gotcha #8)" {
        $content -match "'--skip-trust'" | Should Be $true
    }

    It "writes SESSION_ID to file (not just Write-Host)" {
        $content -match "last-session-id\.txt" | Should Be $true
    }

    It "filters stdout pollution (Skill override line, gotcha #1)" {
        $content -match "'\^\\\\s\*\\\\\{'" -or $content -match 'jsonStart' | Should Be $true
    }

    It "enforces hard caps via Test-TripleCaps function (mirroring Codex pattern)" {
        $content -match 'function Test-TripleCaps' | Should Be $true
        $content -match 'triple-caps\.json' | Should Be $true
    }

    It "exposes BypassCaps switch for explicit Rodrigo override" {
        $content -match '\[switch\]\$BypassCaps' | Should Be $true
    }

    It "Mini cap is unlimited, Triple=3, Max=1" {
        $content -match "Triple = 3; Max = 1" | Should Be $true
    }

    It "resolves Gemini via node.exe + gemini.js bundle (v10.4 fix)" {
        # v10.4 changed from `Get-Command gemini` (which returned the .cmd wrapper
        # that Start-Process can't launch) to invoking node.exe with the gemini.js
        # bundle path directly. This avoids the "%1 no es una aplicación Win32" error.
        $content -match 'gemini-cli[\\/]bundle[\\/]gemini\.js' | Should Be $true
        $content -match '\$nodeExe' | Should Be $true
    }

    It "extracts response field from Gemini JSON output" {
        $content -match '\$parsed\.response' | Should Be $true
    }

    It "captures session_id from parsed JSON (not stderr like Codex)" {
        $content -match '\$parsed\.session_id' | Should Be $true
    }

    It "strips markdown code fences from response (Gemini sometimes wraps JSON)" {
        $content -match '```' | Should Be $true
    }
}
