# Terry Davis — Python

## Usos principales de Rodrigo
- Scripts de automatización y utilidades
- Data science / análisis con pandas, numpy, matplotlib
- Proyectos de carrera (algoritmos, simulaciones)
- IA/ML (si aplica)

---

## COMANDOS

```bash
# Entorno virtual (siempre usar venv)
python -m venv .venv
.venv\Scripts\activate          # Windows
source .venv/bin/activate       # Unix

# Instalar (con --break-system-packages en sandbox)
pip install -r requirements.txt
pip install pandas numpy matplotlib

# Testing
python -m pytest
python -m pytest -v             # verbose
python -m pytest tests/test_x.py::test_func  # test específico

# Type checking
mypy src/                       # si hay type hints
python -m py_compile script.py  # check de sintaxis rápido
```

---

## PATRONES DE BUG

```python
# ❌ Default mutable argument — estado compartido entre calls
def add_item(item, lst=[]):
    lst.append(item)
    return lst
add_item(1)  # [1]
add_item(2)  # [1, 2] — inesperado!
# ✓
def add_item(item, lst=None):
    if lst is None: lst = []
    lst.append(item)
    return lst

# ❌ Import relativo sin __init__.py en el paquete
# ❌ Path relativo — falla según desde dónde se ejecuta
open('data/file.csv')  # rompe si no estás en el dir del script
# ✓
from pathlib import Path
BASE = Path(__file__).parent
open(BASE / 'data' / 'file.csv')

# ❌ File sin context manager — no se cierra en excepción
f = open('file.txt')
data = f.read()
# ✓
with open('file.txt', 'r', encoding='utf-8') as f:
    data = f.read()

# ❌ Bare except — oculta todos los errores incluyendo KeyboardInterrupt
try:
    risky_op()
except:    # demasiado amplio
    pass
# ✓
except (ValueError, TypeError) as e:
    logger.error(f"Expected error: {e}")
```

---

## PANDAS — OPERACIONES FRECUENTES

```python
import pandas as pd

df = pd.read_csv('data.csv', encoding='utf-8')

# Inspección
df.head(), df.info(), df.describe()
df.isnull().sum()           # nulls por columna
df.dtypes                   # tipos de datos

# Filtrado
df[df['col'] > 100]
df.query('col > 100 and otro == "valor"')
df.loc[condición, ['col1', 'col2']]

# Agrupación
df.groupby('categoria')['valor'].agg(['mean', 'sum', 'count'])

# Merge
pd.merge(df1, df2, on='id', how='left')

# Guardar
df.to_csv('output.csv', index=False)
df.to_excel('output.xlsx', index=False)
```

---

## ASYNC PYTHON

```python
import asyncio

# ❌ Mezclar sync y async sin bridge
async def fetch_data():
    return requests.get(url)   # requests es síncrono — bloquea el event loop
# ✓ usar httpx o aiohttp
import httpx
async def fetch_data():
    async with httpx.AsyncClient() as client:
        return await client.get(url)

# Ejecutar múltiples tareas en paralelo
results = await asyncio.gather(fetch_a(), fetch_b(), fetch_c())
```

---

## DOCS PYTHON

```
WebFetch: https://docs.python.org/3/library/[módulo].html
WebSearch: "[lib] [función] site:docs.[lib].org"
WebFetch: https://pandas.pydata.org/docs/reference/api/pandas.[función].html
```
