# ULTRON v10.0 Cockpit - Auth Vault (Windows DPAPI native)
#
# Encrypts MCP service profiles using Windows DPAPI scoped to CurrentUser.
# A "profile" = JSON snapshot of the mcpServers.<service> block in settings.json
# (or any other config blob). Switch profile = atomic swap of that block, with backup.
#
# Architecture: Claude-as-proxy
#   - Codex/Gemini NEVER receive tokens. They receive sanitized data passed in prompts.
#   - This vault is for SWITCHING identities in Claude's own MCP servers,
#     not for distributing credentials to peers.
#
# Run examples:
#   powershell -File auth-vault.ps1 -Action List
#   powershell -File auth-vault.ps1 -Action Add -Service gmail -ProfileName personal -ConfigPath gmail-personal.json
#   powershell -File auth-vault.ps1 -Action Get -Service gmail -ProfileName personal
#   powershell -File auth-vault.ps1 -Action Switch -Service gmail -ProfileName freelance
#   powershell -File auth-vault.ps1 -Action Remove -Service gmail -ProfileName old
#
# Vault file: ~/.ultron/cockpit/auth-vault.dpapi (JSON with base64-encoded DPAPI blobs)
# Backups: ~/.ultron/cockpit/auth-vault.dpapi.bak  (before write)
#          ~/.claude/settings.json.<timestamp>.bak (before Switch)

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateSet("Add","Get","List","Switch","Remove","Status")]
    [string]$Action,

    [string]$Service,
    [string]$ProfileName,
    [string]$ConfigPath,        # for Add: path to JSON file with the config blob
    [string]$Label,             # optional friendly label (e.g. email address)
    [switch]$Force              # skip confirmations on Switch/Remove
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Security

# -- Constants ----------------------------------------------------------------
$VaultPath    = Join-Path $env:USERPROFILE ".ultron\cockpit\auth-vault.dpapi"
$VaultBackup  = "$VaultPath.bak"
$SettingsPath = Join-Path $env:USERPROFILE ".claude\settings.json"

# -- DPAPI helpers (CurrentUser scope, optional entropy bind) -----------------
$Entropy = [System.Text.Encoding]::UTF8.GetBytes("ultron-cockpit-v1")

function Protect-String([string]$plain) {
    $bytes     = [System.Text.Encoding]::UTF8.GetBytes($plain)
    $encrypted = [System.Security.Cryptography.ProtectedData]::Protect(
        $bytes, $Entropy, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
    return [Convert]::ToBase64String($encrypted)
}

function Unprotect-String([string]$encB64) {
    $encrypted = [Convert]::FromBase64String($encB64)
    $bytes     = [System.Security.Cryptography.ProtectedData]::Unprotect(
        $encrypted, $Entropy, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
    return [System.Text.Encoding]::UTF8.GetString($bytes)
}

# -- Vault IO -----------------------------------------------------------------
function Read-Vault {
    if (-not (Test-Path $VaultPath)) {
        return [pscustomobject]@{
            version  = "1.0"
            services = [pscustomobject]@{}
        }
    }
    return Get-Content -Raw $VaultPath | ConvertFrom-Json
}

function Write-Vault($vault) {
    $dir = Split-Path -Parent $VaultPath
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    if (Test-Path $VaultPath) { Copy-Item -Force $VaultPath $VaultBackup }
    $vault | ConvertTo-Json -Depth 10 | Set-Content -Path $VaultPath -Encoding UTF8
}

function Ensure-ServiceNode($vault, [string]$service) {
    if (-not $vault.services.PSObject.Properties[$service]) {
        $vault.services | Add-Member -NotePropertyName $service -NotePropertyValue (
            [pscustomobject]@{
                profiles = [pscustomobject]@{}
                active   = $null
            }
        )
    }
    return $vault.services.$service
}

# -- Actions ------------------------------------------------------------------
switch ($Action) {

    "Status" {
        Write-Host "[Vault] $VaultPath" -ForegroundColor Cyan
        if (-not (Test-Path $VaultPath)) {
            Write-Host "  (vault file does not exist yet - empty)"
            return
        }
        $vault = Read-Vault
        $svcCount = ($vault.services.PSObject.Properties | Measure-Object).Count
        Write-Host "  Version: $($vault.version)"
        Write-Host "  Services: $svcCount"
        foreach ($p in $vault.services.PSObject.Properties) {
            $svc = $p.Value
            $profCount = ($svc.profiles.PSObject.Properties | Measure-Object).Count
            $active = if ($svc.active) { $svc.active } else { "(none)" }
            Write-Host ("    [{0}] {1} profile(s) | active={2}" -f $p.Name, $profCount, $active)
        }
    }

    "List" {
        $vault = Read-Vault
        if (-not $vault.services.PSObject.Properties) {
            Write-Host "[Vault] empty"
            return
        }
        foreach ($svcProp in $vault.services.PSObject.Properties) {
            $svc = $svcProp.Value
            Write-Host "[$($svcProp.Name)] active=$($svc.active)"
            foreach ($profProp in $svc.profiles.PSObject.Properties) {
                $prof = $profProp.Value
                $marker = if ($svc.active -eq $profProp.Name) { "*" } else { " " }
                Write-Host ("  {0} {1,-20} added={2} label={3}" -f $marker, $profProp.Name, $prof.added, $prof.label)
            }
        }
    }

    "Add" {
        if (-not $Service)     { throw "Add requires -Service" }
        if (-not $ProfileName) { throw "Add requires -ProfileName" }
        if (-not $ConfigPath)  { throw "Add requires -ConfigPath (file with JSON config to encrypt)" }
        if (-not (Test-Path $ConfigPath)) { throw "ConfigPath not found: $ConfigPath" }

        $configJson = Get-Content -Raw $ConfigPath
        # Validate it's parseable JSON before encrypting
        try { $null = $configJson | ConvertFrom-Json } catch { throw "ConfigPath is not valid JSON: $_" }

        $vault = Read-Vault
        $svcNode = Ensure-ServiceNode $vault $Service
        $encrypted = Protect-String $configJson

        $profile = [pscustomobject]@{
            encrypted = $encrypted
            added     = (Get-Date).ToString("o")
            label     = $Label
        }

        # Replace if exists, otherwise add
        if ($svcNode.profiles.PSObject.Properties[$ProfileName]) {
            $svcNode.profiles.$ProfileName = $profile
            Write-Host "[Vault] Updated profile: $Service / $ProfileName" -ForegroundColor Yellow
        } else {
            $svcNode.profiles | Add-Member -NotePropertyName $ProfileName -NotePropertyValue $profile
            Write-Host "[Vault] Added profile:   $Service / $ProfileName" -ForegroundColor Green
        }

        # If this is the first profile for the service, mark it active
        $profCount = ($svcNode.profiles.PSObject.Properties | Measure-Object).Count
        if ($profCount -eq 1 -or -not $svcNode.active) {
            $svcNode.active = $ProfileName
            Write-Host "[Vault] Marked active:   $Service / $ProfileName"
        }

        Write-Vault $vault
    }

    "Get" {
        if (-not $Service)     { throw "Get requires -Service" }
        if (-not $ProfileName) { throw "Get requires -ProfileName" }
        $vault = Read-Vault
        $svcNode = $vault.services.$Service
        if (-not $svcNode -or -not $svcNode.profiles.PSObject.Properties[$ProfileName]) {
            throw "Profile not found: $Service / $ProfileName"
        }
        $decrypted = Unprotect-String $svcNode.profiles.$ProfileName.encrypted
        Write-Output $decrypted
    }

    "Switch" {
        if (-not $Service)     { throw "Switch requires -Service" }
        if (-not $ProfileName) { throw "Switch requires -ProfileName" }
        $vault = Read-Vault
        $svcNode = $vault.services.$Service
        if (-not $svcNode -or -not $svcNode.profiles.PSObject.Properties[$ProfileName]) {
            throw "Profile not found: $Service / $ProfileName"
        }

        if (-not (Test-Path $SettingsPath)) {
            throw "settings.json not found: $SettingsPath"
        }

        # Decrypt the target profile config
        $newConfigJson = Unprotect-String $svcNode.profiles.$ProfileName.encrypted
        $newConfig = $newConfigJson | ConvertFrom-Json

        # Confirmation unless -Force
        if (-not $Force) {
            Write-Host "[Vault] About to swap mcpServers.$Service in $SettingsPath" -ForegroundColor Yellow
            Write-Host "        Profile: $ProfileName"
            $resp = Read-Host "Confirm? (y/N)"
            if ($resp -notmatch "^[yY]") {
                Write-Host "[Vault] Aborted by user"
                return
            }
        }

        # Backup settings.json
        $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
        $settingsBackup = "$SettingsPath.$stamp.bak"
        Copy-Item -Force $SettingsPath $settingsBackup
        Write-Host "[Vault] Backup: $settingsBackup"

        # Read settings, swap mcpServers.<service>, write atomically
        $settings = Get-Content -Raw $SettingsPath | ConvertFrom-Json
        if (-not $settings.mcpServers) {
            $settings | Add-Member -NotePropertyName mcpServers -NotePropertyValue ([pscustomobject]@{}) -Force
        }
        if ($settings.mcpServers.PSObject.Properties[$Service]) {
            $settings.mcpServers.$Service = $newConfig
        } else {
            $settings.mcpServers | Add-Member -NotePropertyName $Service -NotePropertyValue $newConfig
        }

        $tmp = "$SettingsPath.tmp"
        $settings | ConvertTo-Json -Depth 20 | Set-Content -Path $tmp -Encoding UTF8
        Move-Item -Force $tmp $SettingsPath

        # Update active marker
        $svcNode.active = $ProfileName
        Write-Vault $vault

        Write-Host "[Vault] Switched: $Service active = $ProfileName" -ForegroundColor Green
        Write-Host "        Restart Claude Code for MCP changes to take effect."
    }

    "Remove" {
        if (-not $Service)     { throw "Remove requires -Service" }
        if (-not $ProfileName) { throw "Remove requires -ProfileName" }
        $vault = Read-Vault
        $svcNode = $vault.services.$Service
        if (-not $svcNode -or -not $svcNode.profiles.PSObject.Properties[$ProfileName]) {
            throw "Profile not found: $Service / $ProfileName"
        }

        if (-not $Force) {
            Write-Host "[Vault] About to remove $Service / $ProfileName" -ForegroundColor Yellow
            $resp = Read-Host "Confirm? (y/N)"
            if ($resp -notmatch "^[yY]") {
                Write-Host "[Vault] Aborted by user"
                return
            }
        }

        $svcNode.profiles.PSObject.Properties.Remove($ProfileName)
        if ($svcNode.active -eq $ProfileName) {
            # Promote first remaining profile to active, or null
            $remaining = @($svcNode.profiles.PSObject.Properties | Select-Object -First 1)
            $svcNode.active = if ($remaining) { $remaining[0].Name } else { $null }
        }
        # If service has no profiles left, remove the service node entirely
        $remainingCount = ($svcNode.profiles.PSObject.Properties | Measure-Object).Count
        if ($remainingCount -eq 0) {
            $vault.services.PSObject.Properties.Remove($Service)
            Write-Host "[Vault] Service '$Service' had no profiles left, removed service node"
        }
        Write-Vault $vault
        Write-Host "[Vault] Removed: $Service / $ProfileName" -ForegroundColor Green
    }
}
