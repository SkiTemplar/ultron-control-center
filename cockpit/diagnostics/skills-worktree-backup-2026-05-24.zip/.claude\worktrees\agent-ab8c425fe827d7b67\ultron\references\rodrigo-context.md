# ULTRON — Contexto Personal de Rodrigo

---

## IDENTIDAD

Nombre: Rodrigo
Email: rodrixfc17@gmail.com
Zona horaria: Europe/Madrid
Rol: Estudiante ingenieria U-tad + desarrollador freelance/emprendedor

---

## UNIVERSIDAD U-tad

Asignaturas activas: ver Blackboard via Chrome MCP
Rutas academicas: C:\Users\Rodrigo\CARRERA\[Asignatura]\[Proyecto]\
Protocolo: verificar en Blackboard antes de marcar entregas como completadas

---

## STACK TECNOLOGICO

Principal:
  C++ / Unreal Engine 5  → Carrera (GAS, replicacion, UObject)
  C# / Unity             → Carrera (MonoBehaviour, NGO, Coroutines)
  TypeScript             → Proyectos web y APIs
  Python                 → Scripts, analisis, automatizacion

Secundario:
  HLSL/GLSL, Bash/PowerShell, SQL

Herramientas:
  VS Code, Visual Studio, GitHub, Supabase, Notion, Vercel/Railway

---

## HERRAMIENTAS CONECTADAS (MCPs activos)

  Notion, Gmail, Google Calendar, Spotify
  Desktop Commander, Windows-MCP, Chrome MCP
  Supabase, Scheduled Tasks
  Google Drive (pendiente de conectar)

---

## RUTAS DE PROYECTOS

  C:\Users\Rodrigo\CARRERA\[Asignatura]\[Proyecto]\   → Carrera U-tad
  C:\Users\Rodrigo\Documents\[Proyecto]\               → Proyectos personales
  C:\Users\Rodrigo\[repo-name]\                        → Repos clonados

---

## SISTEMA DE ESPECIALISTAS

PANA         → Centro de mando personal (emails, agenda, tareas, Spotify)
Terry Davis  → Todo lo que sea codigo
Alfred       → Sistema Windows, archivos, procesos
Einstein     → Investigacion profunda (excepcion: C++/GPU/IA → Novalbos)
Novalbos     → C++ profundo, GPU, IA, bajo nivel, aprendizaje tecnico, modo /learn
Jordan       → Negocio, monetizacion, estrategia
Mike Tyson   → Diseno visual, UI/UX
Profesor     → Fisica universitaria
Tio Gilito   → Finanzas personales (gastos, KutxaBank, presupuesto)
Warren       → Inversiones, bolsa, ETF, cartera, analisis fundamental
Repo Eval.   → Correccion academica de codigo (Kirkardo)
Manolo Lama  → Futbol y momentos epicos
Tolkien      → Narrativa, worldbuilding, escritura
ULTRON       → Orquestacion, proyectos multi-dominio, memoria del sistema

Sistema ULTRON v6.0 inicializado: 2026-04-13 | Ultima actualizacion: 2026-04-23
