# ULTRON v10.0 - Pester unit tests for auth-vault.ps1
#
# Tests structure WITHOUT actually invoking DPAPI (which would create real vault entries).
# Pester 3.x compatible (PS 5.1 default).
#
# Run: Invoke-Pester C:\Users\Rodrigo\.claude\skills\ultron\tests\auth-vault.Tests.ps1

$helper = Join-Path $PSScriptRoot "..\scripts\cockpit\auth-vault.ps1"
$helper = (Resolve-Path $helper).Path

Describe "auth-vault helper - parameter validation" {

    It "exists and is parseable PowerShell" {
        Test-Path $helper | Should Be $true
        $null = [scriptblock]::Create((Get-Content -Raw $helper))
    }

    It "rejects invalid Action parameter" {
        { & $helper -Action "BogusAction" -ErrorAction Stop } | Should Throw
    }

    It "Add fails without -Service" {
        $err = $null
        try { & $helper -Action Add -ProfileName foo -ConfigPath C:\nonexistent.json 2>&1 | Out-Null } catch { $err = $_ }
        ($err -ne $null -or $LASTEXITCODE -ne 0) | Should Be $true
    }

    It "Add fails without -ProfileName" {
        $err = $null
        try { & $helper -Action Add -Service gmail -ConfigPath C:\nonexistent.json 2>&1 | Out-Null } catch { $err = $_ }
        ($err -ne $null -or $LASTEXITCODE -ne 0) | Should Be $true
    }

    It "Add fails when ConfigPath does not exist" {
        $bogus = Join-Path $env:TEMP "ultron-vault-test-nonexistent-$(Get-Random).json"
        $err = $null
        try { & $helper -Action Add -Service x -ProfileName y -ConfigPath $bogus 2>&1 | Out-Null } catch { $err = $_ }
        ($err -ne $null -or $LASTEXITCODE -ne 0) | Should Be $true
    }

    It "Switch fails without -Service" {
        $err = $null
        try { & $helper -Action Switch -ProfileName foo 2>&1 | Out-Null } catch { $err = $_ }
        ($err -ne $null -or $LASTEXITCODE -ne 0) | Should Be $true
    }
}

Describe "auth-vault helper - DPAPI lifecycle smoke (encrypt, decrypt, remove)" {

    $tmpDir = Join-Path $env:TEMP "ultron-vault-tests-$(Get-Random)"
    New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null
    $configFile = Join-Path $tmpDir "test-config.json"
    Set-Content -Path $configFile -Value '{"command":"node","args":["test.js"],"type":"stdio"}' -Encoding UTF8
    $vaultFile = Join-Path $env:USERPROFILE ".ultron\cockpit\auth-vault.dpapi"
    $svc = "pester-test-svc"
    $prof = "pester-test-profile"

    # Read vault directly. Use -Encoding UTF8 which handles PS-written BOM transparently.
    function Get-VaultJson {
        if (-not (Test-Path $vaultFile)) { return $null }
        return (Get-Content -Raw -Encoding UTF8 $vaultFile) | ConvertFrom-Json
    }

    It "Add succeeds and writes the service to vault JSON" {
        & $helper -Action Add -Service $svc -ProfileName $prof -ConfigPath $configFile -Label "test@pester" | Out-Null
        $vault = Get-VaultJson
        $vault | Should Not BeNullOrEmpty
        $vault.services.PSObject.Properties[$svc] | Should Not BeNullOrEmpty
    }

    It "Vault entry has encrypted blob and metadata" {
        $vault = Get-VaultJson
        $node  = $vault.services.$svc.profiles.$prof
        $node.encrypted | Should Not BeNullOrEmpty
        $node.label     | Should Be "test@pester"
        $node.added     | Should Not BeNullOrEmpty
        $vault.services.$svc.active | Should Be $prof
    }

    It "Get returns the original JSON config (DPAPI round-trip)" {
        $output = & $helper -Action Get -Service $svc -ProfileName $prof | Out-String
        $output -match '"command"\s*:\s*"node"' | Should Be $true
        $output -match '"type"\s*:\s*"stdio"'   | Should Be $true
    }

    It "Remove deletes profile and orphan service node disappears" {
        & $helper -Action Remove -Service $svc -ProfileName $prof -Force | Out-Null
        $vault = Get-VaultJson
        $vault.services.PSObject.Properties[$svc] | Should BeNullOrEmpty
    }

    # Cleanup
    Remove-Item -Recurse -Force $tmpDir -ErrorAction SilentlyContinue
}

Describe "auth-vault helper - script structure" {

    $content = Get-Content -Raw $helper

    It "uses Windows DPAPI ProtectedData (CurrentUser scope)" {
        $content -match "ProtectedData\]::Protect" | Should Be $true
        $content -match "DataProtectionScope\]::CurrentUser" | Should Be $true
    }

    It "uses entropy bind for additional protection" {
        $content -match '\$Entropy' | Should Be $true
    }

    It "backs up settings.json before Switch (timestamped .bak)" {
        $content -match "settingsBackup" | Should Be $true
        $content -match '\.bak' | Should Be $true
    }

    It "uses atomic write via temp file rename" {
        $content -match '\$tmp\s*=.*tmp' | Should Be $true
        $content -match 'Move-Item.*\$tmp' | Should Be $true
    }

    It "validates ConfigPath as parseable JSON before encrypting" {
        $content -match 'ConvertFrom-Json' | Should Be $true
    }

    It "removes orphan service node when last profile is removed" {
        $content -match "no profiles left" | Should Be $true
    }
}
