# SKILL REGISTRY — Mapa completo del arsenal de Rodrigo
## Última actualización: 2026-04-27 (v8.1.2)
> Versión compacta de lookup rápido. Fuente autoritativa completa: `~/.ultron/global/skill-registry.md` (v4.1).
> **Total skills locales en `~/.claude/skills/`:** 36 (incluye ultron meta) + Codex CLI como MCP server externo.

---

## 🎮 GAME DEVELOPMENT

| Skill | Descripción | Cuándo activar | Entorno |
|-------|-------------|----------------|---------|
| `don-claudio` | Padrino del game dev — PERSONA maestra | Cualquier pregunta de game dev a alto nivel | CC + Desktop |
| `game-development` | Orquestador técnico de game dev | Patrones, game loop, routing a sub-skills | Solo Desktop |
| `unity-developer` | Unity 6 LTS completo | C#, URP/HDRP, Addressables, cross-platform | Solo Desktop |
| `unity-ecs-patterns` | DOTS / ECS / Burst | Performance extrema, miles de entidades | Solo Desktop |
| `unity-mcp-orchestrator` | Control Unity Editor vía MCP | Automatizar Unity Editor directamente | Solo Desktop |
| `unreal-engine-cpp-pro` | UE5 C++ nivel pro | UObject, GAS, Nanite, Lumen, Blueprints | Solo Desktop |
| `game-dev-multiplayer` | Networking y netcode | Juegos multijugador, lag comp, anti-cheat | Solo Desktop |
| `game-dev-3d` | Rendering 3D, shaders, física | Juegos 3D, pipeline rendering, cámaras | Solo Desktop |

## 🎨 ARTE Y GRÁFICOS

| Skill | Descripción | Cuándo activar | Entorno |
|-------|-------------|----------------|---------|
| `blender-expert` | Blender 3D completo | Modelado, rigging, animación, export | Solo Desktop |
| `metal-shader-expert` | HLSL/GLSL/MSL + PBR | Shaders, PRGR, compute shaders | Solo Desktop |
| `mike-tyson` | UI/UX y diseño visual | Interfaces, layouts, crítica de diseño, mockups | CC + Desktop |
| `canvas-design` | Arte visual PNG/PDF | Posters, ilustraciones, diseño gráfico | Solo Desktop |
| `ui-ux-pro-max` | Recurso de referencia de Mike (67 estilos, 161 paletas) | Mike lo invoca internamente | CC + Desktop |

## 💻 INGENIERÍA Y CÓDIGO

| Skill | Descripción | Cuándo activar | Entorno |
|-------|-------------|----------------|---------|
| `terry-davis` | Dev senior de élite | Código general, bugs, arquitectura, CI/CD | CC + Desktop |
| `repo-evaluator` | Evaluador académico (Kirkardo) | Notas, corrección de repos, entregas | CC + Desktop |
| `mcp-builder` | Construir servidores MCP | Crear integraciones MCP nuevas | CC + Desktop |
| `skill-creator` | Crear/mejorar skills | Nuevas skills o mejorar existentes | CC + Desktop |
| `consolidate-memory` | Auditar y fusionar memorias .ultron | Cuando INDEX/MEMORY desordenado o duplicados | CC + Desktop |

## 🛡️ ENGINEERING SKILLS (instaladas v8.x — sin trackear hasta v8.1.1)

| Skill | Descripción | Cuándo activar | Entorno |
|-------|-------------|----------------|---------|
| `api-design-reviewer` | Revisión REST: convenciones, breaking changes, versionado | Diseñando endpoints / antes de deploy / scorecard API | CC |
| `ask-questions-first` | Clarifica requisitos antes de implementar | Dudas serias sobre dirección | CC |
| `database-schema-designer` | Schemas DB relacionales + migraciones + RLS + tipos | Tablas nuevas, multi-tenancy, Supabase/Postgres | CC |
| `differential-review` | Security-focused review de PRs/diffs/commits | Revisión seguridad pre-merge, blast radius | CC |
| `focused-fix` | Reparación sistemática de features rotas | "Haz que X funcione", módulo con cascada de bugs | CC |
| `insecure-defaults` | Detecta fail-open defaults inseguros | Auditoría seguridad, config management | CC |
| `modern-python` | Configura Python con uv, ruff, ty | Proyectos Python nuevos, migrar de pip/Poetry | CC |
| `mutation-testing` | mewt/muton mutation testing | Configurar campañas de mutation testing | CC |
| `performance-profiler` | Profiling Node.js/Python/C++/UE5/web | Bottlenecks, framerate, memory leaks, queries N+1 | CC |
| `property-based-testing` | Tests basados en propiedades (hypothesis, fast-check) | Serialización/validación/parsing, cobertura mejor que examples | CC |
| `second-opinion` | LLM externo (Codex/Gemini CLI) review final del diff | Review final pre-merge, comparar reviews multi-modelo | CC |
| `sharp-edges` | API ergonomics, footguns, secure-by-default | Diseño APIs/configs, evaluar misuse-resistance | CC |
| `spec-to-code-compliance` | Verifica que código cumpla la spec (blockchain audits) | Comparar whitepaper vs implementación, gaps | CC |
| `tech-debt-tracker` | Identificar/priorizar/gestionar deuda técnica | Refactor planificado, sprint con tech debt, paga vs feature | CC |
| `theme-factory` | Estilizar artifacts con themes (10 presets + on-the-fly) | Slides, docs, reportings, HTML landing pages | CC |
| `variant-analysis` | Buscar variants de bugs/vulns con CodeQL/Semgrep | Hunting variants tras encontrar 1 bug, audits | CC |
| `webapp-testing` | Playwright para testing local de web apps | Verificar frontend, debug UI, screenshots, browser logs | CC |

## 🧠 CONOCIMIENTO E INVESTIGACIÓN

| Skill | Descripción | Cuándo activar | Entorno |
|-------|-------------|----------------|---------|
| `einstein` | Científico universal | Investigar, papers, aprender cualquier tema | CC + Desktop |
| `profesor-fisica` | Física universitaria | Cinemática, dinámica, exámenes de Física | CC + Desktop |
| `novalbos` | Profesor técnico — C++/Gráfica/IA/Bajo Nivel | Aprender, entender, apuntes Notion/NotebookLM, modo Learn | CC + Desktop |

## 💼 NEGOCIO Y PRODUCTIVIDAD

| Skill | Descripción | Cuándo activar | Entorno |
|-------|-------------|----------------|---------|
| `jordan-belfort` | Estratega de negocio | Monetización, go-to-market, pitch, SaaS | CC + Desktop |
| `pana` | J.A.R.V.I.S. personal | Gmail, Calendar, Notion, Spotify, briefings | CC + Desktop |
| `alfred` | Mayordomo del sistema | Windows, procesos, archivos, drivers | CC + Desktop |
| `tio-gilito` | Finanzas personales | Gastos, KutxaBank, fondos, presupuesto | CC + Desktop |
| `manolo-lama` | Comentarista deportivo | Fútbol, análisis deportivo, épica | CC + Desktop |
| `warren` | Asesor de inversiones | Bolsa, ETF, cartera, análisis fundamental, ¿compro X? | CC + Desktop |
| `schedule` | Tareas programadas | Automatizar tareas en intervalos | CC + Desktop |
| `ultron` | Orquestador maestro | Multi-dominio, proyectos complejos | CC + Desktop |

## 📄 DOCUMENTOS Y ARCHIVOS

| Skill | Descripción | Cuándo activar | Entorno |
|-------|-------------|----------------|---------|
| `docx` | Word documents | Crear/editar .docx | Solo Desktop |
| `pdf` | PDFs | Crear, leer, manipular PDFs | Solo Desktop |
| `pptx` | Presentaciones | Crear/editar .pptx | Solo Desktop |
| `xlsx` | Hojas de cálculo | Crear/editar Excel | Solo Desktop |
| `web-artifacts-builder` | HTML/React complejos | Artifacts web multi-componente | Solo Desktop |

---

## ÁRBOL DE DECISIÓN GAME DEV

```
¿Qué tipo de tarea de game dev?
│
├── Diseño de sistemas, arquitectura de juego, decisiones de alto nivel
│   └── → DON CLAUDIO (persona) + cargar sub-skill técnica relevante
│
├── Unity específico
│   ├── Performance extrema (ECS, miles de entidades) → unity-ecs-patterns
│   ├── Control del Editor via MCP → unity-mcp-orchestrator
│   └── Todo lo demás → unity-developer
│
├── Unreal Engine 5 (C++)
│   └── → unreal-engine-cpp-pro
│
├── Multiplayer / Networking
│   └── → game-dev-multiplayer
│
├── Shaders / Rendering / PRGR
│   └── → metal-shader-expert + game-dev-3d
│
├── Assets 3D / Blender
│   └── → blender-expert
│
└── Patrones generales de game dev
    └── → game-development (orquestador)
```

---

## MCPs CONECTADOS

| MCP | Para qué | Skills que lo usan |
|-----|----------|--------------------|
| Unity MCP | Controlar Unity Editor | `unity-mcp-orchestrator` |
| Blender MCP | Controlar Blender | `blender-expert` |
| Desktop Commander | Windows FS, procesos | `alfred`, ULTRON |
| Windows-MCP | PowerShell, sistema | `alfred`, ULTRON |
| Notion MCP | Base de conocimiento | `pana`, ULTRON |
| Gmail MCP | Emails | `pana` |
| GCal MCP | Calendario | `pana` |
| Supabase MCP | Bases de datos | `terry-davis`, proyectos |
| Chrome MCP | Navegación web | ULTRON, investigación |
| Spotify MCP | Música | `pana` |
| **Codex MCP (NUEVO v8.1)** | Codex como tool MCP nativo (`mcp__codex__*`) | ULTRON Dual Mode (alternativa a helper PS) |
| sequential-thinking | Razonamiento estructurado | ULTRON HIGH/ULTRA |
| context7 | Docs oficiales libs | ULTRON HIGH/ULTRA, terry-davis |
| memory (MCP) | Memoria estructurada externa | ULTRON contexto |
| playwright (MCP) | Browser automation | webapp-testing, ULTRON |
| firebase | Firebase tools | terry-davis si Firebase |

## Externos (CLI invocables como skill o MCP)

| Tool | Cómo se invoca | Para qué |
|------|----------------|----------|
| Codex CLI 0.125.0 (gpt-5.5) | `Skill second-opinion` (review puntual) o `Dual Mode` overlay (peer continuo) o MCP nativo (v8.1+) | Segunda opinión / DUET pattern |
| Gemini CLI | `Skill second-opinion` con `Gemini` flag | Review final con context window 1M |
