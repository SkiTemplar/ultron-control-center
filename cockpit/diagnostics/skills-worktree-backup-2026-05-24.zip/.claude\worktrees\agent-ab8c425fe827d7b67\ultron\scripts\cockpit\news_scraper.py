#!/usr/bin/env python3
"""
ULTRON v10.0 Cockpit - AI News Scraper.

Scrapes:
  - RSS feeds (Anthropic, OpenAI, Google AI, HN front page filter)
  - Reddit JSON API public endpoints (r/LocalLLaMA, r/ClaudeAI top daily)

Filters:
  - Whitelist: model names (Claude X.X, GPT-X, Gemini X.X), release/deprecate/regression,
    benchmark, MCP, Codex/gemini-cli, Anthropic/OpenAI/Google AI announcements
  - Blacklist: drama, leak rumor, "user said"

Output:
  - ~/.ultron/cockpit/news/YYYY-MM-DD.md  (today's digest)
  - ~/.ultron/cockpit/news/ALERTS.md      (breaking changes, append-only)
  - ~/.ultron/cockpit/news/seen.json      (dedup hash)

NO external deps required (uses urllib, json, re, hashlib only).
Gemini summarization is OPTIONAL - if `gemini` is available in PATH, we use
gemini-duet.ps1 to summarize; otherwise we just include item titles + URLs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

sys.path.insert(0, str(Path(__file__).parent))
from cockpit_base import Cockpit, NEWS_DIR, NEWS_ALERTS, NEWS_SEEN  # noqa: E402


USER_AGENT = "ULTRON-Cockpit/10.0 (news scraper, personal use)"
HTTP_TIMEOUT = 12

# ── Sources ──────────────────────────────────────────────────────────────────

# Anthropic does NOT publish an official RSS feed (verified 2026-04, see GitHub
# issue DIYgod/RSSHub#18943). Workaround: HN filter with broad Anthropic keywords
# captures discussions and announcements indirectly.
RSS_FEEDS = [
    ("OpenAI",      "https://openai.com/blog/rss.xml"),
    ("Google AI",   "https://blog.google/technology/ai/rss/"),
    ("HN AI",       "https://hnrss.org/newest?q=Claude+OR+Anthropic+OR+GPT-5+OR+OpenAI+OR+Gemini&points=30"),
    ("HN Front",    "https://hnrss.org/frontpage?q=AI+OR+LLM"),
]

REDDIT_FEEDS = [
    ("r/LocalLLaMA",   "https://www.reddit.com/r/LocalLLaMA/top.json?t=day&limit=15"),
    ("r/ClaudeAI",     "https://www.reddit.com/r/ClaudeAI/top.json?t=day&limit=15"),
    ("r/singularity",  "https://www.reddit.com/r/singularity/top.json?t=day&limit=10"),
]

# Cap on items KEPT in final digest (after filter+dedup+score). Total across all sources.
MAX_ITEMS_DIGEST = 25

# Rodrigo's high-priority keywords - boost score +5 when matched (verbatim or close).
# These are the names he wants to track most: current models he uses + future model announces.
PRIORITY_KEYWORDS = re.compile(
    r"\b(Opus\s*4\.[789]|Opus\s*5|Sonnet\s*4\.[6789]|Sonnet\s*5|Haiku\s*5|Mythos|"
    r"GPT[-\s]?5\.[5-9]|GPT[-\s]?6|"
    r"Gemini\s*3\.[1-9]|Gemini\s*4|"
    r"Claude\s*Code|Claude\s*Skills|"
    r"Codex\s*CLI|gemini-cli|"
    r"Anthropic|OpenAI|DeepMind)\b",
    re.IGNORECASE,
)

# ── Filtering ────────────────────────────────────────────────────────────────

# Match these (case-insensitive) anywhere in title to keep the item.
WHITELIST_PATTERNS = [
    r"\bClaude\s*\d+\.\d+\b", r"\bGPT[\s-]*\d+(\.\d+)?\b", r"\bGemini\s*\d+(\.\d+)?\b",
    r"\bO\d+\b",  # o3, o4, o5
    r"\b(Sonnet|Opus|Haiku|Mythos)\b",
    r"\b(release|releases|released|launching|launched|announce[ds]?|introducing)\b",
    r"\b(deprecate[sd]?|deprecation|sunset|EOL|retires|retiring)\b",
    r"\b(regression|degradation|nerfed?|quality\s*drop)\b",
    r"\bbenchmark(s|ed)?\b",
    r"\b(MCP|skill|skills|hook|hooks)\b.*\b(Claude|Anthropic|OpenAI|Google)\b",
    r"\b(Codex\s*CLI|gemini-cli|Cursor|Cline|aider)\b",
    r"\b(Anthropic|OpenAI|Google\s*AI|DeepMind|xAI|Grok|Meta\s*AI|Llama\s*4|Mistral)\b",
    r"\bcontext\s*window\b",
    r"\b(api|sdk)\b.*\b(update|change|new|release)\b",
]
WL_RE = re.compile("|".join(WHITELIST_PATTERNS), re.IGNORECASE)

# Reject these (case-insensitive) to cut noise.
BLACKLIST_PATTERNS = [
    r"\bI\s+(found|made|built|wrote|tried|discovered|prompted)\b",  # Reddit "I did X" posts
    r"\bcan\s+anyone\b", r"\bdoes\s+anyone\b", r"\bwhy\s+is\b",
    r"\b(meme|joke|funny|hilarious)\b",
    r"\b(leaked|rumor|allegedly)\b",
    r"\bMy\s+(AI|Claude|Gemini|GPT)\b",
    r"\bweekend\s+(project|build)\b",
]
BL_RE = re.compile("|".join(BLACKLIST_PATTERNS), re.IGNORECASE)

# Breaking-change signals - if matched, item also goes into ALERTS.md
BREAKING_PATTERNS = [
    r"\b(release[sd]?|launching|launched)\b.*\b(Claude|GPT|Gemini|Opus|Sonnet|Haiku)\s*\d",
    r"\bdeprecate[sd]?\b",
    r"\bregression\b.*\b(Claude|GPT|Opus|Gemini)\b",
    r"\bbreaking\s*change\b",
    r"\b(API|SDK)\s+(removed|sunset|EOL)\b",
]
BREAKING_RE = re.compile("|".join(BREAKING_PATTERNS), re.IGNORECASE)


def http_get(url: str) -> bytes | None:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "*/*"})
        with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as r:
            return r.read()
    except Exception as e:
        print(f"[news] WARN: GET {url} failed: {e}", file=sys.stderr)
        return None


# ── Parsers (RSS and Reddit JSON, no external deps) ──────────────────────────

def parse_rss(xml_bytes: bytes, source: str) -> list[dict]:
    """Naive RSS/Atom parser - returns list of {title, url, source, summary}."""
    if not xml_bytes:
        return []
    text = xml_bytes.decode("utf-8", errors="replace")
    items: list[dict] = []

    # Try RSS <item> first, then Atom <entry>
    item_re = re.compile(r"<(item|entry)\b[^>]*>(.*?)</\1>", re.DOTALL | re.IGNORECASE)
    for _, body in item_re.findall(text):
        def grab(tag: str) -> str:
            m = re.search(rf"<{tag}\b[^>]*>(.*?)</{tag}>", body, re.DOTALL | re.IGNORECASE)
            if not m:
                return ""
            inner = m.group(1).strip()
            # Strip CDATA + tags
            inner = re.sub(r"<!\[CDATA\[(.*?)\]\]>", r"\1", inner, flags=re.DOTALL)
            inner = re.sub(r"<[^>]+>", "", inner)
            return inner.strip()

        def grab_link() -> str:
            # Atom <link href="..."/> or RSS <link>...</link>
            m = re.search(r"<link\b[^>]*href=[\"']([^\"']+)[\"']", body)
            if m:
                return m.group(1)
            m = re.search(r"<link\b[^>]*>([^<]+)</link>", body)
            if m:
                return m.group(1).strip()
            return ""

        title = grab("title")
        url = grab_link()
        summary = grab("description") or grab("summary") or grab("content")
        if title and url:
            items.append({
                "title": title[:200],
                "url": url[:500],
                "source": source,
                "summary": (summary or "")[:500],
            })
    return items


def parse_reddit(json_bytes: bytes, source: str) -> list[dict]:
    if not json_bytes:
        return []
    try:
        data = json.loads(json_bytes)
    except json.JSONDecodeError:
        return []
    children = data.get("data", {}).get("children", [])
    items = []
    for c in children:
        d = c.get("data", {})
        title = d.get("title", "")
        url = "https://reddit.com" + d.get("permalink", "")
        items.append({
            "title": title[:200],
            "url": url,
            "source": source,
            "summary": (d.get("selftext", "") or "")[:500],
        })
    return items


# ── Filtering / dedup ────────────────────────────────────────────────────────

def is_relevant(item: dict) -> bool:
    title = item.get("title", "")
    if BL_RE.search(title):
        return False
    return bool(WL_RE.search(title) or WL_RE.search(item.get("summary", "")))


def relevance_score(item: dict) -> int:
    """Score for ranking. Title matches count more than summary matches.
    Breaking signals + Rodrigo's priority keywords get extra boost."""
    title = item.get("title", "")
    summary = item.get("summary", "")[:300]
    blob = title + " " + summary
    score = 0
    score += 3 * len(WL_RE.findall(title))
    score += 1 * len(WL_RE.findall(summary))
    if BREAKING_RE.search(blob):
        score += 10
    # Rodrigo's priority keywords - +5 per match (Opus 4.7, GPT 5.5, Gemini 3.1, Mythos, etc.)
    score += 5 * len(PRIORITY_KEYWORDS.findall(blob))
    # Penalty for very short summaries (likely just a title repeat)
    if len(summary) < 30:
        score -= 1
    # Source quality boost
    src = item.get("source", "")
    if src in ("OpenAI", "Google AI"):
        score += 2  # official sources rank higher
    return score


def is_breaking(item: dict) -> bool:
    blob = item.get("title", "") + " " + item.get("summary", "")
    return bool(BREAKING_RE.search(blob))


def item_hash(item: dict) -> str:
    return hashlib.sha1(item.get("url", "").encode("utf-8")).hexdigest()[:16]


def load_seen() -> set[str]:
    data = Cockpit.read_json(NEWS_SEEN, default={"seen": []})
    return set(data.get("seen", []))


def save_seen(seen: set[str]) -> None:
    # Cap at 5000 to keep file size sane
    items = list(seen)[-5000:]
    Cockpit.write_json(NEWS_SEEN, {"seen": items}, backup=False)


# ── Summarization (optional Gemini) ──────────────────────────────────────────

def gemini_available() -> bool:
    return shutil.which("gemini") is not None


def _extract_json_object(text: str) -> str | None:
    """Walk text from first char (assumed '{') to matching '}'. Multi-line tolerant."""
    depth = 0
    in_string = False
    escape = False
    for i, ch in enumerate(text):
        if escape:
            escape = False
            continue
        if ch == "\\" and in_string:
            escape = True
            continue
        if ch == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[: i + 1]
    return None


def summarize_with_gemini(items: list[dict]) -> str | None:
    """Call gemini flash via CLI to produce a 5-bullet TL;DR. Returns markdown or None.

    v10.5.1 fix: Gemini in plan mode often does Read tool-use first ("I will read
    the news file...") instead of replying directly. When that happens, `-o json`
    is not respected and stdout is plain text. We now:
      1. Run from a tempdir so no GEMINI.md / workspace context auto-loads
      2. Try JSON parse first (clean direct response path)
      3. Fall back to plain-text extraction if stdout has no JSON envelope
    """
    if not items:
        return None
    gemini_bin = shutil.which("gemini")
    if not gemini_bin:
        return None
    bullets = "\n".join(f"- [{it['source']}] {it['title']}" for it in items[:10])
    prompt = (
        "Task: summarize AI/LLM industry news in 5 markdown bullets, each <=120 chars. "
        "Format: '- {one-liner} ({source})'. Pick MOST important. Skip noise. "
        "Output ONLY the 5 bullets. No preamble. Do not invoke tools.\n\n"
        f"Headlines:\n{bullets}"
    )
    import tempfile as _tempfile
    try:
        with _tempfile.TemporaryDirectory() as cwd_tmp:
            result = subprocess.run(
                [gemini_bin, "-p", prompt, "-m", "flash", "--approval-mode", "plan",
                 "-o", "json", "--skip-trust"],
                cwd=cwd_tmp,
                capture_output=True, text=True, timeout=90, encoding="utf-8",
            )
        raw = (result.stdout or "").strip()
        if not raw:
            if result.stderr:
                print(f"[news] Gemini stderr: {result.stderr[:200]}", file=sys.stderr)
            return None

        # Path 1: JSON envelope present
        first = raw.find("{")
        if first >= 0:
            payload = _extract_json_object(raw[first:])
            if payload:
                try:
                    data = json.loads(payload)
                    response = data.get("response", "")
                    response = re.sub(r"^```(?:markdown)?\s*", "", response.strip())
                    response = re.sub(r"\s*```$", "", response)
                    if response:
                        return response
                except json.JSONDecodeError as e:
                    print(f"[news] JSON parse failed: {e}", file=sys.stderr)

        # Path 2: plain-text fallback. Extract bullet lines (start with '-' or '*').
        bullet_lines = [
            ln.rstrip() for ln in raw.splitlines()
            if ln.strip().startswith(("-", "*"))
        ]
        if len(bullet_lines) >= 3:
            return "\n".join(bullet_lines[:5])

        # Last resort: return raw if it looks like a summary (≤800 chars, multi-line)
        if 50 <= len(raw) <= 800 and "\n" in raw:
            return raw
    except Exception as e:
        print(f"[news] Gemini summarize failed (non-fatal): {e}", file=sys.stderr)
    return None


# ── Output ───────────────────────────────────────────────────────────────────

def write_digest(items: list[dict], breaking: list[dict], summary: str | None) -> Path:
    NEWS_DIR.mkdir(parents=True, exist_ok=True)
    today = datetime.now().strftime("%Y-%m-%d")
    path = NEWS_DIR / f"{today}.md"

    new_count = sum(1 for it in items if it.get("_is_new"))
    lines = [f"# AI News Digest - {today}", ""]
    lines.append(f"_Generated {datetime.now().isoformat(timespec='seconds')} | "
                 f"{len(items)} items | {new_count} new since last run_")
    lines.append("")

    if summary:
        lines.append("## TL;DR")
        lines.append("")
        lines.append(summary)
        lines.append("")

    if breaking:
        lines.append("## Breaking changes")
        lines.append("")
        for it in breaking:
            badge = " 🆕" if it.get("_is_new") else ""
            lines.append(f"- **[{it['source']}]** [{it['title']}]({it['url']}){badge}")
        lines.append("")

    lines.append("## All items")
    lines.append("")
    by_source: dict[str, list] = {}
    for it in items:
        by_source.setdefault(it["source"], []).append(it)
    for src in sorted(by_source.keys()):
        lines.append(f"### {src}")
        for it in by_source[src]:
            badge = " 🆕" if it.get("_is_new") else ""
            lines.append(f"- [{it['title']}]({it['url']}){badge}")
        lines.append("")

    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def append_alerts(breaking: list[dict]) -> None:
    if not breaking:
        return
    NEWS_ALERTS.parent.mkdir(parents=True, exist_ok=True)
    existing = NEWS_ALERTS.read_text(encoding="utf-8") if NEWS_ALERTS.exists() else ""
    new_lines = []
    if not existing:
        new_lines.append("# ULTRON News ALERTS - breaking changes log")
        new_lines.append("> Auto-loaded into next Claude session for awareness.")
        new_lines.append("")
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    new_lines.append(f"## {today}")
    for it in breaking:
        new_lines.append(f"- **[{it['source']}]** [{it['title']}]({it['url']})")
    new_lines.append("")
    NEWS_ALERTS.write_text(existing + "\n".join(new_lines), encoding="utf-8")


# ── Main ─────────────────────────────────────────────────────────────────────

def run(use_gemini: bool, verbose: bool) -> int:
    print(f"[news] Run @ {datetime.now().isoformat(timespec='seconds')}")
    seen = load_seen()
    raw: list[dict] = []

    for source, url in RSS_FEEDS:
        if verbose:
            print(f"[news] Fetching RSS {source}: {url}")
        body = http_get(url)
        if body:
            raw.extend(parse_rss(body, source))

    for source, url in REDDIT_FEEDS:
        if verbose:
            print(f"[news] Fetching Reddit {source}: {url}")
        body = http_get(url)
        if body:
            raw.extend(parse_reddit(body, source))

    print(f"[news] Raw items fetched: {len(raw)}")

    # Filter
    relevant = [it for it in raw if is_relevant(it)]
    print(f"[news] Relevant after whitelist/blacklist: {len(relevant)}")

    if not relevant:
        print("[news] No relevant items today (whitelist too strict or upstream feeds dry)")
        return 0

    # v10.4 fix: dedup-by-seen was emptying daily digest after first run.
    # New behavior: digest always shows top N by score (deterministic across runs).
    # Mark items as "new" (not in seen) for visual badge. Use seen ONLY for ALERTS dedup.
    for it in relevant:
        it["_score"] = relevance_score(it)
        it["_is_new"] = item_hash(it) not in seen
    relevant.sort(key=lambda x: x["_score"], reverse=True)
    fresh = relevant[:MAX_ITEMS_DIGEST]
    new_count = sum(1 for it in fresh if it["_is_new"])
    print(f"[news] Top {len(fresh)} by score in digest ({new_count} new since last run)")
    if len(relevant) > MAX_ITEMS_DIGEST:
        print(f"[news] Capped to top {MAX_ITEMS_DIGEST} (dropped {len(relevant) - MAX_ITEMS_DIGEST} lower-score)")

    # Detect breaking — but only ALERT for ones we haven't alerted before
    breaking_in_digest = [it for it in fresh if is_breaking(it)]
    new_breaking = [it for it in breaking_in_digest if it["_is_new"]]
    if new_breaking:
        print(f"[news] New breaking changes: {len(new_breaking)} (alerting)")
        append_alerts(new_breaking)
    elif breaking_in_digest:
        print(f"[news] {len(breaking_in_digest)} breaking in digest, all already alerted")

    # Mark all relevant as seen for future ALERTS dedup
    for it in relevant:
        seen.add(item_hash(it))
    save_seen(seen)

    # Use full breaking list for digest highlight (includes already-alerted ones)
    breaking = breaking_in_digest

    # Optional summarization
    summary = None
    if use_gemini and gemini_available():
        if verbose:
            print("[news] Summarizing top items with gemini flash...")
        summary = summarize_with_gemini(fresh)

    # Write digest
    path = write_digest(fresh, breaking, summary)
    print(f"[news] Wrote {path}")
    return 0


def main():
    p = argparse.ArgumentParser(description="ULTRON Cockpit AI news scraper")
    p.add_argument("--no-gemini", action="store_true",
                   help="Skip Gemini summarization (faster, free)")
    p.add_argument("--verbose", "-v", action="store_true")
    p.add_argument("--from-cron", action="store_true",
                   help="(Internal) Apply daily skip-guard. Manual runs always execute.")
    args = p.parse_args()

    # Daily guard ONLY from cron. Manual runs always execute.
    if args.from_cron:
        from should_run import should_run_today
        if not should_run_today("news_scraper"):
            print("[news] Cron skip (already ran today)")
            return 0

    rc = run(use_gemini=not args.no_gemini, verbose=args.verbose)
    if rc == 0 and args.from_cron:
        from should_run import mark_ran_today
        mark_ran_today("news_scraper")
    return rc


if __name__ == "__main__":
    sys.exit(main())
