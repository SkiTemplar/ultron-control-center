# UE5 Gameplay Ability System (GAS) — Referencia Don Claudio

> Fuente: DSTN2000/claude-unreal-engine-skill · Adaptado para uso en CC

## Arquitectura Core

### Ability System Component (ASC)
Hub central que gestiona todo: abilities, attributes, effects, tags.

**Dónde colocarlo:**
- **Single-player / local:** en el Character directamente
- **Multiplayer (recomendado):** en el PlayerState — sobrevive al respawn del Character

```cpp
// En PlayerState
UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
UAbilitySystemComponent* AbilitySystemComponent;

// InitAbilityActorInfo — crítico, llamar en possession
void AMyPlayerState::BeginPlay()
{
    Super::BeginPlay();
    AbilitySystemComponent->InitAbilityActorInfo(this, GetPawn());
}
```

---

## Componentes Principales

### Attributes (AttributeSet)
```cpp
UCLASS()
class UMyAttributeSet : public UAttributeSet
{
    GENERATED_BODY()
public:
    UPROPERTY(BlueprintReadOnly, ReplicatedUsing = OnRep_Health)
    FGameplayAttributeData Health;

    GAMEPLAYATTRIBUTE_PROPERTY_GETTER(UMyAttributeSet, Health)
    GAMEPLAYATTRIBUTE_VALUE_GETTER(Health)
    GAMEPLAYATTRIBUTE_VALUE_SETTER(Health)
    GAMEPLAYATTRIBUTE_VALUE_INITTER(Health)
};
```

### Gameplay Abilities (UGameplayAbility)
- Heredar de `UGameplayAbility`
- `ActivateAbility()` → lógica principal
- `EndAbility()` → SIEMPRE llamar al terminar, incluso en cancel
- Concurrency policies: `NonInstanced`, `InstancedPerActor`, `InstancedPerExecution`

### Gameplay Effects
Data assets que modifican attributes (daño, curación, buffs).
- `Instant` → modifica atributo una vez
- `Duration` → activo N segundos
- `Infinite` → hasta cancelación manual

### Gameplay Tags
Sistema jerárquico de etiquetas: `Character.State.Stunned`, `Ability.Jump`, etc.
Usar para: activación condicional, bloqueo de abilities, consultas de estado.

---

## Setup Mínimo (checklist)

```
[ ] Plugin GameplayAbilities habilitado en .uproject
[ ] Módulos en Build.cs: "GameplayAbilities", "GameplayTags", "GameplayTasks"
[ ] ASC añadido al Character o PlayerState
[ ] AttributeSet registrado en el ASC
[ ] InitAbilityActorInfo() llamado correctamente (server + client)
[ ] Abilities granted en BeginPlay (server only)
[ ] Replication mode configurado: Full (solo player), Mixed/Minimal (AI/mobs)
```

---

## Replication Modes

| Modo | Cuándo usar |
|---|---|
| `Full` | Characters del jugador — todos los atributos replicados a todos |
| `Mixed` | NPCs y enemigos — efectos solo al owner, Gameplay Cues a todos |
| `Minimal` | Mobs en masa — solo Gameplay Cues, mínimo bandwidth |

---

## Pitfalls Críticos

- **Abilities solo se activan en el server** — el cliente puede pedir la activación pero el server la ejecuta
- `InitAbilityActorInfo()` debe llamarse tanto en server como en client tras possession
- `DOREPLIFETIME_CONDITION_NOTIFY` requerido para replicar atributos correctamente
- Olvidar `EndAbility()` provoca que la ability quede "atascada" y no pueda reactivarse
- No usar `InstancedPerExecution` para abilities frecuentes → GC pressure

---

## Debugging

```
Console: showdebug abilitysystem
Console: AbilitySystem.Debug.PrintAllAbilities
Log:     LogAbilitySystem (habilitar en DefaultEngine.ini)
```
