# Terry Davis — Systems Programming (C / Low-Level / OS)

## Contexto
- C puro: algoritmos, estructuras de datos, sistemas operativos
- Bajo nivel C++: sin STL, sin RTTI, sin excepciones (embedded, game engines)
- Conceptos OS: memoria, procesos, hilos, syscalls
- Proyectos de carrera de bajo nivel

---

## C — GESTIÓN DE MEMORIA

```c
#include <stdlib.h>
#include <string.h>

// Allocación básica
int *arr = malloc(n * sizeof(int));
if (arr == NULL) { perror("malloc"); exit(EXIT_FAILURE); }

// Inicializar a cero
int *arr = calloc(n, sizeof(int));

// Redimensionar
int *new_arr = realloc(arr, new_n * sizeof(int));
if (new_arr == NULL) { free(arr); exit(EXIT_FAILURE); }
arr = new_arr;

// SIEMPRE liberar
free(arr);
arr = NULL;  // evitar dangling pointer

// Copiar memoria
memcpy(dst, src, n * sizeof(int));     // sin solapamiento
memmove(dst, src, n * sizeof(int));    // con solapamiento seguro
memset(ptr, 0, n * sizeof(int));       // llenar de ceros
```

---

## C — PATRONES DE BUG CRÍTICOS

```c
// ❌ Buffer overflow — el clásico
char buf[8];
strcpy(buf, "este string es muy largo");  // sobreescribe stack

// ✓ Usar funciones seguras
strncpy(buf, src, sizeof(buf) - 1);
buf[sizeof(buf) - 1] = '\0';
// O mejor: snprintf
snprintf(buf, sizeof(buf), "%s", src);

// ❌ Use after free
free(ptr);
printf("%d\n", ptr->value);  // undefined behavior
// ✓ Poner NULL inmediatamente tras free
free(ptr); ptr = NULL;

// ❌ Double free
free(ptr);
free(ptr);  // crash o corrupción del heap
// ✓ Verificar antes de liberar
if (ptr != NULL) { free(ptr); ptr = NULL; }

// ❌ Leer variable no inicializada
int x;           // valor indeterminado en stack
printf("%d", x); // undefined behavior
// ✓ Siempre inicializar
int x = 0;

// ❌ Signed integer overflow
int a = INT_MAX;
int b = a + 1;  // undefined behavior en C
// ✓ Usar unsigned o checked arithmetic

// ❌ Null pointer dereference
int *p = NULL;
*p = 5;  // segfault
// ✓ Verificar antes de dereferenciar
if (p != NULL) *p = 5;
```

---

## PUNTEROS — CONCEPTOS CLAVE

```c
int x = 42;
int *p = &x;      // p apunta a x
*p = 100;         // deref: modifica x a través del puntero
int **pp = &p;    // puntero a puntero

// Aritmética de punteros
int arr[5] = {0, 1, 2, 3, 4};
int *ptr = arr;
ptr++;            // avanza sizeof(int) bytes, NO 1 byte
*(ptr + 2) = 99;  // arr[3] = 99

// Puntero a función
int (*fn_ptr)(int, int) = &suma;
int result = fn_ptr(3, 4);

// void pointer (genérico)
void *generic = malloc(size);
int *typed = (int *)generic;

// const correctness
const int *p;      // puntero a int constante (no se puede modificar *p)
int * const p;     // puntero constante (no se puede modificar p)
const int * const p; // ambos constantes
```

---

## ESTRUCTURAS DE DATOS EN C

```c
// Lista enlazada
typedef struct Node {
    int data;
    struct Node *next;
} Node;

Node* create_node(int data) {
    Node *n = malloc(sizeof(Node));
    if (!n) return NULL;
    n->data = data;
    n->next = NULL;
    return n;
}

void push_front(Node **head, int data) {
    Node *n = create_node(data);
    n->next = *head;
    *head = n;
}

void free_list(Node **head) {
    Node *curr = *head;
    while (curr) {
        Node *tmp = curr->next;
        free(curr);
        curr = tmp;
    }
    *head = NULL;
}

// Stack (array-based)
#define MAX_STACK 1024
typedef struct { int data[MAX_STACK]; int top; } Stack;
void push(Stack *s, int v) { s->data[s->top++] = v; }
int  pop (Stack *s)        { return s->data[--s->top]; }
int  peek(Stack *s)        { return s->data[s->top-1]; }
```

---

## CONCURRENCIA — PTHREADS

```c
#include <pthread.h>

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_t thread;

void *worker(void *arg) {
    int id = *(int *)arg;
    pthread_mutex_lock(&lock);
    // sección crítica
    pthread_mutex_unlock(&lock);
    return NULL;
}

int main() {
    int id = 1;
    pthread_create(&thread, NULL, worker, &id);
    pthread_join(thread, NULL);    // esperar a que termine
    pthread_mutex_destroy(&lock);
}

// ❌ Race condition: dos threads modifican la misma variable sin mutex
// ❌ Deadlock: A espera B, B espera A
//    → Adquirir locks siempre en el mismo orden
// ❌ pthread_join faltante → recursos del thread no se liberan
```

---

## SYSCALLS Y OS

```c
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

// I/O de bajo nivel (sin buffering de stdio)
int fd = open("file.txt", O_RDONLY);
ssize_t n = read(fd, buf, sizeof(buf));
write(STDOUT_FILENO, buf, n);
close(fd);

// Fork / exec
pid_t pid = fork();
if (pid < 0) { perror("fork"); exit(1); }
if (pid == 0) {
    // proceso hijo
    execvp("ls", args);
    exit(1);  // solo si exec falla
} else {
    // proceso padre
    int status;
    waitpid(pid, &status, 0);
}

// Pipes
int pipefd[2];
pipe(pipefd);  // pipefd[0]=lectura, pipefd[1]=escritura
```

---

## HERRAMIENTAS DE DIAGNÓSTICO

```bash
# Valgrind — memory leaks y errores
valgrind --leak-check=full --track-origins=yes ./programa

# AddressSanitizer — build con:
gcc -fsanitize=address -g programa.c -o programa

# GDB — debugger
gdb ./programa
(gdb) run
(gdb) break main
(gdb) next / step / continue
(gdb) print variable
(gdb) backtrace

# strace — syscalls en tiempo real
strace ./programa

# size — secciones del binario
size ./programa
```

---

## DOCS

```
WebFetch: https://en.cppreference.com/w/c/[sección]
WebSearch: "C [función] man page site:man7.org"
WebFetch: https://man7.org/linux/man-pages/man2/[syscall].2.html
WebSearch: "POSIX [tema] site:pubs.opengroup.org"
```
