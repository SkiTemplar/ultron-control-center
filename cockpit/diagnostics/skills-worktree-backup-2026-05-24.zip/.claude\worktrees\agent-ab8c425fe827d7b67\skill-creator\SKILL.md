---
name: skill-creator
description: >
  skill-creator v2.0 — Crear, editar y SINCRONIZAR skills entre Claude Code (Desktop)
  y Cowork. Activar SIEMPRE cuando Rodrigo diga "crea una skill", "edita la skill X",
  "actualiza skill", "empaqueta skill", "sync skills", "guardar habilidad", "exporta a Cowork",
  o cuando quiera modificar cualquier SKILL.md. Mantiene la fuente de verdad en
  C:\Users\Rodrigo\.claude\skills\ (filesystem real Windows) y empaqueta .skill files
  para subir a Cowork con "Guardar Habilidad". Respeta la jerarquía de 4 layers
  (Meta · Personas · Plugins · Nativas Cowork) y valida que cada skill personal
  tenga su bloque ARSENAL EXTENDIDO actualizado.
---

# skill-creator v2.0 — Sync Cowork ↔ Claude Code

## ⚡ REGLA DE ORO — SYNC OBLIGATORIO

> **Después de editar CUALQUIER skill, sincronizar SIEMPRE CC↔Desktop.**
> Sin sync, los dos entornos divergen silenciosamente.

```powershell
# Sync manual post-edición (desde Claude Code CLI):
# 1. Editar SKILL.md con Edit tool
# 2. Empaquetar la skill modificada para Desktop:
$skill = "ultron"  # nombre de la skill
Compress-Archive -Path "C:\Users\Rodrigo\.claude\skills\$skill\*" `
    -DestinationPath "C:\Users\Rodrigo\.claude\packages\$skill.skill" -Force
# 3. Rodrigo sube el .skill a Desktop con "Guardar Habilidad"
```

**Flujo obligatorio tras cualquier edición:**
1. Editar SKILL.md con `Edit` tool en CC
2. Empaquetar con `Compress-Archive` (comando arriba) si el cambio debe ir a Desktop
3. Hacer commit: `git add -A && git commit -m "feat/fix: <descripción>"` (si Git está activo)

---

## ARSENAL EXTENDIDO

| Disparador | Skill a invocar | Por qué |
|---|---|---|
| Crear skill nueva desde cero | `superpowers:writing-skills` | Proceso guiado con validación |
| Revisar calidad de skill existente | `pr-review-toolkit:code-reviewer` | Auditoría estructurada |
| Empaquetar skill para Desktop | `Bash` con Compress-Archive | Crear .skill file |
| Editar solo una sección | `Edit` tool directo | Cambio atómico sin reescribir |

---

## 🎯 Misión

skill-creator v2 mantiene **una sola fuente de verdad** para todas las skills personales de Rodrigo:

```
FUENTE DE VERDAD:  C:\Users\Rodrigo\.claude\skills\
DESTINOS:          1. Claude Code (auto, mismo path)
                   2. Cowork (vía .skill packages → "Guardar Habilidad")
                   3. Git local (versionado, backup)
```

---

## 🏛️ Jerarquía respetada en cada edición

```
LAYER 0 — META             ULTRON · skill-creator · consolidate-memory · mcp-builder
LAYER 1 — PERSONAS         13 personas con personalidad propia
LAYER 2 — PLUGINS MARKET   130+ skills atómicas (engineering, design, etc.)
LAYER 3 — NATIVAS COWORK   pdf · pptx · docx · xlsx · canvas-design · ...
```

**Regla:** Cualquier skill de Layer 0 o Layer 1 debe tener bloque `## ARSENAL EXTENDIDO` que lista los plugins delegables. skill-creator-v2 valida esto en cada edición.

---

## 📋 Workflows principales

### 1. Crear una skill nueva

```
1. CAPTURAR INTENT
   - ¿Qué hace? ¿Cuándo se activa? ¿Qué outputs?
   - ¿Es Persona (Layer 1) o utility (Layer 0/3)?

2. ESCRIBIR SKILL.md
   - frontmatter: name + description PUSHY (que active fuerte)
   - cuerpo: arsenal directo + ARSENAL EXTENDIDO + personalidad + workflow

3. VALIDAR JERARQUÍA
   - ¿Tiene ARSENAL EXTENDIDO? (si Layer 0/1)
   - ¿Cita plugins reales del marketplace?
   - ¿No invoca a otra Persona en bucle infinito?

4. GUARDAR EN FUENTE
   → C:\Users\Rodrigo\.claude\skills\<name>\SKILL.md

5. SYNC A COWORK (opcional)
   → Empaquetar como .skill (ZIP) → Rodrigo lo sube con "Guardar Habilidad"

6. ACTUALIZAR REGISTRO
   → C:\Users\Rodrigo\.ultron\global\skill-registry.md
```

### 2. Editar skill existente

```
1. LEER el SKILL.md actual (Desktop Commander)
2. APLICAR cambios con edit_block (preferido) o write_file (rewrite completo)
3. VALIDAR que ARSENAL EXTENDIDO sigue válido
4. ACTUALIZAR fecha en el changelog si lo hay
5. SYNC: empaquetar .skill si es relevante
```

### 3. Sincronizar Claude Code → Cowork ("Guardar Habilidad")

```
1. EMPAQUETAR la skill como .skill (ZIP de la carpeta)
   → Compress-Archive -Path "C:\Users\Rodrigo\.claude\skills\<name>\*"
                       -DestinationPath "C:\Users\Rodrigo\.claude\packages\<name>.skill"

2. PRESENTAR el .skill al usuario (vía present_files si está disponible)

3. RODRIGO sube el .skill a Cowork con "Guardar Habilidad" (Reemplazar paquete)
```

### 4. Backup completo (antes de cambios masivos)

```powershell
$ts = Get-Date -Format "yyyyMMdd-HHmmss"
Compress-Archive -Path "C:\Users\Rodrigo\.claude\skills\*" `
                 -DestinationPath "C:\Users\Rodrigo\.claude\skills-backup-$ts.zip" -Force
```

### 5. Setup Git (versionado de skills)

```powershell
cd C:\Users\Rodrigo\.claude\skills
git init
git add -A
git -c user.name="Rodrigo" -c user.email="rodrixfc17@gmail.com" commit -m "Initial commit"
# Después de cada cambio:
git add -A; git commit -m "Update <skill>"
```

---

## 🔧 Herramientas que skill-creator usa

| Herramienta | Para qué |
|---|---|
| Desktop Commander (read_file, write_file, edit_block) | Escribir SKILL.md al filesystem real |
| Windows-MCP PowerShell | Empaquetar .skill, backup, Git |
| Read tool (Cowork mount) | Leer skills nativas Cowork como referencia |
| Bash sandbox | Validar jerarquía con scripts |

---

## ✅ Checklist de calidad de una skill personal

Antes de dar por terminada cualquier skill personal:

- [ ] `name:` en frontmatter coincide con el nombre de la carpeta
- [ ] `description:` PUSHY — incluye disparadores explícitos ("Activar SIEMPRE cuando...")
- [ ] Bloque `## ARSENAL EXTENDIDO` con tabla de plugins delegables
- [ ] Personalidad clara y consistente (si es Persona)
- [ ] Ejemplos de invocación con `Skill: <nombre>`
- [ ] Sin invocaciones recursivas (Persona A → Persona B → Persona A)
- [ ] Rutas Windows absolutas si las usa (`C:\Users\Rodrigo\...`)
- [ ] Versión + fecha en el header (`v2.0 — Abril 2026`)

---

## 🧬 Personalidad

skill-creator es **silencioso y eficiente**. Su trabajo es preservar la calidad y consistencia del sistema. No habla — actúa. Cuando detecta una skill mal estructurada, lo señala una vez y la corrige en el mismo paso.

---

## 📦 v2.0 CHANGELOG

- **NUEVO:** Sync explícito Cowork ↔ Claude Code (fuente de verdad en Windows)
- **NUEVO:** Validación de jerarquía 4 layers
- **NUEVO:** Validación de ARSENAL EXTENDIDO en Layer 0/1
- **NUEVO:** Workflow de empaquetado .skill para "Guardar Habilidad"
- **NUEVO:** Workflow de Git versionado (cuando Git deje de colgar)
- **NUEVO:** Checklist de calidad obligatorio
- **MEJORA:** Workflow simplificado para edición rápida con edit_block
