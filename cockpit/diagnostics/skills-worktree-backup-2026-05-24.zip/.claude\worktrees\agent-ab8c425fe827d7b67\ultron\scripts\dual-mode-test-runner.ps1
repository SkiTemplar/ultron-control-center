# ULTRON v8.0.1 - Dual Mode test runner
# Validates the 3 sub-modes against live Codex CLI.
# Designed to be invoked manually OR by consistency-check.py with --with-codex flag.
#
# Each test:
#   - Sends a canonical prompt
#   - Verifies Codex returns valid JSON matching the schema
#   - For Dual/Max: verifies session_id captured + resume works in round 2
#
# Costs ~3-5K Codex tokens per full run (3 invocations x ~1K tk avg).
#
# Note: ASCII-only script. Windows PowerShell 5.1 reads files without BOM as
# Windows-1252, which breaks unicode chars. Keep this file ASCII-only.

[CmdletBinding()]
param(
    [ValidateSet('Mini','Dual','Max','All')][string]$Test = 'All',
    [switch]$Quiet,
    [int]$TimeoutSec = 180
)

$ErrorActionPreference = 'Continue'
$helper = Join-Path $PSScriptRoot 'codex-duet.ps1'
$testDir = Join-Path $env:TEMP 'ultron-duet-tests'
New-Item -ItemType Directory -Force -Path $testDir | Out-Null

$results = @()

function Write-TestStatus {
    param($Name, $Status, $Detail)
    $icon = if ($Status -eq 'PASS') { '[PASS]' } elseif ($Status -eq 'SKIP') { '[SKIP]' } else { '[FAIL]' }
    Write-Host "$icon $Name :: $Status :: $Detail"
}

function Test-MiniDual {
    Write-Host ""
    Write-Host "-- Test 1: MiniDual (1 round) --------------------------------"
    $promptFile = Join-Path $testDir 'mini-prompt.txt'
    $prompt = "Reply with valid JSON only (no markdown, no thinking aloud) matching this exact shape:`n" +
              '{"round_type":"critique","verdict":"agree","critique":"MiniDual smoke test passed","suggestions":[]}'
    [System.IO.File]::WriteAllText($promptFile, $prompt, (New-Object System.Text.UTF8Encoding $false))

    $start = Get-Date
    $output = & $helper -Mode Mini -Round 1 -PromptFile $promptFile -TimeoutSec $TimeoutSec 2>&1 | ForEach-Object { "$_" }
    $elapsed = ((Get-Date) - $start).TotalSeconds

    $jsonLine = $output | Where-Object { $_ -match '^\s*\{.*"round_type".*\}\s*$' } | Select-Object -First 1
    if ($jsonLine) {
        try {
            $parsed = $jsonLine | ConvertFrom-Json
            if ($parsed.round_type -and $parsed.verdict -and $null -ne $parsed.suggestions) {
                $rounded = [math]::Round($elapsed, 1)
                Write-TestStatus 'MiniDual' 'PASS' "verdict=$($parsed.verdict), elapsed=${rounded}s"
                return @{ Test='MiniDual'; Status='PASS'; Elapsed=$elapsed }
            }
        } catch {}
    }
    $rounded = [math]::Round($elapsed, 1)
    Write-TestStatus 'MiniDual' 'FAIL' "no valid JSON in output (elapsed=${rounded}s)"
    return @{ Test='MiniDual'; Status='FAIL'; Elapsed=$elapsed }
}

function Test-Dual {
    Write-Host ""
    Write-Host "-- Test 2: Dual (2 rounds with session resume) ---------------"

    # Round 1
    $promptFile1 = Join-Path $testDir 'dual-r1-prompt.txt'
    $prompt1 = "Round 1 of Dual mode test. Critique this design and reply ONLY with valid JSON " +
               "matching the schema (round_type, verdict, critique, suggestions[]):`n`n" +
               "Design: PowerShell helper that writes prompt to temp file then invokes Node.exe " +
               "running codex.js with stdin redirected from the file. Sandbox=read-only.`n`n" +
               "Provide one concrete suggestion in the suggestions array (with priority)."
    [System.IO.File]::WriteAllText($promptFile1, $prompt1, (New-Object System.Text.UTF8Encoding $false))

    $start1 = Get-Date
    $output1 = & $helper -Mode Dual -Round 1 -PromptFile $promptFile1 -TimeoutSec $TimeoutSec 2>&1 | ForEach-Object { "$_" }
    $elapsed1 = ((Get-Date) - $start1).TotalSeconds

    # SESSION_ID extraction: prefer file written by helper (Write-Host doesn't survive 2>&1 capture)
    $sidFile = Join-Path $env:TEMP 'ultron-duet/last-session-id.txt'
    $sid = $null
    if (Test-Path $sidFile) {
        $sid = (Get-Content -Raw $sidFile).Trim()
    } else {
        $sidLine = $output1 | Where-Object { $_ -match '^SESSION_ID=' } | Select-Object -First 1
        if ($sidLine) { $sid = ($sidLine -replace '^SESSION_ID=', '').Trim() }
    }
    if (-not $sid) {
        $rounded1 = [math]::Round($elapsed1, 1)
        Write-TestStatus 'Dual round 1' 'FAIL' "no SESSION_ID captured (elapsed=${rounded1}s)"
        return @{ Test='Dual'; Status='FAIL'; Elapsed=$elapsed1; Reason='no_sid' }
    }
    $rounded1 = [math]::Round($elapsed1, 1)
    $sidShort = $sid.Substring(0, [Math]::Min(18, $sid.Length))
    Write-TestStatus 'Dual round 1' 'PASS' "SID=${sidShort}... (${rounded1}s)"

    # Round 2 (with resume)
    $promptFile2 = Join-Path $testDir 'dual-r2-prompt.txt'
    $prompt2 = "Round 2: Briefly confirm whether resuming the thread worked. Reply with JSON: " +
               "round_type=refine_response, verdict=agree, critique='resume confirmed', suggestions=[]."
    [System.IO.File]::WriteAllText($promptFile2, $prompt2, (New-Object System.Text.UTF8Encoding $false))

    $start2 = Get-Date
    $output2 = & $helper -Mode Dual -Round 2 -SessionId $sid -PromptFile $promptFile2 -TimeoutSec $TimeoutSec 2>&1 | ForEach-Object { "$_" }
    $elapsed2 = ((Get-Date) - $start2).TotalSeconds

    $jsonLine = $output2 | Where-Object { $_ -match '^\s*\{.*"round_type".*\}\s*$' } | Select-Object -First 1
    if ($jsonLine) {
        $rounded2 = [math]::Round($elapsed2, 1)
        Write-TestStatus 'Dual round 2 (resume)' 'PASS' "elapsed=${rounded2}s"
        $totalElapsed = $elapsed1 + $elapsed2
        $roundedTotal = [math]::Round($totalElapsed, 1)
        Write-TestStatus 'Dual TOTAL' 'PASS' "2 rounds in ${roundedTotal}s, resume worked"
        return @{ Test='Dual'; Status='PASS'; Elapsed=$totalElapsed; SessionId=$sid }
    }
    $rounded2 = [math]::Round($elapsed2, 1)
    Write-TestStatus 'Dual round 2 (resume)' 'FAIL' "resume returned no valid JSON (elapsed=${rounded2}s)"
    return @{ Test='Dual'; Status='FAIL'; Elapsed=($elapsed1+$elapsed2); Reason='resume_failed' }
}

function Test-MaxDual {
    Write-Host ""
    Write-Host "-- Test 3: MaxDual (single-round smoke; full 5-round run is opt-in) --"
    # MaxDual full run consumes too many tokens for routine validation.
    # The protocol itself is identical to Dual round 1 - what makes MaxDual distinct
    # is rounds 4+ (VERIFY) which we skip here. Full validation: run manually with
    # a real diff when shipping critical code.
    $promptFile = Join-Path $testDir 'maxdual-smoke-prompt.txt'
    $prompt = "MaxDual smoke (path validation only - full 5-round VERIFY is opt-in). " +
              "Reply with valid JSON: round_type=critique, verdict=agree, " +
              "critique='MaxDual path validated (full VERIFY round skipped to save tokens)', " +
              "suggestions=[]."
    [System.IO.File]::WriteAllText($promptFile, $prompt, (New-Object System.Text.UTF8Encoding $false))

    $start = Get-Date
    $output = & $helper -Mode Max -Round 1 -PromptFile $promptFile -TimeoutSec $TimeoutSec 2>&1 | ForEach-Object { "$_" }
    $elapsed = ((Get-Date) - $start).TotalSeconds

    $jsonLine = $output | Where-Object { $_ -match '^\s*\{.*"round_type".*\}\s*$' } | Select-Object -First 1
    $sidFile = Join-Path $env:TEMP 'ultron-duet/last-session-id.txt'
    $sidOk = Test-Path $sidFile
    $rounded = [math]::Round($elapsed, 1)
    if ($jsonLine -and $sidOk) {
        Write-TestStatus 'MaxDual smoke' 'PASS' "path validated, elapsed=${rounded}s"
        return @{ Test='MaxDual'; Status='PASS'; Elapsed=$elapsed; Note='full_5round_opt_in' }
    }
    Write-TestStatus 'MaxDual smoke' 'FAIL' "elapsed=${rounded}s, json=$([bool]$jsonLine), sid=$sidOk"
    return @{ Test='MaxDual'; Status='FAIL'; Elapsed=$elapsed }
}

# -- Run tests ---------------------------------------------------------------
Write-Host "================================================================"
Write-Host " ULTRON v8.0.1 - Dual Mode test runner"
Write-Host " Helper: $helper"
Write-Host " Test dir: $testDir"
Write-Host "================================================================"

if (@('All','Mini') -contains $Test) { $results += Test-MiniDual }
if (@('All','Dual') -contains $Test) { $results += Test-Dual }
if (@('All','Max')  -contains $Test) { $results += Test-MaxDual }

# -- Summary -----------------------------------------------------------------
Write-Host ""
Write-Host "================================================================"
Write-Host " SUMMARY"
Write-Host "================================================================"
$passed = ($results | Where-Object { $_.Status -eq 'PASS' }).Count
$failed = ($results | Where-Object { $_.Status -eq 'FAIL' }).Count
$total = $results.Count
$totalElapsed = 0
foreach ($r in $results) { if ($r.Elapsed) { $totalElapsed += $r.Elapsed } }
$roundedTotal = [math]::Round($totalElapsed, 1)
Write-Host " Passed: $passed / $total | Failed: $failed | Total elapsed: ${roundedTotal}s"

if ($failed -gt 0) {
    Write-Host " [FAIL] Some tests failed - see output above"
    exit 1
}
Write-Host " [PASS] All Dual Mode tests passed"
exit 0
