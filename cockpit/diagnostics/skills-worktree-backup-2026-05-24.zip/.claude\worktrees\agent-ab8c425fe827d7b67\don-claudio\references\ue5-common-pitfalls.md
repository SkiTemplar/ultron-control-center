# UE5 Common Pitfalls — Referencia Don Claudio

> Fuente: DSTN2000/claude-unreal-engine-skill · Adaptado para uso en CC

## Input System

| Problema | Causa | Solución |
|---|---|---|
| Input no responde | Enhanced Input plugin no activado | Habilitar en .uproject + "EnhancedInput" en Build.cs |
| Binding silencioso | Cast a `UInputComponent` base | Usar `Cast<UEnhancedInputComponent>` |
| Solo responde primer frame | `ETriggerEvent::Started` en movimiento | Cambiar a `ETriggerEvent::Triggered` |
| Input desaparece en vehículo | Context no cambiado | `RemoveMappingContext` + `AddMappingContext` del vehículo |

---

## Gameplay Ability System

| Problema | Causa | Solución |
|---|---|---|
| Ability no se activa | Llamada desde cliente sin server auth | Verificar que la activación viene del server |
| Atributo no replica | Falta `DOREPLIFETIME_CONDITION_NOTIFY` | Añadir en `GetLifetimeReplicatedProps` |
| Ability se queda atascada | `EndAbility()` no llamado | Llamar siempre, incluido en rutas de error |
| ASC no inicializado | `InitAbilityActorInfo()` solo en server | Llamar en ambos: server + client |

---

## Compilación y Build

| Problema | Causa | Solución |
|---|---|---|
| Unresolved external symbol | Módulo faltante en Build.cs | Añadir dependencia en `PublicDependencyModuleNames` |
| Hot reload rompe reflection | Cambios estructurales con hot reload | Cerrar editor → compilar → reabrir (no usar hot reload para headers) |
| Intermediate corrupto | Build parcialmente fallido | Borrar `Intermediate/` + `Binaries/` → reconstruir |

---

## Blueprint / C++ Integration

| Problema | Causa | Solución |
|---|---|---|
| Función C++ no visible en BP | Falta `UFUNCTION(BlueprintCallable)` | Añadir specifier |
| Clase C++ no usable en BP | Falta `UCLASS(Blueprintable)` | Añadir especificador |
| BP no ve cambios de C++ | Headers no regenerados | Tools → Refresh Visual Studio Project |

---

## Asset Management

| Problema | Causa | Solución |
|---|---|---|
| Tiempo de carga elevado | Hard references cargan todo el árbol | Usar `TSoftObjectPtr` / `TSoftClassPtr` |
| Memory bloat | Assets cargados y nunca liberados | Gestionar handles de Async Load, liberar en EndPlay |

```cpp
// MAL — hard reference, carga en startup
UPROPERTY()
UStaticMesh* MyMesh;

// BIEN — soft reference, carga bajo demanda
UPROPERTY(EditAnywhere)
TSoftObjectPtr<UStaticMesh> MyMeshSoft;
```

---

## Replication / Networking

| Problema | Causa | Solución |
|---|---|---|
| Propiedad no replica | Falta `UPROPERTY(Replicated)` + `GetLifetimeReplicatedProps` | Añadir ambos |
| RPC no ejecuta | Falta sufijo `_Implementation` | Implementar `MyRPC_Implementation()` |
| Actor no replica | `bReplicates` no activado | `bReplicates = true` en constructor |
| OnRep no dispara | `UPROPERTY(ReplicatedUsing=...)` incorrecto | Verificar nombre de función OnRep |

---

## Recovery — Proyecto Corrupto

```bash
# 1. Cerrar Unreal Editor
# 2. Borrar carpetas de build
rm -rf Intermediate/ Binaries/ .vs/ *.sln

# 3. Regenerar proyecto
# Click derecho en .uproject → "Generate Visual Studio project files"

# 4. Compilar desde cero
Build.bat [Proyecto] Win64 Development -Project="[ruta].uproject"
```

---

## Herramientas de Diagnóstico

```
stat fps                    → framerate y frame time
stat unit                   → desglose CPU/GPU/Draw
showdebug abilitysystem     → estado GAS en runtime
showdebug enhancedinput     → estado input system
Net.Reliable.Debug 1        → log de RPCs reliable
p.Chaos.DebugDraw.Enabled 1 → visualizar física Chaos
```
