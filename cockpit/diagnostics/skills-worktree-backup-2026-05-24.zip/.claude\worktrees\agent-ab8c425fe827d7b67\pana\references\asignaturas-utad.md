# PANA — Contexto Académico U-tad

## Universidad
**U-tad** — Centro Universitario de Tecnología y Arte Digital, Madrid
- **Grado:** Ingeniería Informática / Diseño de Videojuegos (verificar con Rodrigo si necesario)
- **Email Rodrigo:** rodrixfc17@gmail.com

---

## Asignaturas y Materiales

### Física (Mecánica)
- **Ruta:** `C:\Users\Rodrigo\CARRERA\investigacion\Apuntes\Física\`
- **Especialista:** `profesor-fisica` skill

| Archivo | Tema |
|---|---|
| `Tema 1. Cinemática.pdf` | Posición, velocidad, aceleración, MRU, MRUA, caída libre |
| `T1. Cinemática.Ejercicios Práctica.pdf` | Ejercicios Tema 1 |
| `Tema 2. Dinámica.pdf` | Leyes Newton, rozamiento, impulso |
| `T2. Dinámica. Ejercicios Práctica.pdf` | Ejercicios Tema 2 |
| `Tema 3. Energía y Colisiones.pdf` | Trabajo, energía, colisiones |
| `T3. Energía y Colisiones. Ejercicios Práctica.pdf` | Ejercicios Tema 3 |
| `Tema 4. Sólido Rígido.pdf` | Momento de inercia, torque, rotación |
| `T4. Sólido Rígido. Ejercicios Práctica.pdf` | Ejercicios Tema 4 |
| `Tema 5. Introducción a la Mecánica de Fluidos.pdf` | Presión, Arquímedes, Bernoulli |
| `T5. Mecánica de Fluidos. Ejercicios Práctica.pdf` | Ejercicios Tema 5 |
| `Examen Final.pdf` | Examen final |
| `Repaso. Examen Final 2024.pdf` | Material de repaso |

---

### Proyectos de Carrera (Programación)
- **Ruta general:** `C:\Users\Rodrigo\CARRERA\[Asignatura]\[Proyecto]\`
- **Especialista código:** `terry-davis` skill
- **Evaluador académico:** `repo-evaluator` (Kirkardo) skill

#### Herramientas de desarrollo conocidas
| Herramienta | Uso |
|---|---|
| CLion | C++ — Proyectos Unreal Engine |
| Rider | C# — Proyectos Unity |
| VS Code / Cursor | Web, scripts, general |
| Unity Hub | Gestión de proyectos Unity |
| Unreal Engine | UE5 — proyectos AAA |
| SmowlCM | Software de vigilancia U-tad (exámenes online) |

---

## Blackboard — Acceso a Entregas

Ver `conexiones.md` para URLs y protocolo de navegación.

### Qué extraer de Blackboard
- Fecha límite de entregas próximas
- Enunciados de ejercicios/proyectos
- Anuncios de profesores
- Notas publicadas

### Protocolo de sincronización Blackboard → Notion
```
1. Chrome MCP: navegar Blackboard → extraer entregas próximas
2. Comparar con tareas existentes en Notion
3. Crear/actualizar tareas con fecha límite y descripción
4. Crear eventos en Calendar si hay fecha concreta
```

---

## Delegación por Tipo de Tarea Académica

| Tarea | Especialista |
|---|---|
| Ejercicio de Física | `profesor-fisica` |
| Código / Bug / Commit | `terry-davis` |
| Game Dev (UE5, Unity) | `don-claude` |
| Evaluar entrega/repo | `repo-evaluator` (Kirkardo) |
| Investigación profunda | `einstein` |
| Organizar agenda de estudio | PANA directamente |
