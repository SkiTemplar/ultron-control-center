#!/usr/bin/env python3
"""
ULTRON v10.4 - Health check.

Verifies all CORE subsystems in one shot:
  - Python + Node.js + claude/gemini/codex CLIs in PATH
  - All cockpit scripts present
  - Config files exist + parse
  - Cron jobs registered
  - Game processes config
  - Pause state
  - Recent audit/usage activity
  - Disk usage of cockpit dir

Output: green check / yellow warn / red fail per item, plus summary.
Exit code: 0 if all green, 2 if any red.

Usage:
    health.py             pretty output
    health.py --json      programmatic
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

sys.path.insert(0, str(Path(__file__).parent))
from cockpit_base import COCKPIT_DIR, PROJECTS_JSON, NEWS_DIR  # noqa: E402

ULTRON_SKILL_DIR = Path.home() / ".claude" / "skills" / "ultron"
SCRIPTS_DIR = ULTRON_SKILL_DIR / "scripts" / "cockpit"
PEER_SCRIPTS = ULTRON_SKILL_DIR / "scripts"

EXPECTED_SCRIPTS = [
    # Core operations
    "ultron.ps1", "cockpit_base.py", "scan_projects.py", "launch_project.py",
    "track_activity.py", "retention.py", "should_run.py",
    # News + dashboard
    "news_scraper.py", "newsletter.py", "build_dashboard.py",
    # Schedule + standup + calendar
    "install-scheduler.ps1", "ai_standup.py", "calendar_match.py",
    # Auth
    "auth-vault.ps1", "auth_vault.py",
    # Desktop + MCP
    "desktop-shortcut.ps1", "mcp_installer.py",
    # v10.4 new
    "quick_ask.py", "usage_tracker.py", "apps_launcher.py",
    "persona_audit.py", "project_editor.py", "auto_updater.py", "health.py",
]
EXPECTED_PEER_HELPERS = ["codex-duet.ps1", "gemini-duet.ps1"]
EXPECTED_CONFIGS = ["projects.json", "apps.json", "schedule-config.json",
                    "ide-mappings.json", "mcp-catalog.json"]


class Check:
    def __init__(self, name: str, status: str, detail: str = ""):
        self.name = name
        self.status = status   # "ok", "warn", "fail"
        self.detail = detail


def check_binary(name: str) -> Check:
    path = shutil.which(name)
    if path:
        return Check(f"{name} CLI", "ok", path)
    return Check(f"{name} CLI", "fail", "not found in PATH")


def check_python_version() -> Check:
    v = sys.version_info
    if v.major == 3 and v.minor >= 10:
        return Check("Python", "ok", f"{v.major}.{v.minor}.{v.micro}")
    return Check("Python", "warn", f"{v.major}.{v.minor} (>=3.10 recommended)")


def check_scripts() -> list[Check]:
    out = []
    for name in EXPECTED_SCRIPTS:
        p = SCRIPTS_DIR / name
        if p.exists():
            out.append(Check(f"script: {name}", "ok", f"{p.stat().st_size}b"))
        else:
            out.append(Check(f"script: {name}", "fail", "missing"))
    for name in EXPECTED_PEER_HELPERS:
        p = PEER_SCRIPTS / name
        if p.exists():
            out.append(Check(f"helper: {name}", "ok", f"{p.stat().st_size}b"))
        else:
            out.append(Check(f"helper: {name}", "fail", "missing"))
    return out


def check_configs() -> list[Check]:
    out = []
    for name in EXPECTED_CONFIGS:
        p = COCKPIT_DIR / name
        if not p.exists():
            out.append(Check(f"config: {name}", "warn", "absent (will be created on use)"))
            continue
        try:
            json.loads(p.read_text(encoding="utf-8-sig"))
            out.append(Check(f"config: {name}", "ok", f"{p.stat().st_size}b valid"))
        except (json.JSONDecodeError, OSError) as e:
            out.append(Check(f"config: {name}", "fail", f"parse error: {e}"))
    return out


def check_cron_jobs() -> Check:
    """Check Windows Task Scheduler for ULTRON tasks."""
    try:
        result = subprocess.run(
            ["schtasks", "/Query", "/FO", "CSV", "/NH"],
            capture_output=True, text=True, timeout=10, encoding="utf-8",
            errors="replace",
        )
        if result.returncode != 0:
            return Check("cron jobs", "warn", "schtasks query failed")
        ultron_lines = [l for l in result.stdout.splitlines()
                        if "Ultron" in l or "ULTRON" in l]
        n = len(ultron_lines)
        if n == 0:
            return Check("cron jobs", "warn",
                         "0 tasks (run: ultron schedule install)")
        if n < 5:
            return Check("cron jobs", "warn", f"{n} tasks (expected ~7)")
        return Check("cron jobs", "ok", f"{n} ULTRON tasks scheduled")
    except (subprocess.TimeoutExpired, OSError) as e:
        return Check("cron jobs", "warn", f"check failed: {e}")


def check_pause_state() -> Check:
    pause_file = COCKPIT_DIR / "paused-until.txt"
    if not pause_file.exists():
        return Check("pause state", "ok", "not paused")
    try:
        until = datetime.fromisoformat(pause_file.read_text(encoding="utf-8").strip())
        if until > datetime.now():
            mins = int((until - datetime.now()).total_seconds() / 60)
            return Check("pause state", "warn",
                         f"paused for {mins}min more (until {until.strftime('%H:%M')})")
        return Check("pause state", "ok", "expired pause marker (will clean)")
    except (ValueError, OSError):
        return Check("pause state", "warn", "invalid marker")


def check_recent_audit() -> Check:
    audits_dir = COCKPIT_DIR / "audits"
    if not audits_dir.exists():
        return Check("recent audits", "warn", "no audits yet")
    audits = sorted(audits_dir.glob("*.md"), key=lambda p: p.stat().st_mtime,
                     reverse=True)
    if not audits:
        return Check("recent audits", "warn", "no audits yet")
    latest = audits[0]
    age_days = (datetime.now() -
                datetime.fromtimestamp(latest.stat().st_mtime)).days
    return Check("recent audits", "ok",
                 f"{len(audits)} audits, latest: {latest.stem} ({age_days}d old)")


def check_recent_usage() -> Check:
    cc_dir = Path.home() / ".claude" / "projects"
    if not cc_dir.exists():
        return Check("usage data", "warn", "no Claude Code sessions found")
    cutoff = (datetime.now() - timedelta(days=1)).timestamp()
    recent_count = 0
    for project_dir in cc_dir.iterdir():
        if not project_dir.is_dir():
            continue
        for jsonl in project_dir.glob("*.jsonl"):
            try:
                if jsonl.stat().st_mtime >= cutoff:
                    recent_count += 1
            except OSError:
                continue
    if recent_count == 0:
        return Check("usage data", "warn", "no sessions last 24h")
    return Check("usage data", "ok", f"{recent_count} active sessions (24h)")


def check_news_freshness() -> Check:
    if not NEWS_DIR.exists():
        return Check("news freshness", "warn", "no news dir")
    today_md = NEWS_DIR / f"{datetime.now().strftime('%Y-%m-%d')}.md"
    if today_md.exists():
        size = today_md.stat().st_size
        return Check("news freshness", "ok",
                     f"today's digest exists ({size}b)")
    yesterday_md = NEWS_DIR / f"{(datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')}.md"
    if yesterday_md.exists():
        return Check("news freshness", "ok",
                     "yesterday's digest exists (today's not run yet)")
    return Check("news freshness", "warn", "no recent digests")


def check_consistency() -> Check:
    """v10.5: run consistency-check.py and reflect its exit code in health.

    Avoids the 'ALL GREEN with 2 problems detected' inconsistency.
    """
    script = ULTRON_SKILL_DIR / "scripts" / "consistency-check.py"
    if not script.exists():
        return Check("consistency", "warn", "consistency-check.py missing")
    try:
        r = subprocess.run([sys.executable, str(script)],
                           capture_output=True, text=True, timeout=120,
                           encoding="utf-8", errors="replace")
        # Last line typically: '✅ Sin problemas' or '❌ N problema(s) detectado(s):'
        tail = (r.stdout or "").strip().splitlines()
        summary = ""
        for line in reversed(tail):
            if "problema" in line.lower() or "Sin problemas" in line:
                summary = line.strip()
                break
        if r.returncode == 0:
            return Check("consistency", "ok", summary or "no issues")
        return Check("consistency", "warn",
                     summary or f"exit={r.returncode} (run consistency-check)")
    except subprocess.TimeoutExpired:
        return Check("consistency", "warn", "timeout (>120s)")
    except OSError as e:
        return Check("consistency", "warn", f"failed: {e}")


def check_activity_coverage() -> Check:
    """v10.5: warn if activity tracker coverage <60% over last 12h.

    Coverage = entries / expected_at_10min_cadence. Idle entries (v10.5+)
    count toward coverage, so this flags the tracker actively malfunctioning."""
    activity = COCKPIT_DIR / "activity.jsonl"
    if not activity.exists():
        return Check("activity coverage", "warn", "no activity log yet")
    try:
        cutoff = datetime.now() - timedelta(hours=12)
        count = 0
        for line in activity.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                ts = datetime.fromisoformat(json.loads(line).get("ts", ""))
                if ts >= cutoff:
                    count += 1
            except (ValueError, json.JSONDecodeError):
                continue
        # 12h * 6/h = 72 expected; tolerate 50% (assume PC off some hours)
        expected_min = 36
        if count == 0:
            return Check("activity coverage", "warn",
                         "0 entries in 12h (tracker may be off)")
        if count < expected_min:
            return Check("activity coverage", "warn",
                         f"{count} entries / 12h (expected ≥{expected_min})")
        return Check("activity coverage", "ok",
                     f"{count} entries last 12h")
    except OSError as e:
        return Check("activity coverage", "warn", f"read failed: {e}")


def check_pending_proposals() -> Check:
    """v10.5: surface pending L2 proposals so they don't sit unread."""
    proposals_dir = COCKPIT_DIR / "proposals"
    if not proposals_dir.exists():
        return Check("pending proposals", "ok", "none")
    pending = []
    for f in proposals_dir.glob("*.json"):
        if f.stem.endswith(".applied"):
            continue
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            if data.get("status") == "consumed":
                continue
            n = sum(1 for p in data.get("proposals", [])
                    if p.get("old_string")
                    and p.get("false_positive_risk") in (None, "none", "low"))
            if n > 0:
                pending.append((f.stem, n))
        except (OSError, json.JSONDecodeError):
            continue
    if not pending:
        return Check("pending proposals", "ok", "none")
    total = sum(n for _, n in pending)
    return Check("pending proposals", "warn",
                 f"{len(pending)} file(s), {total} actionable "
                 f"(run: ultron updater apply-auto)")


def check_disk_usage() -> Check:
    if not COCKPIT_DIR.exists():
        return Check("disk usage", "warn", "cockpit dir missing")
    total = 0
    file_count = 0
    for p in COCKPIT_DIR.rglob("*"):
        if p.is_file():
            try:
                total += p.stat().st_size
                file_count += 1
            except OSError:
                continue
    mb = total / (1024 * 1024)
    if mb > 100:
        return Check("disk usage", "warn",
                     f"{mb:.1f}MB / {file_count} files (consider retention)")
    return Check("disk usage", "ok", f"{mb:.1f}MB / {file_count} files")


def run_all_checks() -> list[Check]:
    out = []
    out.append(check_python_version())
    out.append(check_binary("node"))
    out.append(check_binary("claude"))
    out.append(check_binary("gemini"))
    out.append(check_binary("codex"))
    out.extend(check_scripts())
    out.extend(check_configs())
    out.append(check_cron_jobs())
    out.append(check_pause_state())
    out.append(check_recent_audit())
    out.append(check_recent_usage())
    out.append(check_news_freshness())
    out.append(check_activity_coverage())
    out.append(check_pending_proposals())
    out.append(check_consistency())
    out.append(check_disk_usage())
    return out


def render_pretty(checks: list[Check]) -> int:
    icons = {"ok": "[OK]  ", "warn": "[WARN]", "fail": "[FAIL]"}
    n_ok = sum(1 for c in checks if c.status == "ok")
    n_warn = sum(1 for c in checks if c.status == "warn")
    n_fail = sum(1 for c in checks if c.status == "fail")

    print()
    print("ULTRON CORE Health Check")
    print("=" * 60)
    # Group output: binaries first, then scripts, then configs, then runtime
    for c in checks:
        icon = icons.get(c.status, "?")
        print(f"  {icon} {c.name:<32} {c.detail}")
    print()
    print(f"Summary: {n_ok} OK · {n_warn} warnings · {n_fail} failures")
    if n_fail > 0:
        print("Status: FAIL — investigate red items above")
        return 2
    if n_warn > 0:
        print("Status: OK with warnings — system functional")
        return 0
    print("Status: ALL GREEN")
    return 0


def main():
    p = argparse.ArgumentParser(description="ULTRON CORE health check")
    p.add_argument("--json", action="store_true", help="JSON output")
    args = p.parse_args()
    checks = run_all_checks()

    if args.json:
        print(json.dumps([{"name": c.name, "status": c.status, "detail": c.detail}
                          for c in checks], indent=2))
        return 0
    return render_pretty(checks)


if __name__ == "__main__":
    sys.exit(main())
