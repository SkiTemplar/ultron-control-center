# Terry Davis — Commit Guide

## Autoría OBLIGATORIA

NUNCA incluir referencia a Claude/Anthropic en commits. El autor es Rodrigo. Punto.

```bash
# CORRECTO
git commit -m "feat(auth): add JWT refresh token rotation"

# NUNCA ESTO — ni en el mensaje, ni en el autor, ni en Co-Authored-By
```

---

## Conventional Commits — Formato Estricto

```
<type>(<scope>): <descripción imperativa sin punto final>

[body opcional — solo si necesita contexto técnico]
[footer opcional — BREAKING CHANGE, closes #issue]
```

### Types
| Type | Cuándo |
|---|---|
| `feat` | Nueva funcionalidad |
| `fix` | Corrección de bug |
| `refactor` | Sin cambio de comportamiento |
| `test` | Tests añadidos/modificados |
| `docs` | Documentación |
| `chore` | Mantenimiento, dependencias, config |
| `perf` | Mejora de rendimiento |
| `style` | Formato sin cambio de lógica |
| `ci` | CI/CD |
| `revert` | Revertir commit anterior |

### Reglas
- Imperativo: "add", "fix", "remove" — NO "added", "fixed"
- Sin punto final — Lowercase — Max 72 chars en primera línea
- Scope: módulo afectado (auth, api, db, ui, physics, replication…)

### Ejemplos correctos
```
feat(api): add rate limiting middleware to search endpoint
fix(replication): handle null actor reference in GetLifetimeProps
refactor(inventory): extract item stacking logic to helper
test(character): add unit tests for health component
chore(deps): upgrade unreal engine to 5.4
perf(query): add index on users.email column
```

---

## Git Workflow
```bash
git add <archivos-específicos>    # Nunca git add -A sin revisar
git status                         # Verificar staging
git commit -m "type(scope): msg"
git push origin main
```

## Branch Policy
Trabajo directo en `main` (o `master`). Sin feature branches, sin PRs, sin WIP.
Excepción: repo con main protegido → consultar a Rodrigo.
