# Terry Davis — Bug Patterns (Resumen Rápido)

Patrones frecuentes en proyectos de Rodrigo. Para detalle por dominio ver los reference files específicos.

---

## NODE.JS / EXPRESS
- Promise sin `await` → devuelve Promise, no datos
- `res.json()` sin `return` → "Cannot set headers after sent"
- Middleware de auth colocado después de la ruta
- `forEach` con `async/await` → no espera (usar `for...of` o `Promise.all`)
- Refresh token sin rotación → replay attacks
- MongoDB `findOne` sin null-check en resultado

## C++ / UE5
- Raw pointer sin `UPROPERTY()` → destruido por GC silenciosamente
- Variable replicada sin `GetLifetimeReplicatedProps` → nunca se replica
- RPC de cliente sin flag `Server` → no ejecuta en servidor
- `Cast<>()` sin null-check en resultado → nullptr silencioso
- `NewObject<>` sin outer válido → GC inmediato

## C# / UNITY
- `GetComponent<>()` sin null-check → NullReferenceException
- Mover Rigidbody con `transform.position` → saltea física
- Coroutine en objeto inactivo → no ejecuta silenciosamente
- `FindObjectOfType<>()` en Update → O(n) cada frame
- `StartCoroutine` sin guardar referencia → no se puede detener

## PYTHON
- Default mutable argument `def f(lst=[])` → estado compartido entre calls
- Path relativo → falla según directorio de ejecución
- File sin `with` → no se cierra en excepción
- `except:` bare → oculta KeyboardInterrupt y SystemExit

## GENÉRICOS
- Error silenciado: `catch(e) {}` vacío
- Config hardcodeada: credenciales en código
- Input sin sanitizar: datos de usuario usados directamente
- Race condition: estado compartido en async sin lock
- Memory leak: event listeners sin removeEventListener
