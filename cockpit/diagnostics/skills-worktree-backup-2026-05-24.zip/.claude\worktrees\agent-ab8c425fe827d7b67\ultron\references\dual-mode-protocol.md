# ULTRON — DUAL MODE PROTOCOL · v1.0
## Codex Inclusion via DUET Pattern

> **Introducido en:** ULTRON v8.0.0 "Dual Mode" (2026-04-27)
> **Backend:** OpenAI Codex CLI (`codex exec`) — `gpt-5.5` por defecto, fallback `gpt-5.4-codex` en auth error
> **Sandbox:** SIEMPRE `read-only`. Codex JAMÁS escribe en filesystem. Si propone cambio → lo escribe Claude.
> **Objetivo:** segundo modelo como peer continuo durante el flujo, complementando `second-opinion` (review final).

---

## 🤝 Los 3 sub-modos

| Sub-modo | Rounds default | Cap configurable | Output max | Disponible en | Caso de uso |
|---|---|---|---|---|---|
| **MiniDual** | **1** (CRITIQUE solo) | No — siempre 1 | ~500 tk | MEDIUM (trigger), HIGH, ULTRA | sanity check rápido · "¿este patrón es estándar?" · "¿esta API existe?" |
| **Dual** | **3** (PROPOSE→CRITIQUE→REFINE) | Sí: `/dual --rounds=N` (1-5) | ~2K tk | HIGH (trigger), ULTRA | feature nueva · refactor con dudas · decisión de diseño |
| **MaxDual** | **5** (incluye VERIFY del diff + REFINE-2) | Sí: `/maxdual --rounds=N` (3-8) | ~5K tk | **ULTRA siempre** · HIGH solo bajo trigger explícito de Rodrigo | arquitectura crítica · código a producción · diseñar el propio ULTRON |

**Hard rules:**
- LOW → DUAL **prohibido**. Mensaje: *"Dual no disponible en LOW. ¿Subo a MEDIUM?"*
- MEDIUM → solo MiniDual y solo con trigger explícito (`/minidual`)
- HIGH → MiniDual auto-disponible, Dual con trigger, MaxDual solo si Rodrigo lo pide
- ULTRA → cualquiera; MaxDual recomendado en `/contrast --dual`

---

## 🔁 Protocolo round por round

### MiniDual (1 round)

```
[ROUND 1: CRITIQUE]
  Claude → prompt compactado (≤500 tk input):
    "Pregunta concreta sobre [tema]. Contexto mínimo: [3-5 líneas].
     Devuelve veredicto + crítica corta + 1-2 sugerencias."
  Codex → JSON estructurado (verdict + critique + suggestions)
  Claude → integra, reporta a Rodrigo: "[MiniDual] Codex dice: [verdict]. Aplicando: [decisión]"
```

### Dual (3 rounds default)

```
[ROUND 1: PROPOSE]
  Claude (interno) → formula propuesta inicial
  Claude → prompt round 1 a Codex (≤1500 tk input):
    "Problema: [descripción]
     Mi propuesta: [solución]
     Restricciones: [stack, convenciones, edge cases conocidos]
     Critica esta propuesta. Veredicto + concerns + alternativas."
  Codex → JSON (verdict + critique + suggestions)
  Captura SESSION_ID del primer event JSONL.

[ROUND 2: REFINE]
  Claude → integra crítica de Codex, refina propuesta
  Claude → ejecuta cambios en filesystem (Write/Edit)
  Claude → prompt round 2 a Codex (resume SESSION_ID, ≤500 tk):
    "He aplicado: [diff resumen]. ¿Algún concern restante?"
  Codex → JSON (verdict final)

[ROUND 3: opcional CONFIRM]
  Solo si Codex en round 2 marcó "concerns" o "disagree"
  Sin "concerns" → cerrar en round 2.
```

### MaxDual (5 rounds default)

```
[ROUND 1: PROPOSE]      — igual que Dual
[ROUND 2: CRITIQUE-DEEP]
  Claude envía contexto rico (≤3K tk): archivo entero + dependencias + historial relevante
  Codex devuelve crítica profunda + alternativas arquitectónicas

[ROUND 3: REFINE]       — Claude integra y ejecuta
[ROUND 4: VERIFY]
  Claude → resume SESSION_ID, envía diff real:
    "Diff aplicado: [contenido git diff]. Verifica correctness."
  Codex → veredicto sobre diff + bugs/issues nuevos detectados
[ROUND 5: REFINE-2]     — solo si VERIFY marcó issues nuevos
```

---

## 🚀 Activación — triggers

| Vía | Trigger | Sub-modo activado | Notas |
|---|---|---|---|
| Explícita simple | `/minidual` · `/dual` · `/maxdual` | el indicado | Validar gating según modo activo |
| Override rondas | `/dual --rounds=N` | Dual con N rondas (1-5) | `--rounds=N` válido para Dual y MaxDual |
| Auto en CONTRAST | `/contrast --dual` | Dual (Codex hace FASE 4 DEVIL externo) | Reemplaza el devil's advocate interno de Claude |
| Auto en BREAK-GLASS | sin cambios — `second-opinion` ya cubre | n/a | No duplicar |
| Auto en ULTRA + arquitectura sin precedente | sugerir MaxDual a Rodrigo | MaxDual con confirmación | Opcional, no obligatorio |

**Override de gating:** si Rodrigo dice explícitamente *"usa MaxDual aunque sea HIGH"* → respetar y notificar el override en el log de sesión.

---

## ⚙️ Backend técnico — invocación Codex CLI

### Comando base (round 1 de Dual/MaxDual, o único de MiniDual)

```bash
"C:/Users/Rodrigo/AppData/Roaming/npm/codex.cmd" exec \
  --sandbox read-only \
  -m gpt-5.5 \
  --output-schema "C:/Users/Rodrigo/.claude/skills/ultron/references/codex-duet-schema.json" \
  -o "$output_file" \
  --json \
  - < "$prompt_file"
```

- `--ephemeral` se añade SOLO en MiniDual (no necesita resume)
- `--json` produce JSONL en stdout — del primer event extraer `session_id` para rounds 2+
- `-o` captura solo el último mensaje (JSON validado por schema)
- Se pasa el prompt vía stdin con `-` para evitar problemas de quoting

### Comando rounds 2+ (Dual/MaxDual con resume)

```bash
"C:/Users/Rodrigo/AppData/Roaming/npm/codex.cmd" exec resume "$session_id" \
  --sandbox read-only \
  -m gpt-5.5 \
  --output-schema "...codex-duet-schema.json" \
  -o "$output_file" \
  --json \
  - < "$prompt_file"
```

→ thread mantenido en Codex side. **No reenviar contexto previo.** Solo el delta del round actual.

### Helper PowerShell

Usar siempre `scripts/codex-duet.ps1` para invocar — abstrae path absoluto, fallback de modelo, parseo JSON, captura de session_id, reporte de tokens.

```powershell
& "C:\Users\Rodrigo\.claude\skills\ultron\scripts\codex-duet.ps1" `
    -Mode Dual -Round 1 -PromptFile "$env:TEMP\round1.md"
# → output a stdout: JSON parseado + linea "SESSION_ID=..."
```

---

## 📊 Reporte por round

Cada llamada a Codex emite a Rodrigo:

```
[Dual round 2/3] Codex consumido — input ~1.2K tk, output ~340 tk
                veredicto: concerns
                critique: "El locking aquí puede dar deadlock si X..."
                aplicando: refactor del lock pattern antes de continuar
```

**Token tracking acumulado por sesión** — en `~/.claude/projects/<proj>/memory/dual-session-log.md` (append-only).

---

## 🛡️ Reglas inamovibles

1. **Codex JAMÁS escribe** — sandbox `read-only` siempre. Si por error se omite el flag, abortar.
2. **Claude tiene la última palabra** — Codex sugiere, Claude decide e implementa.
3. **Codex no ve memoria persistente de ULTRON** — no se le pasan los archivos `MEMORY.md` ni `PROJECT.md`. Solo el contexto del problema concreto.
4. **Hard cap por sesión:**
   - MiniDual: ilimitado (cada llamada es 1 round)
   - Dual: 3 invocaciones por sesión sin permiso explícito de Rodrigo (4ª → preguntar)
   - MaxDual: 1 invocación por sesión sin permiso explícito (2ª → preguntar)
5. **Si Codex retorna error de auth** → reintento solo si el llamador pasó `-FallbackModel` explícito al helper. **Default del helper es `FallbackModel=''` (sin fallback automático)** porque con auth ChatGPT (suscripción) `gpt-5.4-codex` no está disponible — solo `gpt-5.5`. Solo se aplica fallback automático si tienes `OPENAI_API_KEY` configurada y pasas `-FallbackModel "gpt-5.4-codex"` al invocar `codex-duet.ps1`. Sin fallback, un auth error → abortar y notificar a Rodrigo (`codex login` puede haber expirado).
6. **No usar Codex para decisiones de negocio, físicas, financieras o narrativas** — solo dominios técnicos (código, arquitectura, debugging). Para los otros dominios, las personas (warren, jordan-belfort, profesor-fisica, tolkien) son autoritativas.

---

## 🔗 Integración con sistema existente

| Componente | Relación con Dual Mode |
|---|---|
| `second-opinion` skill | **Intacta.** Se reusa en MaxDual round 4 VERIFY si está disponible (preferida sobre invocación directa). |
| `/contrast` overlay | FASE 4 DEVIL puede delegarse a Codex con flag `/contrast --dual`. Sin flag → comportamiento original (Claude juega devil). |
| `BREAK-GLASS` protocol | Sin cambios — sigue usando `second-opinion`. Dual Mode es para iteración durante el flujo, no para escalada de bloqueo. |
| Personas (14) | No se afectan. Las personas pueden invocar Dual Mode si el modo activo lo permite y la tarea es técnica. |
| Knowledge layer | No se afecta. Codex no lee el knowledge — Claude sí. Si Codex sugiere algo que contradice knowledge curado, Claude prevalece y reporta. |
| Hooks | No se afectan. `block-dangerous-bash.py` revisa la invocación a `codex.cmd` como cualquier otro Bash. |

---

## 🧪 Smoke test (post-deploy)

```powershell
& "C:\Users\Rodrigo\.claude\skills\ultron\scripts\codex-duet.ps1" `
    -Mode Mini -Round 1 -Prompt "Reply with JSON: {verdict:'agree',critique:'smoke test ok',suggestions:[]}"
# → debe devolver JSON válido en <15s
```

Si el smoke test falla:
1. Verificar `codex --version` (debe ser ≥0.125.0)
2. Verificar `codex login` (debe estar logueado con ChatGPT)
3. Verificar acceso a gpt-5.5 (puede requerir suscripción ChatGPT activa)
4. Fallback temporal: `-m gpt-5.4-codex`

---

## 📈 Roadmap

- **v8.0.0** ✅ — Dual Mode lanzado: 3 sub-modos, helper PowerShell, schema JSON, smoke test
- **v8.0.1** ✅ — Hardening: refactor Start-Process, 7 gotchas catalogados, test runner live, --with-codex flag
- **v8.1.0** ✅ — **MCP nativo + Pester tests:**
  - `codex mcp-server` registrado en `~/.claude/settings.json` con sandbox=read-only y model=gpt-5.5
  - Codex disponible como tool MCP nativo (`mcp__codex__*`) además del helper PowerShell legacy
  - 15 Pester unit tests en `tests/codex-duet.Tests.ps1` validan helper sin invocar Codex (~1s, 0 tokens)
  - consistency-check.py extendido con check #12 (MCP registration) y #13 (Pester tests)
- **v8.2.0** (próximo) — caching de respuestas Codex por hash de prompt → no repetir queries idénticas en una sesión.
- **v8.3.0** — Gemini como tercer modelo opcional bajo `/triad` (Claude + Codex + Gemini).
