# Terry Davis — C# / Unity

## Entorno de Rodrigo
- **IDE:** Rider (JetBrains) para C# / Unity
- **Engine:** Unity (versiones recientes, Unity Hub)
- **Multiplayer:** Netcode for GameObjects (NGO) o Fusion
- **Rutas:** `C:\Users\Rodrigo\CARRERA\` y `C:\Users\Rodrigo\Documents\`

---

## UNITY LIFECYCLE — ORDEN DE EJECUCIÓN

```
Awake() → OnEnable() → Start() → FixedUpdate() → Update()
→ LateUpdate() → OnDisable() → OnDestroy()

Awake:  inicializar referencias internas (self-contained)
Start:  inicializar dependencias externas (otras scripts ya awakeadas)
FixedUpdate: física (50 veces/seg por defecto)
Update: input, lógica (frame-rate dependiente)
LateUpdate: cámara, IK (después de todos los Updates)
```

---

## PATRONES DE BUG — UNITY C#

```csharp
// ❌ GetComponent sin null-check
void Start() {
    rb = GetComponent<Rigidbody>(); // puede ser null si falta el componente
    rb.AddForce(Vector3.up);        // NullReferenceException
}
// ✓
void Start() {
    rb = GetComponent<Rigidbody>();
    if (rb == null) { Debug.LogError($"Rigidbody missing on {gameObject.name}"); return; }
}

// ❌ Mover Rigidbody con transform.position
void Update() {
    transform.position += Vector3.right * speed * Time.deltaTime; // saltea física
}
// ✓
void FixedUpdate() {
    rb.MovePosition(rb.position + Vector3.right * speed * Time.fixedDeltaTime);
}

// ❌ FindObjectOfType en Update (extremadamente lento)
void Update() {
    var player = FindObjectOfType<PlayerController>(); // O(n) cada frame
}
// ✓ cachear en Awake/Start
```

---

## COROUTINES — GOTCHAS

```csharp
// ❌ Coroutine sin condición de salida
IEnumerator BadLoop() {
    while (true) { yield return null; } // loop infinito, cuelga el juego
}

// ❌ StartCoroutine en objeto inactivo
gameObject.SetActive(false);
StartCoroutine(MyRoutine()); // silently does nothing

// ✓ Patrón correcto con cancelación
private Coroutine _activeRoutine;
void StartMyRoutine() {
    if (_activeRoutine != null) StopCoroutine(_activeRoutine);
    _activeRoutine = StartCoroutine(MyRoutine());
}
IEnumerator MyRoutine() {
    while (_isActive) {
        // lógica
        yield return new WaitForSeconds(0.1f);
    }
}
```
