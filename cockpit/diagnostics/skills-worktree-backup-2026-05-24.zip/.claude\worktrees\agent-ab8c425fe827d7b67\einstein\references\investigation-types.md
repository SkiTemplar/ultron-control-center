# Einstein — Protocolos por Tipo de Investigación (v3.0)

---

## A) EXPLICAR UN CONCEPTO

*"¿Cómo funciona X?", "¿Qué es X?", "Explícame X"*

```
1. Identificar disciplina y nivel de complejidad pedido
2. Construir explicación en 3 capas:
   - Capa intuitiva: analogía o ejemplo cotidiano
   - Capa técnica: definición precisa + fórmulas si aplica
   - Capa profunda: mecanismo subyacente + preguntas abiertas
3. Si el concepto tiene apuntes locales → leer con Desktop Commander primero
4. Si hay simulación PhET relevante → mencionarla
5. Conectar con otros conceptos que Rodrigo ya conoce
```

**Formato de salida:**
- Concepto en una línea
- Explicación intuitiva (1-2 párrafos)
- Fórmulas/estructura técnica si aplica
- Ejemplo concreto
- Conexiones con otros temas

---

## B) INVESTIGACIÓN PROFUNDA

*"Investiga sobre X", "Busca información sobre X", "Dame contexto sobre X"*

```
1. WebSearch amplio: [tema] + [subtemas relevantes]
2. Identificar 3-5 fuentes de calidad (ver research-sources.md)
3. WebFetch a cada fuente → leer contenido real
4. Sintetizar: qué se sabe, qué está en debate, qué falta
5. Si hay papers relevantes: leer abstract + conclusiones
6. Guardar en Notion si la investigación es sustancial
```

**Estructura del output:**
- Resumen ejecutivo (3-5 líneas)
- Contexto histórico/origen
- Estado actual del conocimiento
- Debates abiertos / fronteras del campo
- Fuentes utilizadas

---

## C) BÚSQUEDA DE PAPERS

*"Busca papers sobre X", "¿Qué dice la literatura sobre X?"*

```
1. Identificar la disciplina → elegir la base correcta:
   - Física/Matemáticas → arXiv
   - Biología/Medicina → PubMed
   - Humanidades/Historia → JSTOR
   - CS/IA → arXiv, Papers With Code
   - Psicología → APA PsycNet, PubMed
   - Economía → NBER, JSTOR
2. WebSearch: "[tema] site:[base correcta]"
3. Para cada paper relevante: extraer conclusiones clave
4. Ordenar por relevancia + año
5. Priorizar reviews y meta-análisis si hay demasiados
```

**Formato de salida:**
- Lista: título, autores, año, journal/fuente, resumen 2 líneas
- Síntesis del estado del campo en 1 párrafo

---

## D) ASTRONOMÍA / COSMOLOGÍA

*"¿Qué tan lejos está X?", "¿Cómo se formó X?", "¿Qué es una estrella de neutrones?"*

```
1. WebSearch: "[objeto/fenómeno] site:nasa.gov" O site:esa.int
2. Para objetos específicos: Simbad → datos precisos
3. Para cálculos (distancias, luminosidades): Wolfram Alpha
4. Para papers recientes: arXiv astro-ph
5. Mencionar la escala: poner los números en perspectiva humana
6. Si es observable → indicar cuándo/cómo verlo
```

---

## E) GEOLOGÍA / CIENCIAS DE LA TIERRA

*"¿Cómo se forma X?", "¿Por qué hay terremotos en X?", "¿Qué era este lugar hace 50 millones de años?"*

```
1. WebSearch: "[fenómeno/proceso] site:usgs.gov"
2. Para minerales/rocas: Mindat
3. Para vulcanología: Smithsonian Global Volcanism Program
4. Para paleontología: UCMP Berkeley + artículos Nature Geoscience
5. Contextualizar en la escala geológica del tiempo
6. Conectar con tectónica de placas cuando sea relevante
```

---

## F) HISTORIA E INVESTIGACIÓN CULTURAL

*"¿Qué pasó con X?", "Historia de X", "¿Por qué cayó X?"*

```
1. Britannica → contexto general fiable
2. World History Encyclopedia → artículos académicos accesibles
3. JSTOR → si se necesita profundidad académica
4. Documentos primarios: Avalon Project (Yale) / Internet Archive
5. Distinguir causas próximas vs causas estructurales
6. Evitar el presentismo: contextualizar en su época
7. Señalar debates historiográficos cuando existan
```

---

## G) EXPERIMENTO MENTAL / EXPLORACIÓN FILOSÓFICA

*"¿Qué pasaría si...?", "¿Por qué X tiene que ser así?", "Conecta X con Y"*

```
1. NO buscar inmediatamente — pensar primero
2. Identificar los supuestos de la pregunta
3. Explorar consecuencias lógicas paso a paso
4. Buscar si algún pensador/científico ya exploró esto
5. WebSearch: "[pregunta/hipótesis] philosophy site:plato.stanford.edu"
6. Presentar múltiples perspectivas si las hay
7. Distinguir claramente especulación de conocimiento establecido
```

---

## H) ANÁLISIS DE DATOS

*"Analiza estos datos", "¿Qué patrones hay en X?", "Visualiza esto"*

```
1. Entender qué representa el dataset
2. data:explore-data → perfil básico
3. data:statistical-analysis → patrones, correlaciones, outliers
4. data:create-viz → visualización con Python/matplotlib
5. Interpretar: ¿qué dicen los datos? ¿qué NO dicen?
6. Guardar resultados en Notion si son relevantes
```

---

## I) APOYO ACADÉMICO

*"Prepárame para el examen de X", "No entiendo Y del tema Z"*

```
1. Para Física → delegar a profesor-fisica (especialista)
2. Para CS / programación → delegar a terry-davis (código)
3. Para contexto histórico o filosófico de una disciplina → Einstein directamente
4. Para papers o investigación de un tema del curso → Einstein directamente
5. Para el resto de ciencias (Química, Bio, Geo, Historia...) → Einstein directamente
```

---

## J) COMPARACIÓN DE ENFOQUES / TECNOLOGÍAS

*"¿Es mejor X o Y?", "¿Cuáles son las diferencias entre X e Y?"*

```
1. Definir criterios de comparación relevantes para la disciplina
2. Buscar benchmarks o estudios comparativos si aplica
3. Leer fuentes de ambos lados
4. Presentar como tabla comparativa + recomendación contextualizada
5. Señalar en qué contextos gana cada opción
```

---

## SEÑALES DE INVESTIGACIÓN DE CALIDAD

✓ Fuente primaria o peer-reviewed
✓ Fecha reciente (o clásico establecido)
✓ Consenso verificado en múltiples fuentes
✓ Distinción clara entre hechos e interpretaciones
✓ Cita las limitaciones del estudio

⚠ Señales de alarma:
- "Estudios demuestran que..." sin citar el estudio
- Una sola fuente para afirmación polémica
- Artículo de divulgación sin enlace al paper original
- Datos sin metodología visible
