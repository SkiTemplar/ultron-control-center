# Terry Davis — Search Tactics

Regla: fuente primaria > Stack Overflow > Reddit. Específico con versión y error exacto.

---

## POR TECNOLOGÍA

| Tech | Fuente primaria | Búsqueda |
|---|---|---|
| Node.js | nodejs.org/api/ | `[error] site:nodejs.org` |
| TypeScript | typescriptlang.org/docs | `TS[código] typescript` |
| React / Next.js | react.dev / nextjs.org/docs | `[hook] site:react.dev` |
| MongoDB/Mongoose | mongoosejs.com/docs | `mongoose [versión] [problema]` |
| C++ / UE5 | dev.epicgames.com/documentation | `UE5 [clase] site:dev.epicgames.com` |
| C# / Unity | docs.unity3d.com/ScriptReference | `unity [clase] site:docs.unity3d.com` |
| Python | docs.python.org/3/library/ | `python [módulo] [función]` |
| PowerShell | learn.microsoft.com/powershell | `powershell [cmd] site:learn.microsoft.com` |
| Bash | man7.org/linux/man-pages | `bash [función] site:tldp.org` |
| HLSL/DirectX | learn.microsoft.com/direct3dhlsl | `HLSL [función] site:learn.microsoft.com` |
| C / POSIX | man7.org / cppreference.com | `C [función] man page site:man7.org` |

---

## GITHUB ISSUES — Para bugs de librerías

```
WebSearch: "[lib] [síntoma] is:issue site:github.com"
```
Si el issue está cerrado con fix → ver PR asociado para entender el cambio.

---

## STACK OVERFLOW — Solo como referencia, verificar siempre

Señales de respuesta mala: sin explicación del porqué, sin votos, >3 años de antigüedad,
"funciona en mi máquina", código con deprecation warnings.
