#!/usr/bin/env python3
"""
ULTRON v10.0 Cockpit - Dashboard auto-generator.

Reads:
  - ~/.ultron/cockpit/projects.json
  - ~/.ultron/cockpit/activity.jsonl
  - ~/.ultron/cockpit/deadlines.json (if exists)
  - ~/.ultron/cockpit/auth-vault.dpapi (metadata only)
  - ~/.ultron/cockpit/news/ALERTS.md (head only)

Writes:
  - ~/.ultron/cockpit/DASHBOARD.md   (single file, regenerable)

Designed to run hourly via Task Scheduler. Idempotent.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

sys.path.insert(0, str(Path(__file__).parent))
from cockpit_base import (  # noqa: E402
    Cockpit, COCKPIT_DIR, PROJECTS_JSON, ACTIVITY_JSONL,
    DEADLINES_JSON, AUTH_VAULT, NEWS_ALERTS, NEWS_DIR,
)


DASHBOARD_PATH = COCKPIT_DIR / "DASHBOARD.md"


# ── Helpers ──────────────────────────────────────────────────────────────────

def load_projects() -> list[dict]:
    return Cockpit.read_json(PROJECTS_JSON, default={"projects": []}).get("projects", [])


def load_activity(days: int = 7) -> list[dict]:
    if not ACTIVITY_JSONL.exists():
        return []
    cutoff = datetime.now() - timedelta(days=days)
    out = []
    for line in ACTIVITY_JSONL.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            entry = json.loads(line)
            ts = datetime.fromisoformat(entry.get("ts", ""))
            if ts >= cutoff:
                out.append(entry)
        except (ValueError, json.JSONDecodeError):
            continue
    return out


def load_deadlines() -> dict:
    return Cockpit.read_json(DEADLINES_JSON, default={"matches": []})


def load_vault_summary() -> dict:
    """Return {service: {active, profile_count}} without decrypting blobs."""
    if not AUTH_VAULT.exists():
        return {}
    try:
        data = json.loads(AUTH_VAULT.read_text(encoding="utf-8-sig"))
        out = {}
        for svc, svc_data in (data.get("services") or {}).items():
            out[svc] = {
                "active": svc_data.get("active") or "(none)",
                "profile_count": len(svc_data.get("profiles") or {}),
            }
        return out
    except Exception:
        return {}


def latest_news_path() -> Path | None:
    if not NEWS_DIR.exists():
        return None
    files = sorted(NEWS_DIR.glob("20*.md"), reverse=True)
    return files[0] if files else None


def alerts_head(max_lines: int = 30) -> list[str]:
    if not NEWS_ALERTS.exists():
        return []
    return NEWS_ALERTS.read_text(encoding="utf-8").splitlines()[:max_lines]


# ── Sections ─────────────────────────────────────────────────────────────────

def section_header() -> list[str]:
    now = datetime.now().isoformat(timespec="seconds")
    return [
        "# ULTRON Cockpit Dashboard",
        "",
        f"_Auto-generated {now}. Edit nothing here - it's regenerated hourly._",
        "",
    ]


def section_projects(projects: list[dict], activity: list[dict]) -> list[str]:
    """Top active projects with last_active + activity count last 7d."""
    counts = Counter(e.get("project_id") for e in activity if e.get("project_id"))
    active = [p for p in projects if p.get("status") in ("active", "auto-detected")]

    def last_active_or_min(p):
        return p.get("last_active") or "0000-00-00"

    # Show top 10 by latest mtime, weighted slightly by recent activity
    active.sort(
        key=lambda p: (counts.get(p.get("id", ""), 0), last_active_or_min(p)),
        reverse=True,
    )
    top = active[:10]

    lines = [
        "## Active projects (top 10)",
        "",
        "| Project | IDE | Status | Last active | Activity 7d | Deadline |",
        "|---------|-----|--------|-------------|-------------|----------|",
    ]
    for p in top:
        deadline = p.get("deadline") or "-"
        last = p.get("last_active") or "-"
        act = counts.get(p["id"], 0)
        lines.append(
            f"| `{p['id']}` | {p.get('ide', '?')} | {p.get('status', '?')} | {last} | {act} | {deadline} |"
        )
    lines.append("")
    lines.append(f"_Total registered: {len(projects)} | active: {len(active)}_")
    lines.append("")
    return lines


def section_activity(activity: list[dict], days: int = 7) -> list[str]:
    """Histogram of activity samples per project + per hour."""
    if not activity:
        return [
            "## Activity (last 7 days)",
            "",
            "_No samples yet. Activity tracker installs via `ultron schedule install`._",
            "",
        ]

    # v10.5: idle entries (project_id=None) are counted under '(idle)' so the
    # histogram reflects "PC was on but not on a tracked project" — distinct
    # from "PC was off". Without this, the dashboard crashed on f-string format
    # of NoneType.
    by_project: Counter = Counter()
    for e in activity:
        pid = e.get("project_id")
        by_project[pid if pid else "(idle)"] += 1
    total = sum(by_project.values())

    lines = [
        f"## Activity (last {days} days, {total} samples)",
        "",
        "**By project:**",
        "",
    ]
    max_count = max(by_project.values()) if by_project else 1
    for pid, count in by_project.most_common(8):
        bar_len = int((count / max_count) * 30)
        lines.append(f"- `{pid:<28}` `{'#' * bar_len:<30}` {count}")
    lines.append("")

    # Hour-of-day histogram
    by_hour: Counter = Counter()
    for e in activity:
        try:
            ts = datetime.fromisoformat(e.get("ts", ""))
            by_hour[ts.hour] += 1
        except Exception:
            continue
    lines.append("**By hour-of-day:**")
    lines.append("")
    lines.append("```")
    max_h = max(by_hour.values()) if by_hour else 1
    for h in range(24):
        c = by_hour.get(h, 0)
        bar_len = int((c / max_h) * 24) if max_h else 0
        lines.append(f"  {h:02d}h |{'#' * bar_len:<25} {c}")
    lines.append("```")
    lines.append("")
    lines.append("_(hour data feeds 4.J' Schedule Learner once we have ≥7 days)_")
    lines.append("")
    return lines


def section_deadlines(projects: list[dict], deadlines: dict) -> list[str]:
    upcoming = []
    today = datetime.now().date()
    for p in projects:
        dl = p.get("deadline")
        if not dl:
            continue
        try:
            dl_date = datetime.fromisoformat(dl).date()
            days_left = (dl_date - today).days
            upcoming.append((days_left, p["id"], p.get("name", ""), dl))
        except (ValueError, TypeError):
            continue
    # Calendar matches (4.J output)
    for m in deadlines.get("matches", []):
        try:
            dl_date = datetime.fromisoformat(m.get("date", "")).date()
            days_left = (dl_date - today).days
            upcoming.append((days_left, m.get("project_id", "?"),
                             m.get("event_title", ""), m.get("date", "")))
        except (ValueError, TypeError):
            continue

    if not upcoming:
        return [
            "## Upcoming deadlines",
            "",
            "_No deadlines registered. Add `\"deadline\": \"YYYY-MM-DD\"` to a project in projects.json,_",
            "_or run `ultron calendar sync` (4.J) once Calendar matching is wired up._",
            "",
        ]

    upcoming.sort(key=lambda x: x[0])
    lines = ["## Upcoming deadlines", ""]
    for days_left, pid, title, date in upcoming[:15]:
        if days_left < 0:
            tag = f"PAST ({-days_left}d ago)"
        elif days_left == 0:
            tag = "**TODAY**"
        elif days_left <= 3:
            tag = f"**{days_left}d** :warning:"
        elif days_left <= 7:
            tag = f"{days_left}d"
        else:
            tag = f"{days_left}d"
        lines.append(f"- {tag} | `{pid}` | {date} | {title}")
    lines.append("")
    return lines


def section_vault(vault: dict) -> list[str]:
    if not vault:
        return [
            "## Auth Vault",
            "",
            "_Empty. Run: `ultron auth add -Service gmail -ProfileName personal -ConfigPath ...`_",
            "",
        ]
    lines = ["## Auth Vault", "", "| Service | Active | Profiles |", "|---------|--------|----------|"]
    for svc, info in sorted(vault.items()):
        lines.append(f"| `{svc}` | `{info['active']}` | {info['profile_count']} |")
    lines.append("")
    return lines


def section_alerts() -> list[str]:
    head = alerts_head()
    if not head:
        return ["## News alerts", "", "_No breaking changes in queue._", ""]
    return ["## News alerts (latest)", "", "```"] + head + ["```", "", f"_See full: `{NEWS_ALERTS}`_", ""]


def section_news_pointer() -> list[str]:
    p = latest_news_path()
    if not p:
        return ["## News digest", "", "_No digest yet. Run: `ultron news` (or wait for daily 8AM cron)._", ""]
    return [
        "## News digest",
        "",
        f"Latest: `{p.relative_to(Path.home())}` ({datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec='seconds')})",
        "",
    ]


def section_footer() -> list[str]:
    return [
        "---",
        "",
        "**Quick actions:**",
        "- `ultron status` - terminal version of this dashboard",
        "- `ultron open <project>` - launch IDE",
        "- `ultron scan` - re-scan filesystem for new projects",
        "- `ultron schedule status` - check Task Scheduler",
        "",
    ]


# ── Build ────────────────────────────────────────────────────────────────────

def build() -> Path:
    projects = load_projects()
    activity = load_activity(days=7)
    deadlines = load_deadlines()
    vault = load_vault_summary()

    lines: list[str] = []
    lines += section_header()
    lines += section_projects(projects, activity)
    lines += section_activity(activity)
    lines += section_deadlines(projects, deadlines)
    lines += section_vault(vault)
    lines += section_alerts()
    lines += section_news_pointer()
    lines += section_footer()

    DASHBOARD_PATH.parent.mkdir(parents=True, exist_ok=True)
    DASHBOARD_PATH.write_text("\n".join(lines), encoding="utf-8")
    return DASHBOARD_PATH


def main():
    p = argparse.ArgumentParser(description="ULTRON Cockpit dashboard generator")
    p.add_argument("--print", action="store_true", help="Print dashboard to stdout instead of writing")
    args = p.parse_args()

    if args.print:
        print(DASHBOARD_PATH.read_text(encoding="utf-8") if DASHBOARD_PATH.exists() else "(no dashboard yet)")
        return 0

    out = build()
    print(f"[dashboard] Wrote {out} ({out.stat().st_size} bytes)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
