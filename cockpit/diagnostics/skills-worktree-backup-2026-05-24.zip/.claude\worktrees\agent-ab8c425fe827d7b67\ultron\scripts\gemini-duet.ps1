# ULTRON v9.0 Triumvirate — Gemini CLI helper
# Mirror funcional de codex-duet.ps1 adaptado a Gemini CLI 0.39.1.
# Invokes Gemini with --approval-mode plan (read-only equivalent), captures session_id for round 2+ resume.
# Backend for /minitriple /triple /maxtriple overlays AND /dual --gemini.
#
# Diferencias clave vs codex-duet:
#   - Gemini NO tiene mcp-server subcommand → no MCP nativo registration possible
#   - Gemini NO tiene --output-schema strict → schema validado client-side post-hoc
#   - Gemini -o json devuelve { session_id, response, stats } completo a stdout
#   - Resume acepta UUID directo (no solo índices) — más simple que Codex
#   - Stdout pollution: línea "Skill X is overriding..." aparece antes del JSON, hay que filtrarla
#
# See knowledge: ~/.ultron/knowledge/claude-platform/gemini-cli.md

[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateSet('Mini','Triple','Max')][string]$Mode,
    [Parameter(Mandatory)][int]$Round,
    [string]$PromptFile,
    [string]$Prompt,
    # v10.4 H: prompt template support (mirror of codex-duet)
    [string]$PromptTemplate,
    [string]$TemplateVars,
    [string]$SessionId,
    # Aliases CLI: auto · pro · flash · flash-lite. Default 'pro' para debate sustancial.
    # Para sanity checks rápidos (Mini), considerar pasar -Model flash desde el caller.
    [ValidateSet('auto','pro','flash','flash-lite')][string]$Model = 'pro',
    [string]$OutputDir = (Join-Path $env:TEMP 'ultron-triple'),
    [int]$TimeoutSec = 240,
    # v9.0: hard cap enforcement via per-session counter file (separate from Codex Dual caps).
    # Caps: Mini=unlimited, Triple=3/day, Max=1/day
    [switch]$BypassCaps
)

$ErrorActionPreference = 'Stop'

# ── v9.0: Hard cap enforcement (mirroring Codex pattern) ─────────────────────
# Counter file lives at ~/.ultron/sessions/<YYYY-MM-DD>/triple-caps.json.
# Only round 1 of Triple/Max counts as "an invocation"; subsequent rounds within the
# same invocation share session_id, so don't double-count.
function Test-TripleCaps {
    param([string]$Mode, [int]$Round, [bool]$Bypass)

    if ($Bypass) {
        Write-Host "[Triple] Caps bypassed via -BypassCaps flag (Rodrigo override)"
        return
    }
    # MiniTriple: unlimited per design (each call is a 1-round sanity check)
    if ($Mode -eq 'Mini') { return }
    # Only count the first round of a multi-round invocation
    if ($Round -ne 1) { return }

    $today = Get-Date -Format 'yyyy-MM-dd'
    $sessionDir = Join-Path $env:USERPROFILE ".ultron\sessions\$today"
    New-Item -ItemType Directory -Force -Path $sessionDir | Out-Null
    $capFile = Join-Path $sessionDir 'triple-caps.json'

    $caps = if (Test-Path $capFile) {
        try { Get-Content -Raw $capFile | ConvertFrom-Json } catch { $null }
    } else { $null }
    if (-not $caps) {
        $caps = [pscustomobject]@{ mini = 0; triple = 0; max = 0 }
    }

    $limits = @{ Triple = 3; Max = 1 }
    $key = $Mode.ToLower()
    $current = [int]$caps.$key

    if ($current -ge $limits[$Mode]) {
        Write-Error ("[Triple] Hard cap reached for $Mode mode: " +
                     "$current/$($limits[$Mode]) invocations today. " +
                     "Pass -BypassCaps if Rodrigo confirms explicit override. " +
                     "Counter file: $capFile")
        exit 7
    }

    $caps.$key = $current + 1
    $caps | ConvertTo-Json -Compress | Set-Content -Path $capFile -Encoding utf8 -NoNewline
    Write-Host "[Triple] Cap counter: $Mode = $($caps.$key)/$($limits[$Mode]) today"
}

Test-TripleCaps -Mode $Mode -Round $Round -Bypass:$BypassCaps

# ── Resolve binaries ─────────────────────────────────────────────────────────
# v10.4 fix: Start-Process cannot invoke .cmd/.ps1 wrappers on Windows
# ("%1 no es una aplicación Win32 válida"). Mirror codex-duet pattern:
# invoke node.exe directly with gemini.js bundle.
$nodeExe = "C:\Program Files\nodejs\node.exe"
if (-not (Test-Path $nodeExe)) {
    $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
    if ($nodeCmd) { $nodeExe = $nodeCmd.Source }
}
if (-not (Test-Path $nodeExe)) {
    Write-Error "Node.js not found. Install Node.js to use Gemini CLI."
    exit 1
}

$geminiJs = "$env:APPDATA\npm\node_modules\@google\gemini-cli\bundle\gemini.js"
if (-not (Test-Path $geminiJs)) {
    Write-Error "Gemini CLI not found at $geminiJs. Install with: npm i -g @google/gemini-cli"
    exit 1
}

# ── Resolve prompt and write to file (consistency with Codex helper) ─────────
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$promptTmpFile = Join-Path $OutputDir "prompt-r$Round-$timestamp.txt"

if ($PromptTemplate) {
    if (-not [System.IO.Path]::IsPathRooted($PromptTemplate)) {
        $tmplDir = (Resolve-Path (Join-Path $PSScriptRoot '..\references\prompt-templates')).Path
        $tmplPath = Join-Path $tmplDir $PromptTemplate
    } else {
        $tmplPath = $PromptTemplate
    }
    if (-not (Test-Path $tmplPath)) {
        Write-Error "Prompt template not found: $tmplPath"
        exit 2
    }
    $promptText = Get-Content -Raw $tmplPath
    if ($TemplateVars) {
        try {
            $vars = $TemplateVars | ConvertFrom-Json
            foreach ($key in $vars.PSObject.Properties.Name) {
                $placeholder = '{' + $key + '}'
                $value = [string]$vars.$key
                $promptText = $promptText.Replace($placeholder, $value)
            }
        } catch {
            Write-Error "Failed to parse -TemplateVars JSON: $_"
            exit 2
        }
    }
} elseif ($PromptFile) {
    if (-not (Test-Path $PromptFile)) {
        Write-Error "Prompt file not found: $PromptFile"
        exit 2
    }
    $promptText = Get-Content -Raw $PromptFile
} elseif ($Prompt) {
    $promptText = $Prompt
} else {
    Write-Error "One of -PromptTemplate, -PromptFile, or -Prompt must be provided"
    exit 3
}
[System.IO.File]::WriteAllText($promptTmpFile, $promptText, (New-Object System.Text.UTF8Encoding $false))

# ── Setup output paths ───────────────────────────────────────────────────────
$outFile = Join-Path $OutputDir "round-$Round-$timestamp.json"
$logFile = Join-Path $OutputDir "round-$Round-$timestamp.jsonl"
$errFile = Join-Path $OutputDir "round-$Round-$timestamp.err.txt"

# ── Validate gating ──────────────────────────────────────────────────────────
if ($Mode -eq 'Mini' -and $Round -ne 1) {
    Write-Error "MiniTriple is single-round (received Round=$Round)"
    exit 4
}
if ($Round -gt 1 -and -not $SessionId) {
    Write-Error "Round $Round requires -SessionId from a previous round"
    exit 5
}

# ── Build argument list for Gemini CLI ───────────────────────────────────────
# v10.4 fix: pass prompt via STDIN redirect, NOT via -p $prompt arg.
# Reason: Windows arg parsing splits prompts with `{`, `"`, `\n` into multiple
# positionals, triggering "Cannot use both a positional prompt and the --prompt
# (-p) flag together". Gemini help: "-p ... Appended to input on stdin (if any)".
# So -p "" + stdin = headless mode with stdin content as full prompt.
$argsList = @()
# PS5.1 collapses empty strings in arrays - use --prompt= form so the empty value
# stays attached to the flag. Single space triggers Gemini's headless mode without
# overriding the stdin-provided prompt content.
$argsList += '--prompt= '
$argsList += '-m'
$argsList += $Model
$argsList += '--approval-mode'
$argsList += 'plan'
# Sandbox -s removed: requires docker/podman, exit 44 without them.
# --approval-mode plan already enforces read-only.
$argsList += '-o'
$argsList += 'json'
$argsList += '--skip-trust'

# Resume in rounds 2+ (Gemini accepts UUID directly — simpler than Codex's positional SESSION_ID)
if ($Round -gt 1 -and $Mode -ne 'Mini') {
    $argsList += '-r'
    $argsList += $SessionId
}

# ── Invoke Gemini ────────────────────────────────────────────────────────────
function Invoke-GeminiProcess {
    param([string]$NodeExe, [string]$GeminiJs, [string[]]$ArgsList,
          [string]$StdinPath,
          [string]$StdoutPath, [string]$StderrPath, [int]$TimeoutSec)

    # v10.4 fix: invoke node.exe with gemini.js + stdin from prompt file.
    # Avoids Windows arg-parsing breakage on multiline prompts with {} or quotes.
    $fullArgs = @($GeminiJs) + $ArgsList
    $proc = Start-Process -FilePath $NodeExe `
                          -ArgumentList $fullArgs `
                          -RedirectStandardInput $StdinPath `
                          -RedirectStandardOutput $StdoutPath `
                          -RedirectStandardError $StderrPath `
                          -NoNewWindow -PassThru

    if (-not $proc.WaitForExit($TimeoutSec * 1000)) {
        try { $proc.Kill() } catch {}
        Write-Warning "Gemini timed out after $TimeoutSec seconds - process killed"
        return 124
    }
    return $proc.ExitCode
}

Write-Host "[Triple] Mode=$Mode Round=$Round Model=$Model ApprovalMode=plan Sandbox=false Timeout=${TimeoutSec}s"
$startTime = Get-Date

$exitCode = Invoke-GeminiProcess -NodeExe $nodeExe -GeminiJs $geminiJs -ArgsList $argsList `
                                  -StdinPath $promptTmpFile `
                                  -StdoutPath $logFile -StderrPath $errFile `
                                  -TimeoutSec $TimeoutSec

# ── Parse stdout: filter "Skill X is overriding..." pollution, extract JSON ──
$jsonText = $null
$parsedOk = $false

if (Test-Path $logFile) {
    $rawLines = Get-Content $logFile
    # First line that starts with '{' is the JSON. Skill override warnings come before.
    $jsonStart = -1
    for ($i = 0; $i -lt $rawLines.Count; $i++) {
        if ($rawLines[$i] -match '^\s*\{') {
            $jsonStart = $i
            break
        }
    }
    if ($jsonStart -ge 0) {
        $jsonText = ($rawLines[$jsonStart..($rawLines.Count - 1)] -join "`n")
        try {
            $parsed = $jsonText | ConvertFrom-Json
            $parsedOk = $true
        } catch {
            Write-Warning "Stdout has JSON-like start but parse failed: $($_.Exception.Message)"
        }
    }
}

if (-not $parsedOk) {
    if (Test-Path $errFile) {
        $errContent = Get-Content -Raw $errFile
        if ($errContent) { Write-Warning "Stderr: $errContent" }
    }
    Write-Error "Gemini exec failed (exit=$exitCode, no parseable JSON in stdout). See log: $logFile"
    exit 1
}

# ── Extract response (the actual model output) and write to $outFile ─────────
# Gemini puts the natural-language or JSON-structured response inside .response field.
# If the prompt asked for JSON schema (ULTRON pattern), .response will contain JSON-as-string.
$responseText = $parsed.response
if (-not $responseText) {
    Write-Error "Gemini output missing 'response' field. Raw: $jsonText"
    exit 6
}

# Try to strip markdown code fences (Gemini sometimes wraps JSON in ```json ... ```)
$cleanResponse = $responseText -replace '^```(?:json)?\s*', '' -replace '\s*```$', ''
$cleanResponse = $cleanResponse.Trim()

# Validate that response is parseable JSON if it looks like JSON
$isJson = $cleanResponse -match '^\s*[\{\[]'
if ($isJson) {
    try {
        $null = $cleanResponse | ConvertFrom-Json
        Set-Content -Path $outFile -Value $cleanResponse -Encoding utf8 -NoNewline
    } catch {
        Write-Warning "Response looks like JSON but isn't parseable: $($_.Exception.Message)"
        # Save anyway for debug
        Set-Content -Path $outFile -Value $cleanResponse -Encoding utf8 -NoNewline
    }
} else {
    # Non-JSON response (shouldn't happen with ULTRON-style prompts but handle gracefully)
    $wrapped = @{ raw_text = $cleanResponse } | ConvertTo-Json -Compress
    Set-Content -Path $outFile -Value $wrapped -Encoding utf8 -NoNewline
}

# ── Capture session_id for round 2+ resume ───────────────────────────────────
if ($Round -eq 1 -and $Mode -ne 'Mini') {
    $sid = $parsed.session_id
    if ($sid) {
        Write-Host "SESSION_ID=$sid"
        Set-Content -Path (Join-Path $OutputDir 'last-session-id.txt') -Value $sid -Encoding ascii -NoNewline
    } else {
        Write-Warning "Could not extract session_id from Gemini response. Round 2+ resume will not work."
    }
}

# ── Report duration + token usage ────────────────────────────────────────────
$elapsed = ((Get-Date) - $startTime).TotalSeconds
$tokenInfo = ''
try {
    $modelStats = $parsed.stats.models.PSObject.Properties | Select-Object -First 1
    if ($modelStats) {
        $tokens = $modelStats.Value.tokens
        $tokenInfo = " - tokens(in=$($tokens.input), out=$($tokens.candidates), thoughts=$($tokens.thoughts))"
    }
} catch {}
$elapsedRounded = [math]::Round($elapsed, 1)
Write-Host "[Triple] Round $Round complete in ${elapsedRounded}s$tokenInfo"

Write-Host "--- OUTPUT JSON ---"
Get-Content -Raw $outFile
