# ULTRON — Subagent Routing
> Mapa decisional de cuándo usar cada `subagent_type` del `Agent` tool de Claude Code.
> Última actualización: 2026-04-27 · v7.0

> Ver `~/.ultron/knowledge/claude-platform/subagents-and-hooks.md` para spec completa.

---

## 🗺️ Tabla decisional — qué subagent_type para qué

### Built-in CC

| Caso | `subagent_type` | Modelo | Por qué |
|---|---|---|---|
| Buscar archivos / mapear estructura / "¿dónde está X?" | `Explore` | Haiku | Read-only, rápido, no flooding del main context |
| Plan Mode necesita contexto antes del plan | `Plan` | Inherit | Read-only, especializado en research-for-planning |
| Tarea multi-step con explorar+modificar (>3 pasos paralelos) | `general-purpose` | Inherit | Tools completos, contexto aislado |

### Plugins Claude Code

| Caso | Subagent | Cuándo |
|---|---|---|
| Diseñar arquitectura de feature nueva | `feature-dev:code-architect` | Antes de tocar código en HIGH/ULTRA |
| Entender feature existente sin tocar | `feature-dev:code-explorer` | Bug ajeno, codebase nueva |
| Review independiente de código (no Kirkardo) | `feature-dev:code-reviewer` | Tras implementar feature, antes de commit |
| Review profunda de PR / convenciones | `pr-review-toolkit:code-reviewer` | PR antes de merge |
| Cazar errores silenciosos / fail-open | `pr-review-toolkit:silent-failure-hunter` | Tras tocar try/catch / fallbacks |
| Review de comments y docstrings | `pr-review-toolkit:comment-analyzer` | Tras añadir documentación grande |
| Análisis de cobertura de tests en PR | `pr-review-toolkit:pr-test-analyzer` | Tras añadir tests |
| Análisis de diseño de tipos | `pr-review-toolkit:type-design-analyzer` | Al introducir tipos nuevos |
| Code review crítico cross-step | `superpowers:code-reviewer` | Cierre de feature mayor |
| Crear hooks desde transcripción | `hookify:conversation-analyzer` | Tras `/hookify` |
| Simplificar código recién escrito | `code-simplifier:code-simplifier` | Tras gran cambio |

### Personas como subagentes

Cada persona (`terry-davis`, `don-claudio`, `mike-tyson`, etc.) se invoca via `Skill` tool — **no** son subagent_types. La diferencia:

- **`Skill` tool** → carga el SKILL.md de la persona en el contexto principal. Persistencia, comparte contexto.
- **`Agent` tool con subagent_type** → contexto AISLADO. La persona pierde contexto al terminar.

**Regla:** Personas via `Skill`. Subagentes via `Agent` solo cuando el aislamiento es valioso (búsquedas masivas, paralelismo).

---

## 🚀 Patrón canónico de dispatch

### Caso 1 — Una sola persona (lo habitual)

```
ULTRON → Skill(persona) → ejecuta inline
```

No usar Agent. Persona en contexto principal es más eficiente.

### Caso 2 — Persona + investigación masiva

```
ULTRON → Skill(persona) [da contexto, dirección]
       → Agent(Explore, "find all usages of X across repo")
       → integra resultado en contexto persona
```

Explore aísla los grep/glob (reduce contexto del main). Persona usa el summary.

### Caso 3 — Multi-dominio paralelo

```
ULTRON dispatching-parallel-agents:
  Agent(general-purpose, "investigate authentication flow")
  Agent(general-purpose, "investigate payment flow")
  Agent(Explore, "map all API endpoints")
  → ULTRON sintetiza al recibir todos
```

**Regla:** lanzar todos en el MISMO mensaje (un solo turno con N tool calls). Si los lanzas secuencialmente, pierdes el paralelismo real.

### Caso 4 — Pipeline secuencial

```
Fase 1: Agent(Plan, "design X") → strategy.md
Fase 2 paralela: Agent(general-purpose, "implement A según strategy")
                 Agent(general-purpose, "implement B según strategy")
Fase 3: ULTRON main integra + tests
```

---

## 📐 Brief para subagentes — template

```
Tu objetivo es: [UNA cosa específica, accionable]

Contexto:
- [dato relevante 1]
- [dato relevante 2]
- [archivo de referencia con ruta absoluta]

Inputs:
- [archivo: ruta absoluta]
- [URL: si aplica]

Tu output debe ser:
- [entregable concreto] reportado en menos de [N palabras]

Restricciones:
- NO hacer [scope creep]
- Trabajar en [directorio si worktree]

Si encuentras bloqueo: parar, reportar el bloqueo, no inventar.
```

**Reglas de oro:**
1. **Self-contained**: el subagent no ve la conversación. Todo lo que necesite va en el brief.
2. **Cap de output**: pedir resumen corto (<200 palabras) — el resultado vuelve al main, gasta tokens.
3. **Trust but verify**: el summary del agent dice qué quiso hacer. Si tocó código, **lee el diff** antes de reportar listo.
4. **Sin lifecycle ambiguo**: deja claro cuándo el agente se considera "terminado".

---

## 🔥 Reglas de combinación con Personas

| Combo | Resultado |
|---|---|
| Persona via `Skill` + Agent(Explore) | Persona pide al Explore que mapee, recibe summary |
| Persona via `Skill` + Agent(general-purpose) con isolation:worktree | Persona delega impl en worktree aislado, integra cambio cuando termina |
| 2 Personas via `Skill` simultáneas | NO directamente — ULTRON main coordina, llama a una y luego a otra |
| Agent + Plugin subagent (ej: code-reviewer) | Sí, perfecto para review independiente tras implementación |

---

## 🛡️ Hooks — cuándo Rodrigo debería querer uno

Ver `~/.ultron/knowledge/claude-platform/subagents-and-hooks.md § HOOKS`.

**Casos donde un hook ayudaría a ULTRON:**

| Caso | Hook propuesto |
|---|---|
| Auto-aprobar Read/Glob/Grep | `PreToolUse` con matcher `Read\|Glob\|Grep` → `permissionDecision: allow` |
| Bloquear `rm -rf` | `PreToolUse` con matcher `Bash` → check command, deny si match |
| Log de toda sesión a `~/.ultron/sessions/` | `Stop` hook que append metadata |
| Audit cuando se toca SKILL.md de personas | `PostToolUse` con matcher `Edit` + check file_path |

Si Rodrigo pide algo de tipo "cada vez que X, haz Y" → es candidato a hook. ULTRON debería sugerirlo.

---

## ⚠️ Footguns

1. **Lanzar Agent secuencialmente cuando son independientes** — pierdes paralelismo. Un solo turno, N tool calls.
2. **Brief vago** — el subagent se va por las ramas. Especificar UN objetivo, no una lista.
3. **Olvidar `isolation: "worktree"`** cuando vas a modificar código en paralelo — N agents tocando los mismos archivos = caos.
4. **Pedir output largo** al subagent — el summary llena tu contexto. Cap explícito ("<200 palabras").
5. **Asumir que el subagent recordará** algo de turnos anteriores — cada `Agent` call es una sesión nueva. Para continuar, usar `SendMessage` al agent_id existente.
6. **No verificar diff** después de un Agent que escribe — su summary describe intención, no necesariamente lo que pasó.

---

## 📚 Referencias

- `~/.ultron/knowledge/claude-platform/subagents-and-hooks.md` — spec completa
- [Claude Code Subagents](https://code.claude.com/docs/en/sub-agents)
- [Agent SDK Subagents](https://platform.claude.com/docs/en/agent-sdk/subagents)
