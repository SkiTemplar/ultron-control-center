# Auth Vault Protocol — ULTRON v10.0 Cockpit

**Componente:** 4.C de v10.0 "Cockpit"
**Backend:** Windows DPAPI (CurrentUser scope, sin dependencias externas)
**Archivos:** `scripts/cockpit/auth-vault.ps1` (encryption core) · `scripts/cockpit/auth_vault.py` (orchestration)

---

## 0. Filosofía — Claude-as-Proxy

> **Codex y Gemini NUNCA reciben tokens.** Reciben datos sanitizados que Claude lee de sus propios MCP servers y pasa en el prompt.

Este vault NO es para distribuir credenciales a peers. Es para **switching de identidad** dentro de los MCP servers que SOLO Claude usa.

### Diagrama de confianza

```
┌─────────────────┐   ┌──────────────┐   ┌──────────────┐
│  Auth Vault     │──▶│ settings.json│──▶│  Claude (CC) │
│  (DPAPI blob)   │   │ mcpServers.X │   │  via MCP     │
└─────────────────┘   └──────────────┘   └──────┬───────┘
                                                 │
                                                 │ reads MCP tool
                                                 ▼
                                         ┌──────────────┐
                                         │ Gmail / Drive│
                                         │   /Supabase  │
                                         └──────┬───────┘
                                                 │
                                                 │ raw data
                                                 ▼
                                         ┌──────────────┐
                                         │  Claude      │
                                         │  sanitiza    │
                                         └──────┬───────┘
                                                 │
                                                 │ data WITHOUT tokens
                                                 ▼
                              ┌──────────────────┴──────────────────┐
                              ▼                                     ▼
                       ┌──────────┐                         ┌──────────┐
                       │  Codex   │                         │  Gemini  │
                       │ read-only│                         │ plan-only│
                       └──────────┘                         └──────────┘
```

**Regla inamovible:** los blobs encriptados del vault solo se desencriptan con el user de Windows que los creó (DPAPI CurrentUser). Si otro user del mismo PC intenta leer → falla. Si copias el archivo a otro PC → falla.

---

## 1. Schema del vault

`~/.ultron/cockpit/auth-vault.dpapi` (es JSON, no binario — los blobs están dentro como base64):

```json
{
  "version": "1.0",
  "services": {
    "gmail": {
      "active": "personal",
      "profiles": {
        "personal": {
          "encrypted": "<base64 DPAPI blob>",
          "added": "2026-04-27T17:30:00.000Z",
          "label": "rodrixfc17@gmail.com"
        },
        "freelance": { ... }
      }
    },
    "drive": { ... },
    "supabase": { ... }
  }
}
```

El blob `encrypted` es la versión cifrada del bloque JSON `mcpServers.<service>` correspondiente a esa cuenta.

### Por qué el blob es el bloque MCP completo (no solo el token)

- **Modular:** añadir Notion, GitHub, etc. es trivial — vault no necesita conocer la forma de cada token
- **Cero parsing:** swap directo del bloque, sin armar JSON ad-hoc
- **Backups consistentes:** restaurar un profile = restaurar la config exacta que funcionaba

---

## 2. Operaciones soportadas

| Action | Comando | Efecto |
|---|---|---|
| `Status` | `auth-vault.ps1 -Action Status` | Resumen: services × profiles × active |
| `List` | `auth-vault.ps1 -Action List` | Tabla detallada con marcador `*` para active |
| `Add` | `... -Action Add -Service gmail -ProfileName personal -ConfigPath gmail.json [-Label x@y.com]` | Encripta y añade. Si es el primero → marca active. |
| `Get` | `... -Action Get -Service gmail -ProfileName personal` | Imprime JSON desencriptado a stdout |
| `Switch` | `... -Action Switch -Service gmail -ProfileName freelance [-Force]` | Backup + swap atómico de `mcpServers.<service>` en `settings.json` |
| `Remove` | `... -Action Remove -Service gmail -ProfileName old [-Force]` | Elimina profile. Si era active → promueve siguiente. |

### Atomicidad del Switch

```
1. Decrypt target profile blob → newConfig (en memoria)
2. Confirm con user (skip si -Force)
3. cp settings.json → settings.json.<timestamp>.bak
4. Read settings.json → swap settings.mcpServers.<service> = newConfig
5. Write settings.json.tmp → atomic rename a settings.json
6. Update vault.services.<service>.active = <ProfileName>
7. Write vault con backup .bak previo
```

Cualquier fallo en pasos 4-6 deja el `.bak` recuperable.

### Atomicidad del Add

Antes de cualquier escritura: copy `auth-vault.dpapi` → `auth-vault.dpapi.bak`. Si el Write falla, restaurar manualmente o re-add.

---

## 3. Flujos típicos

### Setup inicial — Gmail con 2 cuentas

```powershell
# 1. Capturar el bloque MCP de Gmail con cuenta personal (manualmente, una vez)
#    Asume que ya tienes settings.json con mcpServers.gmail configurado para esa cuenta
$gmailBlock = (Get-Content -Raw ~/.claude/settings.json | ConvertFrom-Json).mcpServers.gmail
$gmailBlock | ConvertTo-Json -Depth 10 | Set-Content gmail-personal.json

# 2. Añadir al vault
.\auth-vault.ps1 -Action Add -Service gmail -ProfileName personal `
                 -ConfigPath gmail-personal.json -Label "rodrixfc17@gmail.com"

# 3. Cambiar a cuenta freelance (login manual primero, capturar config)
$gmailBlock = (Get-Content -Raw ~/.claude/settings.json | ConvertFrom-Json).mcpServers.gmail
$gmailBlock | ConvertTo-Json -Depth 10 | Set-Content gmail-freelance.json

.\auth-vault.ps1 -Action Add -Service gmail -ProfileName freelance `
                 -ConfigPath gmail-freelance.json -Label "freelance@..."
```

### Day-to-day — switch entre cuentas

```powershell
.\auth-vault.ps1 -Action Switch -Service gmail -ProfileName freelance
# Confirma con 'y' → swap completado, restart CC
```

### Recuperación

Si Switch corrompe settings.json:
```powershell
Copy-Item ~/.claude/settings.json.20260427-180000.bak ~/.claude/settings.json
```

Si vault corrompe:
```powershell
Copy-Item ~/.ultron/cockpit/auth-vault.dpapi.bak ~/.ultron/cockpit/auth-vault.dpapi
```

---

## 4. Sistema de servicios soportados

**Modular** — añadir uno nuevo no requiere cambios al core:

| Servicio | Profile típico | Notas |
|---|---|---|
| `gmail` | personal · freelance · academic | Bloque `mcpServers.gmail` completo |
| `drive` | personal · freelance | Idem |
| `supabase` | dev-personal · client-X · client-Y | Tokens distintos por proyecto |
| `notion` | personal · academic · client | Si añades MCP de Notion |
| `github` | personal · org | Token PAT distintos |
| `openai` | (no aplica — `OPENAI_API_KEY` env var, no MCP) | Out of scope |

**Para añadir uno nuevo:** `Add` con cualquier `-Service` string. Vault crea el nodo automáticamente.

---

## 5. Seguridad

### DPAPI guarantees

- **CurrentUser scope:** solo el user de Windows que creó el blob lo desencripta
- **Entropy bind:** uso de entropy `"ultron-cockpit-v1"` añade salt — mismo PC, otro proceso sin entropy correcto → falla
- **No machine boundary:** copiar el `.dpapi` a otro PC → falla
- **Per-blob encryption:** cada profile se cifra independiente — corromper uno no compromete los demás

### Threat model

| Amenaza | Mitigación | No mitigado |
|---|---|---|
| Lectura del archivo por otro user del PC | DPAPI CurrentUser ✅ | — |
| Copia a otro PC | DPAPI machine bind ✅ | — |
| Malware corriendo COMO Rodrigo | ❌ — DPAPI no protege contra esto | El malware tiene el mismo permission de Windows |
| Codex/Gemini sandbox escape | Codex sandbox=read-only · Gemini approval-mode plan ✅ | — |
| settings.json filtrado a peer | Claude-as-proxy: nunca enviado ✅ | Si Rodrigo conscientemente lo pasa en prompt |

### Lo que NO hace este vault

- ❌ NO cifra `settings.json` directamente — solo profiles archivados
- ❌ NO maneja rotación de tokens (se asume que Gmail/Drive/Supabase rotan según su API)
- ❌ NO sincroniza entre PCs (DPAPI machine-bind imposibilita esto by design)
- ❌ NO valida que el blob añadido sea válido para el servicio (solo valida JSON parseable)

---

## 6. Integración con Triple Mode (Claude-as-Proxy explícito)

Cuando Codex o Gemini necesitan info de Gmail/Drive/Supabase durante un round Triple:

```
1. Claude detecta necesidad: "Codex pide ver mi inbox para evaluar X"
2. Claude invoca su MCP tool: mcp__claude_ai_Gmail__search_threads(...)
3. Claude recibe data RAW (incluye tokens en headers internos)
4. Claude SANITIZA:
   - Quita auth headers
   - Reduce a campos relevantes (subject, snippet, from, date)
   - Si email contiene secretos (API keys etc.) → omite o redacta
5. Claude construye prompt para peer:
   "Aquí están los 5 threads relevantes: [sanitized JSON]"
6. Codex/Gemini procesan, NO tienen acceso a tokens ni al MCP tool real
```

**Regla:** si Claude no puede sanitizar (data demasiado sensible) → NO invocar peer. Reportar a Rodrigo: *"Esta query requiere acceso completo a Gmail, no puedo pasar a Codex/Gemini de forma segura. ¿Quieres que la procese yo solo?"*

---

## 7. Pendientes (post-v10.0.x)

- [ ] **Rotación automática:** si profile no se usa en 90 días, prompt para `Remove`
- [ ] **Audit log:** append entry a `~/.ultron/cockpit/auth-vault-audit.jsonl` por cada Switch (sin contenido — solo timestamp + service + profile)
- [ ] **Sync-friendly export:** comando `Export-Profile` que cifre con password en lugar de DPAPI, para mover entre PCs (opcional, riesgoso)
- [ ] **Auto-restart Claude Code post-Switch:** detectar process y notificar
- [ ] **Integration test:** Pester tests con `Add → Get → Switch → Remove` sobre dummy data + restore settings.json al final
