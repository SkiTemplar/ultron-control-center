# [Tema] — [Dominio]
Ultima actualizacion: YYYY-MM-DD
Proyectos donde se aplica:

## Resumen
[2-3 lineas]

## Solucion / Patron
[codigo o descripcion detallada]

## Cuando usar
-

## Limitaciones / Advertencias
-

## Fuentes
-
