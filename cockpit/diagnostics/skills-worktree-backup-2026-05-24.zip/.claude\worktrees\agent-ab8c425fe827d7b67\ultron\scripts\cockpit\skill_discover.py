"""
ULTRON v11.1.0 — GitHub Skill Discovery

Searches for and caches Claude Code skills hosted on GitHub.
No external deps: stdlib only (urllib, json, hashlib, pathlib, argparse).

Subcommands:
  search  <query>      Search GitHub for SKILL.md files
  fetch   <name> <url> Fetch a skill by raw URL and cache locally
  list                 List locally cached skills
  preview <name>       Print cached skill content
  install <name>       Copy from cache to ~/.claude/skills/<name>/
  clean                Remove cached entries older than 7 days
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

CACHE_DIR = Path.home() / ".ultron" / "skill_cache"
SKILLS_DIR = Path.home() / ".claude" / "skills"
GITHUB_API = "https://api.github.com"
CACHE_TTL_DAYS = 7


# ── HTTP helpers ──────────────────────────────────────────────────────────────

def _get(url: str, *, token: str | None = None, accept: str = "application/vnd.github+json") -> dict | str:
    headers = {
        "Accept": accept,
        "User-Agent": "ULTRON-skill-discover/1.0",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = Request(url, headers=headers)
    try:
        with urlopen(req, timeout=15) as resp:
            body = resp.read().decode("utf-8")
            ct = resp.headers.get("Content-Type", "")
            if "json" in ct:
                return json.loads(body)
            return body
    except HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        print(f"[skill_discover] HTTP {e.code}: {body[:200]}", file=sys.stderr)
        raise
    except URLError as e:
        print(f"[skill_discover] Network error: {e}", file=sys.stderr)
        raise


# ── Validation ────────────────────────────────────────────────────────────────

def _validate_skill(content: str) -> bool:
    if len(content) < 100:
        return False
    if not re.search(r"^#{1,3}\s+\S", content, re.MULTILINE):
        return False
    # Reject obvious jailbreak patterns
    jailbreak = ["ignore previous instructions", "[system]:", "ignore all prior", "forget your instructions"]
    lower = content.lower()
    if any(p in lower for p in jailbreak):
        print("[skill_discover] WARNING: Skill content looks like a jailbreak attempt — rejected.", file=sys.stderr)
        return False
    return True


# ── Cache helpers ─────────────────────────────────────────────────────────────

def _safe_name(name: str) -> str:
    """Sanitize skill name to prevent path traversal attacks."""
    safe = re.sub(r"[^\w\-]", "", name)
    if not safe:
        raise ValueError(f"Invalid skill name: {name!r}")
    return safe


def _cache_path(name: str) -> Path:
    return CACHE_DIR / _safe_name(name)


def _save_cache(name: str, content: str, meta: dict):
    d = _cache_path(name)
    d.mkdir(parents=True, exist_ok=True)
    (d / "SKILL.md").write_text(content, encoding="utf-8")
    meta["cached_at"] = datetime.now(timezone.utc).replace(tzinfo=None).isoformat()
    meta["name"] = name
    meta["sha256"] = hashlib.sha256(content.encode()).hexdigest()
    (d / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")


def _load_cache(name: str) -> tuple[str, dict] | None:
    d = _cache_path(name)
    skill_file = d / "SKILL.md"
    meta_file = d / "meta.json"
    if not skill_file.exists():
        return None
    content = skill_file.read_text(encoding="utf-8")
    meta = json.loads(meta_file.read_text(encoding="utf-8")) if meta_file.exists() else {}
    return content, meta


# ── Subcommands ───────────────────────────────────────────────────────────────

def cmd_search(query: str, limit: int = 10):
    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        print("[skill_discover] Tip: Set GITHUB_TOKEN for 5000 req/hr (unauthenticated: 60/hr)")
    params = urlencode({"q": f"{query} filename:SKILL.md", "per_page": min(limit, 30)})
    url = f"{GITHUB_API}/search/code?{params}"
    try:
        data = _get(url, token=token)
    except (HTTPError, URLError):
        return

    items = data.get("items", [])
    if not items:
        print("No skills found.")
        return

    print(f"Found {data.get('total_count', 0)} results (showing {len(items)}):\n")
    for item in items:
        repo = item["repository"]["full_name"]
        path = item["path"]
        raw_url = f"https://raw.githubusercontent.com/{repo}/HEAD/{path}"
        name = Path(path).parent.name or Path(path).stem
        print(f"  {name:<30} {repo}")
        print(f"  {'raw:':<30} {raw_url}\n")


def cmd_fetch(name: str, raw_url: str):
    try:
        content = _get(raw_url, accept="text/plain")
    except (HTTPError, URLError):
        return

    if not isinstance(content, str):
        content = json.dumps(content)

    if not _validate_skill(content):
        print("[skill_discover] Skill failed validation — not cached.")
        return

    meta = {"raw_url": raw_url, "source": "github"}
    _save_cache(name, content, meta)
    print(f"Cached: {name}  →  {_cache_path(name)}")
    print(f"SHA256: {hashlib.sha256(content.encode()).hexdigest()[:16]}...")


def cmd_list():
    if not CACHE_DIR.exists():
        print("No cached skills.")
        return
    entries = sorted(CACHE_DIR.iterdir())
    if not entries:
        print("No cached skills.")
        return

    cutoff = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=CACHE_TTL_DAYS)
    print(f"{'Name':<30} {'Cached':<22} {'Status'}")
    print("-" * 70)
    for d in entries:
        if not d.is_dir():
            continue
        meta_file = d / "meta.json"
        meta = json.loads(meta_file.read_text(encoding="utf-8")) if meta_file.exists() else {}
        cached_at = meta.get("cached_at", "?")
        stale = ""
        if cached_at != "?":
            try:
                ts = datetime.fromisoformat(cached_at)
                if ts < cutoff:
                    stale = "  [STALE]"
            except ValueError:
                pass
        installed = "  [installed]" if (SKILLS_DIR / d.name).exists() else ""
        print(f"{d.name:<30} {cached_at[:19]:<22}{stale}{installed}")


def cmd_preview(name: str):
    result = _load_cache(name)
    if result is None:
        print(f"Skill '{name}' not found in cache. Run: skill_discover.py fetch {name} <raw_url>")
        return
    content, meta = result
    print(f"# {name}  (source: {meta.get('raw_url', '?')})\n")
    print(content[:3000])
    if len(content) > 3000:
        print(f"\n... [{len(content) - 3000} more chars]")


def cmd_install(name: str, force: bool = False):
    safe = _safe_name(name)
    result = _load_cache(safe)
    if result is None:
        print(f"Skill '{safe}' not found in cache.")
        return
    content, meta = result

    dest = SKILLS_DIR / safe
    if dest.exists() and not force:
        print(f"Skill '{name}' already installed at {dest}. Use --force to overwrite.")
        return

    dest.mkdir(parents=True, exist_ok=True)
    (dest / "SKILL.md").write_text(content, encoding="utf-8")
    print(f"Installed: {name}  →  {dest}")
    print("Note: Restart Claude Code to pick up the new skill.")


def cmd_clean():
    if not CACHE_DIR.exists():
        print("Cache empty.")
        return
    cutoff = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=CACHE_TTL_DAYS)
    removed = 0
    for d in CACHE_DIR.iterdir():
        if not d.is_dir():
            continue
        meta_file = d / "meta.json"
        if not meta_file.exists():
            shutil.rmtree(d)
            removed += 1
            continue
        meta = json.loads(meta_file.read_text(encoding="utf-8"))
        cached_at = meta.get("cached_at", "")
        try:
            if datetime.fromisoformat(cached_at) < cutoff:
                shutil.rmtree(d)
                removed += 1
                print(f"  Removed: {d.name}")
        except ValueError:
            pass
    print(f"Cleaned {removed} stale entries.")


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="skill_discover.py",
        description="ULTRON GitHub Skill Discovery — search, cache, and install Claude Code skills",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_search = sub.add_parser("search", help="Search GitHub for SKILL.md files")
    p_search.add_argument("query", help="Search query")
    p_search.add_argument("--limit", type=int, default=10)

    p_fetch = sub.add_parser("fetch", help="Fetch a skill by raw URL and cache locally")
    p_fetch.add_argument("name", help="Local cache name (slug)")
    p_fetch.add_argument("url", help="Raw URL to SKILL.md")

    sub.add_parser("list", help="List cached skills")

    p_preview = sub.add_parser("preview", help="Print cached skill content")
    p_preview.add_argument("name")

    p_install = sub.add_parser("install", help="Install skill from cache to ~/.claude/skills/")
    p_install.add_argument("name")
    p_install.add_argument("--force", action="store_true")

    sub.add_parser("clean", help="Remove stale cache entries (>7 days)")

    args = parser.parse_args()

    if args.cmd == "search":
        cmd_search(args.query, args.limit)
    elif args.cmd == "fetch":
        cmd_fetch(args.name, args.url)
    elif args.cmd == "list":
        cmd_list()
    elif args.cmd == "preview":
        cmd_preview(args.name)
    elif args.cmd == "install":
        cmd_install(args.name, args.force)
    elif args.cmd == "clean":
        cmd_clean()


if __name__ == "__main__":
    main()
