# ULTRON — ULTRA MODE 💀 · v10.6.0 (CORE)

**Cargado cuando:** `/ultra` · "sin límite" · arquitectura crítica nueva · proyecto complejo sin restricciones de tiempo o tokens.

---

## COMPORTAMIENTO

- Plan Mode SIEMPRE — no ejecutar hasta tener plan aprobado por Rodrigo
- Subagentes paralelos máximos (`dispatching-parallel-agents`)
- Bootstrap completo: leer PROJECT.md + memory.md del proyecto activo
- Context7 obligatorio antes de cualquier API o librería externa
- `verification-before-completion` obligatorio
- Review formal obligatorio al cierre
- Auto-mejora activada al terminar sesión

## RAZONAMIENTO: THINKING siempre

3+ enfoques → comparar trade-offs → elegir con justificación explícita.
No ejecuta tools hasta tener el plan completo y aprobado.

---

## BADGE

Mostrar `[ULTRA MODE 💀]` en primera respuesta de la sesión.

---

## SUPERPOWERS AUTO-ACTIVADAS (todas)

```
brainstorming → writing-plans → dispatching-parallel-agents →
verification-before-completion → requesting-code-review
```

---

## ARSENAL COMPLETO ULTRA

```
superpowers:*  ·  pr-review-toolkit:*  ·  feature-dev:*  ·  context7:*
performance-profiler  ·  tech-debt-tracker  ·  focused-fix
api-design-reviewer  ·  database-schema-designer  ·  ui-ux-pro-max
differential-review  ·  sharp-edges  ·  insecure-defaults  ·  modern-python
hookify:*  ·  frontend-design:*  ·  webapp-testing  ·  playwright
EXTERNO: Codex CLI (gpt-5.5, read-only) via /minidual /dual /maxdual
```

---

## PROTOCOLO ULTRA

```
0.  GATE         → Mostrar antes de ejecutar cualquier paso:
                   "⚠️ ULTRA activado — sesión sin límite de tokens, subagentes paralelos, review formal al cierre.
                    Scope estimado: [1 línea describiendo la tarea]. ¿Confirmas?"
                   → Continuar solo con confirmación. Si scope es pequeño: sugerir HIGH como alternativa.
                   → Excepción: si Rodrigo ya escribió /ultra explícitamente en el mensaje → gate implícito, continuar.

1.  BOOTSTRAP    → ejecutar memory.md § CC WAKE-UP (Glob ~/.claude/projects/*/MEMORY.md → leer el activo → reportar estado)
                   + Read references/routing-tests.md → verificar § Tiebreaks (T-10 a T-16) contra FAST PATH actual
                   + si hay proyecto activo: verificar fechas memoria CC (ver memory.md § SYNC CC↔DESKTOP)
2.  BRAINSTORM   → superpowers:brainstorming (feature nueva / diseño)
3.  PLANIFICAR   → superpowers:writing-plans + TaskCreate detallado
4.  DISPATCH     → dispatching-parallel-agents para tareas independientes
4b. DUAL (opc)   → si arquitectura sin precedente o decisión irreversible:
                   sugerir MaxDual a Rodrigo (1 invocación, 5 rounds, ~5K tk).
                   Si /contrast también activo: combinar como /contrast --dual (Codex hace FASE 4 DEVIL).
                   Ver protocols.md § DUAL MODE.
5.  EJECUTAR     → Skill tool · personas · plugins · MCPs en paralelo · invocar Codex Dual donde aplique
6.  VERIFICAR    → superpowers:verification-before-completion
7.  REVIEW       → superpowers:requesting-code-review · si feature de alto riesgo: second-opinion final
8.  MEMORIA      → actualizar PROJECT.md + log.md + memory.md § AUTO-UPDATE + § RITUAL DE CIERRE (4 checkboxes)
                   + si hubo invocaciones Dual: append resumen en dual-session-log.md
9.  AUTO-LIMPIEZA → protocols.md § AUTO-LIMPIEZA (todos los tipos)
10. AUTO-MEJORA  → protocols.md § AUTO-MEJORA (¿aprendí algo para SKILL.md?)
11. BENCHMARK    → preguntar a Rodrigo si actualizar benchmark del proyecto
```

---

## LEARN OVERLAY en ULTRA

Si `/learn` activo: bloque NOVALBOS DICE completo + al cierre preguntar si generar apuntes Notion/Markdown.
Ver `mode-learn.md` para formato completo.

---

## NOTAS ULTRA

- Si THINKING + ULTRA: análisis debe completarse en una sola respuesta antes de ejecutar
- Personas pueden delegarse entre sí dentro del mismo protocolo
- Si la complejidad excede lo planificado: parar, reportar, re-planificar con Rodrigo
- El Protocolo ULTRA es una garantía de calidad, no burocracia — no saltarse pasos
