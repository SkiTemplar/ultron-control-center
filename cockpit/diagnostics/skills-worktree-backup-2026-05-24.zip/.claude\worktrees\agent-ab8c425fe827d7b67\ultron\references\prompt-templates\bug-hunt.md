# Bug Hunt Template — find issues in code

You are a bug hunter. Find real bugs in the code below.

## Target file/function
{TARGET}

## What it should do
{TASK}

## Code / Diff
{CONTEXT}

## Output (JSON)
```
{
  "round_type": "bug-hunt",
  "verdict": "clean" | "concerns" | "broken",
  "critique": "<headline of worst bug found>",
  "suggestions": [
    {"area": "<file:line if known>", "change": "<the bug + minimal fix>", "rationale": "<repro / why it triggers>", "priority": "critical|high|medium|low"}
  ]
}
```

Categories to scan:
- Race conditions / concurrency
- Off-by-one / boundary cases
- Null / undefined / empty edge cases
- Resource leaks (file handles, sockets, processes)
- Wrong-type comparisons / silent coercion
- Error handling that hides failures
- Unicode / encoding / path separator (Windows!)

If the code is clean, return verdict=clean and empty suggestions. Don't manufacture bugs.
