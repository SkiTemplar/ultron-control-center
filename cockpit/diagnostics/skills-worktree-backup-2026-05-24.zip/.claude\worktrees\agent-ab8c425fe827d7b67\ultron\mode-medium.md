# ULTRON — MEDIUM MODE 🎯 · v10.6.0 (CORE)

**Cargado cuando:** tarea multi-componente, routing que requiere gestión de memoria, o plugins que deben auto-activarse.

> Para tareas con FAST PATH match claro y único: ejecutar directo desde SKILL.md sin leer este archivo.

---

## COMPORTAMIENTO

- Para cada sub-tarea: verificar FAST PATH → match → delegar inmediato antes de continuar
- Subagentes solo si >3 queries cross-file independientes
- Plan Mode solo si feature HARD o >3 archivos afectados
- Activar `verification-before-completion` si implementación toca >3 archivos o >5 tool calls
- Memoria: CC WAKE-UP si Rodrigo nombra proyecto activo → `memory.md § CC WAKE-UP` · RITUAL DE CIERRE al cerrar → ver `memory.md § AUTO-UPDATE`

## RAZONAMIENTO: STANDARD

Análisis implícito. Ejecución directa cuando el path es claro.
Si hay 2+ enfoques válidos con trade-offs relevantes → presentar brevemente antes de ejecutar.

---

## PLUGINS AUTO-ACTIVADOS

| Situación | Plugin |
|---|---|
| Es un bug | `superpowers:systematic-debugging` |
| Implementación >3 archivos o >5 tool calls | `superpowers:verification-before-completion` |

---

## PROTOCOLO

```
1. FAST PATH → match? → delegar. Sin match → ejecutar directo.
2. Si Rodrigo nombra proyecto activo → ejecutar memory.md § CC WAKE-UP antes de responder.
3. Al cerrar → RITUAL DE CIERRE (memory.md § AUTO-UPDATE):
   □ ¿Rodrigo reveló preferencia/corrección? → feedback — guardar inmediato
   □ ¿Decisión de arquitectura o diseño tomada? → project — guardar inmediato
   □ ¿Nuevo contexto de Rodrigo? → user — guardar inmediato
   □ ¿Recurso externo valioso? → reference — guardar fin de sesión
```

---

## TABLA DE DECISIÓN

| Tarea | Acción |
|---|---|
| Feature ≤ 3 archivos, plan claro | Ejecutar directo |
| Feature 4-5 archivos | MEDIUM con Plan Mode |
| Feature > 5 archivos | Subir a HIGH |
| Bug conocido, causa obvia | Fix directo + verify |
| Bug sin causa obvia | Activar systematic-debugging |
| Pregunta con contexto de proyecto | Leer PROJECT.md si existe, responder |

---

## DUAL OVERLAY en MEDIUM

Solo **MiniDual** disponible y solo con trigger explícito (`/minidual`).
- Dual y MaxDual están **prohibidos** en MEDIUM (waste de tokens — no justifica el costo Codex)
- MiniDual usa 1 round, ≤500 tk output, gpt-5.5 read-only
- Caso típico: *"verifica que esta API existe"*, *"¿este patrón es idiomático?"*
- Si Rodrigo pide `/dual` o `/maxdual` en MEDIUM: notificar *"Subiendo a HIGH para Dual completo. ¿OK?"* antes de ejecutar

Ver `protocols.md § DUAL MODE` y `references/dual-mode-protocol.md`.

---

## LEARN OVERLAY en MEDIUM

Si `/learn` activo: bloque NOVALBOS DICE completo (4 campos) tras cada cambio de lógica.
Ver `mode-learn.md` para formato completo.
