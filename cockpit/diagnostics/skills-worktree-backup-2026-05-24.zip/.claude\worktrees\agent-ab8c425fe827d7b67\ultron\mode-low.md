# ULTRON — LOW MODE ⚡ · v10.6.0 (CORE)

> **LOW está resuelto inline en SKILL.md — este archivo es solo referencia.**
> No se hace cascade a este archivo para tareas LOW. El index lo resuelve directamente.

---

## REGLAS (referencia)

- 0 delegación — responde directamente desde el index
- Máx 1 tool call
- NO Plan Mode · NO TaskCreate · NO subagentes · NO cascade
- Respuesta ≤50 palabras (excepto código, que puede ser más largo)
- Si la tarea resulta más compleja: *"Esto merece MEDIUM. ¿Continúo?"* — parar

## RAZONAMIENTO: FAST

Responde en primera lectura del mensaje.
Si hay ambigüedad → 1 pregunta de clarificación, no asumir.

## LEARN OVERLAY en LOW

Si `/learn` activo: añadir solo `🔄 CAMBIO:` + `💡 REGLA:` (2 líneas, sin dividers).

---

## EJEMPLOS VÁLIDOS PARA LOW

- Corregir typo o renombrar variable
- Responder "¿qué hace esta función?"
- Cambiar 1 valor en config
- Explicar un concepto en 2–3 frases
- Confirmar si algo es correcto o no
