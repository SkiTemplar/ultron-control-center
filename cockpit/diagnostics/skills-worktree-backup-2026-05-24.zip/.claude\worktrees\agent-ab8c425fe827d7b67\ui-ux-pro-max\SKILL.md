---
name: ui-ux-pro-max
description: >
  Inteligencia de diseño UI/UX de nivel profesional. Activa cuando el usuario
  pide diseñar, revisar, implementar o mejorar interfaces. Contiene 67 estilos
  de diseño, 161 paletas de color, 57 font pairings, 99 directrices UX y 25
  tipos de chart para 16 stacks tecnológicos: React, Next.js, Vue, Svelte,
  Astro, SwiftUI, React Native, Flutter, Nuxt, Nuxt UI, Tailwind, shadcn/ui,
  Jetpack Compose, Three.js, Angular y Laravel. Triggers: "diseña", "crea
  interfaz", "UI", "UX", "landing page", "dashboard", "componente", "paleta",
  "tipografía", "revisión visual", "accesibilidad", "dark mode", "chart",
  "animación", "layout", "responsive".
---

# UI/UX Pro Max — Inteligencia de Diseño

Guía de diseño completa para aplicaciones web y móviles. Base de datos con 67
estilos, 161 paletas de color, 57 font pairings, 99 directrices UX y 25 tipos
de chart para 16 stacks tecnológicos. Sistema de búsqueda con recomendaciones
basadas en prioridad.

---

## Cuándo Aplicar Esta Skill

**Usar siempre cuando la tarea involucre:**
- Diseñar una página nueva (Landing Page, Dashboard, Admin, SaaS, Mobile App)
- Crear o refactorizar componentes UI (botones, modales, formularios, tablas, charts)
- Elegir paleta de colores, sistema tipográfico, espaciado o layout
- Revisar código UI para UX, accesibilidad o consistencia visual
- Implementar navegación, animaciones o comportamiento interactivo
- Tomar decisiones de producto (estilo, jerarquía, identidad de marca)

**No usar para:**
- Desarrollo backend puro
- Diseño de APIs o bases de datos
- Optimización de rendimiento no relacionada con la interfaz
- Infraestructura o DevOps
- Scripts sin componente visual

**Regla de oro:** Si la tarea cambia cómo algo _se ve_, _se usa_ o _se interactúa_, usar esta skill.

---

## Protocolo de Selección de Estilo

### Paso 1 — Clasificar el tipo de producto

| Tipo | Ejemplos | Estilo recomendado |
|------|----------|-------------------|
| **SaaS / Productividad** | Dashboard, CRM, ERP, herramientas | Minimal, Flat, Neumorphism suave |
| **E-commerce / Retail** | Tienda, marketplace, catálogo | Clean, Bold Typography, Glassmorphism leve |
| **Fintech / Banca** | Apps de inversión, pagos, cripto | Dark + Neon, Material 3, Data-forward |
| **Salud / Bienestar** | Apps médicas, fitness, meditación | Soft UI, Pastel, Nature-inspired |
| **Entretenimiento / Social** | Streaming, redes sociales, gaming | Vibrant, Immersive, Content-first |
| **Portfolio / Creativo** | Portfolio, agencia, estudio | Brutalism, Editorial, Experimental |
| **Educación** | Plataformas de aprendizaje, cursos | Friendly, Structured, Warm |
| **B2B / Enterprise** | Paneles de control, analytics | Professional, Dense, Utility-first |

### Paso 2 — Seleccionar el estilo visual

Combinar **máximo 2 estilos** del mismo tier de compatibilidad:

**Tier A — Estilos universales (funcionan con todo):**
- Minimalismo: espacios en blanco, jerarquía clara, pocos elementos
- Flat Design: colores sólidos, sin sombras pesadas, íconos vectoriales
- Material Design 3: elevation, state layers, dynamic color

**Tier B — Estilos especializados (requieren contexto específico):**
- Glassmorphism: fondos difuminados, transparencias, ideal para apps premium
- Neumorphism: sombras suaves extruidas, solo para apps de bienestar/wellness
- Brutalism: tipografía agresiva, bordes crudos, para portfolios disruptivos
- Dark + Neon: fondos oscuros con acentos vibrantes, para fintech/gaming/cripto
- Skeuomorphism moderno: texturas sutiles, para apps creativas o de audio

**Tier C — Estilos de tendencia (usar con moderación):**
- Clay / 3D Inflated: objetos con apariencia suave tridimensional
- Bento Grid: layouts en cuadrícula tipo celdas diferenciadas
- Dot Matrix / Retro: estética pixel/retro para proyectos nostálgicos

### Paso 3 — Confirmar antes de implementar

Antes de empezar cualquier componente, confirmar:
1. ¿El estilo es consistente con el tipo de producto?
2. ¿Hay una paleta de colores definida?
3. ¿Hay un font pairing elegido?
4. ¿Hay tokens de diseño definidos (colores semánticos, espaciado, tipografía)?

---

## Mejores Paletas por Tipo de Proyecto

### SaaS / Dashboard

| Paleta | Colores principales | Cuándo usarla |
|--------|---------------------|---------------|
| **Slate Pro** | slate-900, slate-600, blue-600, white | Dashboard corporativo, B2B |
| **Indigo Clean** | indigo-600, indigo-100, gray-900, gray-50 | Apps de productividad |
| **Violet Modern** | violet-700, violet-200, zinc-900, zinc-50 | Herramientas creativas SaaS |
| **Dark Pro** | gray-950, gray-800, cyan-500, white | Admin panels dark mode |

### E-commerce / Retail

| Paleta | Colores principales | Cuándo usarla |
|--------|---------------------|---------------|
| **Warm Commerce** | amber-600, stone-900, orange-100, white | Tiendas boutique, food |
| **Luxury Black** | zinc-950, gold (#B8860B), white, gray-200 | Marcas de lujo |
| **Vibrant Shop** | rose-500, purple-600, yellow-400, white | Moda joven, streetwear |
| **Clean Retail** | blue-600, gray-800, gray-50, white | Electrónica, tech retail |

### Fintech / Cripto / Banca

| Paleta | Colores principales | Cuándo usarla |
|--------|---------------------|---------------|
| **Crypto Dark** | gray-950, cyan-400, green-400, white | Exchange, wallets |
| **Finance Blue** | blue-800, blue-500, green-500, white | Banca tradicional digital |
| **Neon Finance** | #0D1117, #58A6FF, #3FB950, #E3B341 | Trading apps, mercados |
| **Investment Pro** | slate-800, emerald-500, slate-200, white | Portfolios de inversión |

### Salud / Bienestar

| Paleta | Colores principales | Cuándo usarla |
|--------|---------------------|---------------|
| **Soft Health** | teal-500, teal-100, rose-400, white | Apps de bienestar, yoga |
| **Clinical White** | blue-600, gray-100, green-500, white | Plataformas médicas |
| **Nature Calm** | green-600, green-100, amber-500, stone-50 | Nutrición, fitness natural |
| **Lavender Zen** | purple-400, purple-100, pink-300, white | Meditación, mindfulness |

### Entretenimiento / Social

| Paleta | Colores principales | Cuándo usarla |
|--------|---------------------|---------------|
| **Vibrant Social** | purple-600, pink-500, orange-400, white | Redes sociales, creadores |
| **Streaming Dark** | gray-950, red-500, gray-700, white | Video, streaming |
| **Gaming Neon** | #0A0A0F, #00D4FF, #FF006E, #FFE600 | Gaming, esports |
| **Music Dark** | zinc-950, green-400, white, gray-300 | Apps de música |

### Reglas para color semántico (todos los proyectos)

```
Primary:   El color de marca principal (CTAs, enlaces, focus)
Secondary: Acción de apoyo, menos prominente
Success:   Verde para confirmaciones (#22C55E o equivalente)
Warning:   Ámbar para advertencias (#F59E0B o equivalente)
Error:     Rojo para errores (#EF4444 o equivalente)
Surface:   Fondo de tarjetas y contenedores
On-Surface: Texto sobre Surface
Background: Fondo de página
```

---

## Font Pairings Recomendados por Stack

### React / Next.js (Web)

| Pairing | Heading | Body | Personalidad | Cuándo |
|---------|---------|------|-------------|--------|
| **Professional** | Inter | Inter | Neutral, versátil | SaaS, Dashboard |
| **Editorial** | Playfair Display | Source Serif 4 | Elegante, editorial | Blog, media |
| **Modern Tech** | Space Grotesk | DM Sans | Moderno, técnico | Startups tech |
| **Bold Product** | Syne | Outfit | Atrevido, contemporáneo | Producto, landing |
| **Minimal Clean** | Plus Jakarta Sans | Plus Jakarta Sans | Limpio, amigable | E-commerce, apps |
| **Data Forward** | IBM Plex Sans | IBM Plex Mono | Técnico, datos | Analytics, fintech |

### Tailwind / shadcn/ui

| Pairing | Config (`fontFamily`) | Cuándo |
|---------|----------------------|--------|
| **Default Stack** | `sans: ['Inter']` | Todo propósito |
| **SaaS Premium** | `sans: ['Geist'], mono: ['Geist Mono']` | Apps modernas |
| **Corporate** | `sans: ['IBM Plex Sans']` | Enterprise |
| **Creative** | `display: ['Syne'], sans: ['Outfit']` | Agencias, portfolios |

### SwiftUI / iOS

| Pairing | Fuente | Notas |
|---------|--------|-------|
| **System First** | SF Pro + SF Mono | Siempre preferir para apps nativas |
| **Branded Display** | Custom Display Font + SF Pro Text | Solo para headings, body en SF Pro |
| Dynamic Type | Usar `.title`, `.body`, `.caption` | Obligatorio para accesibilidad |

### Flutter / Android

| Pairing | Fuente | Notas |
|---------|--------|-------|
| **Material Default** | Roboto + Roboto Mono | Apps Material 3 |
| **Modern Android** | Google Sans (Product Sans) + Roboto | Apps Google-style |
| **Custom Brand** | Qualquier Google Font + Roboto | heading personalizado |

### Vue / Nuxt

| Pairing | Integración | Cuándo |
|---------|------------|--------|
| **Nuxt/Fonts** | `Inter + DM Sans` via `@nuxt/fonts` | Proyectos Nuxt estándar |
| **Nuxt UI Default** | `Inter` | Nuxt UI (ya incluido) |
| **Editorial Vue** | `Merriweather + Open Sans` | Blogs, content-heavy |

### Astro

| Pairing | CDN | Cuándo |
|---------|-----|--------|
| **Static Optimal** | `Lato + Merriweather` (Google Fonts preconnect) | Sites estáticos |
| **Modern Astro** | `Plus Jakarta Sans` (self-hosted) | Apps Astro modernas |

### React Native

| Pairing | Implementación | Cuándo |
|---------|---------------|--------|
| **System Default** | Platform.OS === 'ios' ? 'SF Pro' : 'Roboto' | Nativo puro |
| **Cross-platform** | `Inter` via `expo-google-fonts` | Consistencia multiplataforma |
| **Bold Brand** | `Syne` (headings) + `Inter` (body) | Apps con fuerte identidad |

### Reglas tipográficas universales

- **Escala base:** 12 / 14 / 16 / 18 / 24 / 32 / 40 / 48px
- **Line-height:** 1.5-1.75 para cuerpo de texto
- **Longitud de línea:** 60-75 caracteres en desktop, 35-60 en mobile
- **Peso para jerarquía:** 400 (body), 500 (labels), 600 (subheadings), 700 (headings)
- **Nunca:** texto de cuerpo menor a 14px en desktop / 16px en mobile

---

## Cuándo Usar Cada Tipo de Chart

### Selección por tipo de dato

| Dato a visualizar | Chart recomendado | Cuándo NO usarlo |
|------------------|-------------------|-----------------|
| **Tendencia temporal** | Line chart | Para comparar 1 valor en el tiempo |
| **Comparación entre categorías** | Bar chart (vertical) | No funciona con >10 categorías en móvil |
| **Ranking / comparación horizontal** | Bar chart (horizontal) | No para tendencias |
| **Proporción / composición** | Donut chart | Evitar para más de 5 segmentos |
| **Parte de un todo simple** | Pie chart | Nunca más de 5 categorías |
| **Distribución de datos** | Histogram | No para categorías discretas |
| **Correlación entre variables** | Scatter plot | No para tendencias temporales |
| **Múltiples variables en un punto** | Radar chart | Solo para máx. 7 ejes |
| **Flujo y conversión** | Funnel chart | Específico para embudos de conversión |
| **Árbol jerárquico** | Treemap | Solo cuando el tamaño importa |
| **Calor / densidad** | Heatmap | Para matrices de datos o calendarios |
| **Composición acumulada** | Area chart (stacked) | Para 2-4 series como máximo |
| **KPIs simples** | Gauge / Stat card | Solo para 1 valor + meta |
| **Tabla con comparación** | Data table + sparklines | Cuando necesitas detalles + tendencia |
| **Geográfico** | Map chart (choropleth) | Solo con datos georreferenciados |

### Librerías recomendadas por stack

| Stack | Librería principal | Alternativa |
|-------|------------------|-------------|
| React / Next.js | Recharts | Victory, Chart.js |
| Vue / Nuxt | Chart.js + vue-chartjs | ECharts |
| Svelte / Astro | Layerchart | D3 directo |
| React Native | Victory Native | react-native-chart-kit |
| Flutter | fl_chart | charts_flutter |
| SwiftUI | Swift Charts (nativo) | Charts SPM |
| Angular | ngx-charts | ApexCharts |
| Laravel | Chart.js (blade) | ApexCharts PHP |

### Reglas críticas para charts

- **Leyenda visible siempre** — nunca bajo un scroll fold
- **Tooltip en hover (web) y tap (mobile)** con valor exacto
- **Accesibilidad:** proveer tabla alternativa para lectores de pantalla
- **No depender solo del color** — añadir patrones o formas para daltónicos
- **Datasets grandes (1000+):** agregar o muestrear, nunca renderizar todo
- **Estado vacío:** mostrar mensaje + guía, no un eje vacío
- **Error:** mostrar mensaje de error + botón retry, no chart roto

---

## Decisiones de Layout por Dispositivo

### Mobile (< 768px)

```
Contenedor:     100% width, padding horizontal 16px
Navegación:     Bottom tab bar (máx. 5 items) o Top app bar
Tipografía:     Base 16px, heading máx. 32px
Imágenes:       full-width o aspect-ratio 4:3
Cards:          full-width o 2 columnas en grillas simples
Formularios:    1 columna, input height mínimo 44px
Charts:         Bar horizontal preferido, simplificar en pantalla chica
Modales:        Bottom sheet (slide up desde abajo)
Espaciado:      Sistema 4/8dp estricto
```

### Tablet (768px - 1023px)

```
Contenedor:     max-width 720px centrado, o 2 columnas
Navegación:     Bottom nav o sidebar colapsada
Tipografía:     Escalar 10-15% respecto a mobile
Cards:          2 o 3 columnas
Formularios:    2 columnas donde tenga sentido
Charts:         Full width disponible, añadir más detalle
Modales:        Centro de pantalla, max-width 480px
```

### Desktop (1024px - 1439px)

```
Contenedor:     max-width 1280px centrado, padding 24-32px
Navegación:     Sidebar fija o Top navbar
Tipografía:     Escala completa, heading hasta 64px
Cards:          3-4 columnas
Formularios:    2 columnas o formulario compacto lateral
Charts:         Múltiples charts en grid
Modales:        Centro, max-width 640px, con overlay scrim
Espaciado:      Sistema 8px / múltiplos de 8
```

### Breakpoints estándar (Tailwind)

```css
sm:  640px   /* Teléfonos grandes */
md:  768px   /* Tablets portrait */
lg:  1024px  /* Tablets landscape / laptop pequeño */
xl:  1280px  /* Desktop estándar */
2xl: 1536px  /* Desktop grande */
```

---

## Categorías de Reglas UX por Prioridad

| Prioridad | Categoría | Impacto |
|-----------|-----------|---------|
| 1 | Accesibilidad | CRÍTICO |
| 2 | Interacción táctil | CRÍTICO |
| 3 | Rendimiento visual | ALTO |
| 4 | Selección de estilo | ALTO |
| 5 | Layout y responsive | ALTO |
| 6 | Tipografía y color | MEDIO |
| 7 | Animación | MEDIO |
| 8 | Formularios y feedback | MEDIO |
| 9 | Navegación | ALTO |
| 10 | Charts y datos | BAJO |

---

## Referencia Rápida — Reglas Críticas

### 1. Accesibilidad (CRÍTICO)

- **Contraste de color:** mínimo 4.5:1 para texto normal, 3:1 para texto grande
- **Focus states:** anillo de foco visible en todos los elementos interactivos (2-4px)
- **Alt text:** texto alternativo descriptivo en imágenes significativas
- **Aria-labels:** `aria-label` en botones solo con ícono
- **Navegación por teclado:** orden de tab coincide con orden visual
- **Labels de formulario:** usar `<label for>` en todos los inputs
- **No depender solo de color:** añadir ícono o texto para info funcional
- **Dynamic Type:** soportar escalado de texto del sistema sin truncar
- **Reduced motion:** respetar `prefers-reduced-motion`

### 2. Interacción táctil (CRÍTICO)

- **Tamaño mínimo de toque:** 44x44pt (Apple) / 48x48dp (Material)
- **Separación entre targets:** mínimo 8px/dp entre elementos tocables
- **No depender de hover:** click/tap para interacciones primarias
- **Botones en carga:** deshabilitar durante operaciones async, mostrar spinner
- **Cursor pointer:** añadir en elementos clicables (web)
- **touch-action: manipulation:** eliminar delay de 300ms en web
- **Feedback táctil háptico:** para confirmaciones importantes (iOS)

### 3. Rendimiento visual (ALTO)

- **Imágenes:** WebP/AVIF, srcset/sizes, lazy load fuera del fold
- **Dimensiones de imagen:** declarar width/height para evitar CLS
- **Font loading:** `font-display: swap` para evitar texto invisible
- **Listas largas:** virtualizar listas con 50+ elementos
- **Skeleton screens:** usar en lugar de spinners para cargas > 1s
- **Input latency:** mantener bajo 100ms para taps/scroll

### 4. Estilo (ALTO)

- **Consistencia total:** mismo estilo en todas las páginas
- **No emojis como íconos:** usar SVG (Heroicons, Lucide, Phosphor)
- **Effects match style:** sombras, blur y radio alineados al estilo elegido
- **Dark mode:** diseñar light y dark juntos, no inferir uno del otro
- **Solo 1 CTA primario por pantalla:** acciones secundarias visualmente subordinadas

### 5. Layout y Responsive (ALTO)

- **viewport meta:** `width=device-width, initial-scale=1` (nunca deshabilitar zoom)
- **Mobile-first:** diseñar móvil primero, escalar a desktop
- **No scroll horizontal** en móvil
- **min-h-dvh** en lugar de `100vh` en móvil
- **Safe areas:** respetar notch, Dynamic Island, barra home

### 6. Tipografía y Color (MEDIO)

- **Line-height:** 1.5-1.75 para texto de cuerpo
- **Tokens semánticos:** usar `primary`, `error`, `surface`, etc. — nunca hex directo en componentes
- **Dark mode:** usar variantes desaturadas/más claras, no invertir colores
- **Pares accesibles:** verificar contraste 4.5:1 (AA) o 7:1 (AAA) con herramientas

### 7. Animación (MEDIO)

- **Duración:** 150-300ms para microinteracciones, máx. 400ms para transiciones complejas
- **Solo transform/opacity:** nunca animar width/height/top/left
- **Spring physics:** preferir curvas físicas sobre cubic-bezier lineal
- **Exit más rápido que enter:** la salida debe ser ~60-70% de la duración de entrada
- **Interruptible:** toda animación puede cancelarse con un tap/gesto
- **No bloquear input** durante animaciones

### 8. Formularios y Feedback (MEDIO)

- **Label visible** por input (no solo placeholder)
- **Error debajo del campo** relacionado, nunca solo al tope
- **Validar al perder foco** (blur), no en cada keystroke
- **Tipos de input correctos:** `email`, `tel`, `number` para teclado correcto en móvil
- **Toggle de contraseña:** show/hide en campos de password
- **Multi-step:** mostrar indicador de progreso, permitir retroceder
- **Errores con recovery:** siempre incluir cómo solucionar el error

### 9. Navegación (ALTO)

- **Bottom nav máx. 5 items** con íconos + etiquetas
- **Back behavior predecible** y consistente
- **Estado activo visible** en el ítem de navegación actual
- **No mezclar Tab + Sidebar + Bottom Nav** en el mismo nivel de jerarquía
- **Modales con cierre claro:** swipe down en móvil, X visible
- **Deep linking** en todas las pantallas clave

### 10. Charts y Datos (BAJO)

- **Chart type correcto** para el tipo de dato (ver tabla anterior)
- **Colores accesibles:** evitar pares rojo/verde solos
- **Siempre leyenda visible** — no bajo scroll
- **Tooltip en interacción** con valores exactos
- **Tabla alternativa** para accesibilidad con lectores de pantalla

---

## Checklist Pre-Entrega

### Calidad Visual
- [ ] Sin emojis usados como íconos
- [ ] Íconos de una familia consistente con estilo unificado
- [ ] Tokens de color semánticos usados en todos los componentes
- [ ] Estados de press/focus/disabled visualmente claros

### Interacción
- [ ] Todos los elementos tocables tienen feedback visual
- [ ] Targets táctiles >= 44x44pt (iOS) / 48x48dp (Android)
- [ ] Microinteracciones en rango 150-300ms
- [ ] Orden de focus para teclado/screen reader correcto

### Modos Claro/Oscuro
- [ ] Contraste de texto primario >= 4.5:1 en ambos modos
- [ ] Contraste de texto secundario >= 3:1 en ambos modos
- [ ] Bordes y separadores visibles en ambos modos
- [ ] Scrim de modal/drawer con opacidad 40-60%

### Layout
- [ ] Safe areas respetadas en headers, tab bars y CTAs fijos
- [ ] Contenido no oculto detrás de barras fijas
- [ ] Verificado en teléfono pequeño (375px) y tablet
- [ ] Gutters horizontales adaptados por breakpoint
- [ ] Sistema de espaciado 4/8dp consistente

### Accesibilidad
- [ ] Imágenes e íconos significativos con labels
- [ ] Formularios con labels, hints y mensajes de error claros
- [ ] Color no es el único indicador de información
- [ ] Reduced motion y Dynamic Type soportados
- [ ] Roles y estados de accesibilidad anunciados correctamente

---

## Reglas de Íconos e Imágenes

| Regla | Hacer | Evitar |
|-------|-------|--------|
| **Sin emojis estructurales** | Phosphor, Heroicons, Lucide, SF Symbols | Emojis en navegación o controles |
| **Solo vectores** | SVG o íconos de plataforma | PNG rasterizados que se pixelan |
| **Tamaño mínimo tocable** | Mínimo 44x44pt con `hitSlop` si es necesario | Íconos pequeños sin área de toque extendida |
| **Estilo consistente** | Una familia de íconos, misma línea/relleno | Mezclar outline y filled en el mismo nivel |
| **Ancho de trazo consistente** | 1.5px o 2px en toda la app | Mezclar trazos gruesos y finos arbitrariamente |
| **Contraste de ícono** | WCAG 4.5:1 para íconos pequeños, 3:1 para grandes | Íconos de bajo contraste que se pierden |

**Jerarquía de librerías de íconos:**
1. **Phosphor** (`@phosphor-icons/react`) — primera opción
2. **Heroicons** (`@heroicons/react`) — si Phosphor no tiene lo que necesitas
3. **Lucide** — alternativa moderna para proyectos Tailwind/shadcn
4. **SF Symbols** — obligatorio en SwiftUI / iOS nativo
5. **Material Symbols** — obligatorio en Android / Jetpack Compose

---

## Stacks — Guías de Implementación

### React / Next.js

```bash
# Componentes recomendados
shadcn/ui + Tailwind CSS    # Base de componentes
Framer Motion               # Animaciones
Recharts o Nivo             # Charts
next/image                  # Optimización de imágenes (WebP automático)
next/font                   # Fuentes optimizadas

# Patrones de rendimiento
- React.memo para componentes que reciben mismas props
- useMemo/useCallback para cálculos costosos
- Dynamic import para componentes pesados
- Suspense boundaries con skeleton screens
- Virtualización con @tanstack/virtual para listas largas
```

### Vue / Nuxt / Nuxt UI

```bash
# Stack recomendado
Nuxt UI v3 + Tailwind       # Componentes con dark mode automático
@nuxt/fonts                 # Fuentes optimizadas
Nuxt Image                  # Optimización automática

# Patrones
- Usar componentes Nuxt UI con slots para personalización
- defineProps con TypeScript para componentes tipados
- useColorMode() de @nuxtjs/color-mode para dark/light
```

### SwiftUI

```swift
// Patrones recomendados
- ViewModifier para estilos reutilizables
- Environment para color scheme y tamaño dinámico
- .accessibilityLabel() en todos los íconos sin texto
- .dynamicTypeSize(..) con rango de tamaños soportados
- SafeAreaInsets para layouts que respetan notch
- .sensoryFeedback() para feedback háptico (iOS 17+)
```

### React Native

```bash
# Stack recomendado
Expo + Expo Router          # Navegación basada en archivos
NativeWind 4.x              # Tailwind en React Native
React Navigation v7         # Si no usas Expo Router
Victory Native XL           # Charts optimizados para RN

# Reglas críticas
- Platform.select() para diferencias iOS/Android
- useWindowDimensions() en lugar de Dimensions.get
- KeyboardAvoidingView en formularios
- FlatList con windowSize y getItemLayout para rendimiento
- useSafeAreaInsets() para safe areas
```

### Flutter

```dart
// Patrones recomendados
- Material 3 con ColorScheme.fromSeed()
- ThemeData.light() y ThemeData.dark() desde el inicio
- Semantics widget para accesibilidad
- MediaQuery.of(context) para responsive
- flutter_screenutil para adaptación de tamaños
- fl_chart para visualizaciones
```

### Angular

```typescript
// Stack recomendado
Angular Material 3          // Componentes accesibles
ng-icons                    // Íconos
ngx-charts                  // Visualizaciones

// Patrones
- Signals para reactividad moderna
- OnPush change detection por defecto
- CDK Overlay para modales/tooltips
- RouterLink con preloading strategy
```

### Laravel (Frontend)

```php
// Stack frontend con Laravel
Livewire + Alpine.js        // Componentes reactivos sin SPA
Blade + Tailwind CSS         // Templates con utilidades
Laravel Folio + Volt         // Routing declarativo moderno
Chart.js                     // Charts en Blade

// Con Inertia.js
Inertia + React/Vue          // SPA sin API separada
shadcn/ui o Headless UI      // Componentes
```

---

## Problemas Comunes y Soluciones

| Problema | Causa probable | Solución |
|---------|---------------|----------|
| UI no se ve profesional | Sin sistema de diseño | Definir tokens: color, tipografía, espaciado |
| Contraste insuficiente en dark mode | Invertir colores light | Rediseñar paleta dark con variantes desaturadas |
| Animaciones se sienten raras | Curvas de easing incorrectas | ease-out para entrada, ease-in para salida, spring para interacciones |
| Formulario confuso | Solo placeholder como label | Añadir labels visibles siempre |
| Navegación confusa | Mezclar patrones de nav | Un solo patrón por nivel de jerarquía |
| Layout roto en móvil chico | No mobile-first | Diseñar desde 375px hacia arriba |
| Jank / lag en scroll | Sin virtualización | Virtualizar listas con 50+ elementos |
| Charts ilegibles en móvil | No responsive | Bar horizontal en móvil, simplificar ejes |
| Íconos pixelados | Usando PNG | Migrar a SVG o librería de íconos vectorial |
| Targets difíciles de tocar | Tamaño insuficiente | Mínimo 44x44pt, usar hitSlop |

---

## Workflow Completo — Ejemplo

**Request del usuario:** "Diseña una landing page para una app de finanzas personales"

### Paso 1 — Analizar el tipo de producto
- Tipo: Fintech / App de consumidor
- Audiencia: Adultos 25-40, smartphone
- Keywords: confianza, moderno, datos, simplicidad
- Stack: Next.js + Tailwind + shadcn/ui

### Paso 2 — Definir el sistema de diseño

**Estilo:** Flat + Material 3 (confianza + modernidad)

**Paleta:**
```
Primary:    #2563EB (blue-600) — confianza financiera
Secondary:  #10B981 (emerald-500) — crecimiento, dinero
Background: #F8FAFC (slate-50) — limpieza
Surface:    #FFFFFF — tarjetas
On-Surface: #1E293B (slate-800) — texto principal
Error:      #EF4444 (red-500)
```

**Tipografía:** Plus Jakarta Sans (heading 700) + Plus Jakarta Sans (body 400)
Escala: 14 / 16 / 20 / 24 / 32 / 48px

**Spacing:** Sistema de 8px (8, 16, 24, 32, 48, 64px)

### Paso 3 — Estructura de la landing

```
Hero:       Headline + CTA primario + mockup de app
Stats:      3 KPIs clave (números grandes)
Features:   3 features en grid (íconos + descripción corta)
Social:     Testimonios o logos de partners
CTA Final:  Frase + botón de descarga
Footer:     Links + legal
```

### Paso 4 — Checklist antes de entregar

- [ ] Contraste verificado en hero y todas las secciones
- [ ] CTA primario único y prominente
- [ ] Responsive desde 375px
- [ ] Imágenes en WebP con dimensiones declaradas
- [ ] Animaciones de entrada con Framer Motion (motion.div, `opacity`, `y`)
- [ ] Font preloaded via `next/font`
- [ ] Alt text en imagen de mockup
