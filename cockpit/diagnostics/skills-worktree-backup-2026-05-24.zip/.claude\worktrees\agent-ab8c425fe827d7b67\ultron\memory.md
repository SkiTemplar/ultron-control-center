# ULTRON — MEMORY SYSTEM · v7.0

> Cargar cuando se trabaja con memoria, contexto cross-sesión, o proyectos activos.

---

## § CC WAKE-UP — Inicio de sesión con contexto activo

**Cuándo ejecutar:** Rodrigo dice "en qué estaba" / "continua con X" / nombra un proyecto / HIGH o ULTRA arranca con proyecto activo implícito.

```
# Herramienta CC (no comando shell) — ordenar por mtime, más reciente primero
Glob: ~/.claude/projects/*/MEMORY.md
```

1. Si hay match con el nombre del proyecto mencionado → leer ese MEMORY.md
2. Si no hay nombre explícito → leer el de mtime más reciente
3. Si `mtime > 7 días`: *"Memoria CC de [proyecto] tiene [N] días — ¿algo cambió desde entonces?"*
4. Reportar: `[PROYECTO ACTIVO: X — última sesión: FECHA]` + 3-5 bullets del estado actual
5. Si no existe ningún directorio `~/.claude/projects/*/`: *"No encuentro memoria CC de proyectos — ¿hay algo en marcha?"*

**No asumir que la memoria CC es completa** si hubo sesiones en Desktop. Ver `§ SYNC CC↔DESKTOP`.

---

## AUTO-UPDATE CC (guardar sin que Rodrigo lo pida)

| Trigger en conversación | Tipo | Cuándo guardar |
|---|---|---|
| Rodrigo corrige enfoque / estilo / preferencia explícita | `feedback` | **Inmediato** |
| Decisión de arquitectura o diseño en proyecto | `project` | **Inmediato** |
| Rodrigo menciona contexto / nivel / rol nuevo | `user` | **Inmediato** |
| Recurso externo valioso (doc, repo, tablero) | `reference` | Fin de sesión |
| Técnico importante del proyecto (constraints, bugs) | `project` | Fin sesión MEDIUM+ |

### Cómo guardar en CC

```bash
# Archivo: ~/.claude/projects/<proyecto>/memory/<tipo>_<descripcion>.md
# Frontmatter obligatorio:
---
name: <nombre>
description: <una línea — se usa para decidir relevancia>
type: feedback | project | user | reference
---
<contenido>
```

Actualizar MEMORY.md índice: `- [Título](archivo.md) — hook ≤150 chars`
**RITUAL DE CIERRE (MEDIUM+ — obligatorio):** antes de decir "listo", auditoría de 30s:
□ ¿Rodrigo reveló preferencia/corrección? → `feedback` — guardar inmediato
□ ¿Decisión de arquitectura o diseño tomada? → `project` — guardar inmediato
□ ¿Nuevo contexto de Rodrigo (rol, nivel, herramienta)? → `user` — guardar inmediato
□ ¿Recurso externo valioso encontrado? → `reference` — guardar fin de sesión
Si alguna caja es ✓ → escribir la memoria AHORA, antes del mensaje final.

---

## ESTRUCTURA PERSISTENTE

```
C:\Users\Rodrigo\.ultron\           (Desktop/Desktop Commander)
├── INDEX.md                        leer al arrancar [solo Desktop]
├── archive\                        entradas obsoletas — nunca borrar
├── global\
│   ├── skill-registry.md           mapa de invocación de todas las skills
│   ├── skill-usage.md              qué funciona mejor para qué patrón
│   ├── decisions.md                decisiones arquitectónicas históricas
│   └── patterns.md                 patrones de trabajo de Rodrigo
├── knowledge\                      técnico por dominio
│   ├── cpp-ue5\                    replicación, Seamless Travel, gotchas
│   ├── supabase\                   auth gotchas, GoTrue bugs
│   └── [otros dominios]
├── projects\<nombre>\
│   ├── PROJECT.md                  estado actual del proyecto
│   ├── memory.md                   decisiones y contexto
│   ├── benchmark.md [SAGRADO]      historial de notas
│   └── log.md                      log de sesiones
└── sessions\                       YYYY-MM-DD.md por fecha

C:\Users\Rodrigo\.claude\projects\<proyecto>\memory\  (CC)
└── <tipo>_<descripcion>.md         con frontmatter type:
```

---

## ARSENAL DE HERRAMIENTAS CC

| Herramienta | Para qué |
|---|---|
| **Read / Edit / Write** | Archivos locales · memoria persistente |
| **Bash** | Scripts · análisis · procesamiento |
| **WebSearch / WebFetch** | Información externa · documentación |
| **Notion MCP** | Base de conocimiento de Rodrigo |
| **Gmail / GCal MCP** | Comunicación y agenda |
| **Supabase MCP** | Bases de datos en proyectos web |
| **Playwright MCP** | Browser automation · GitHub navegación |
| **Context7 MCP** | Docs oficiales (HIGH/ULTRA: obligatorio) |
| **Sequential Thinking MCP** | Razonamiento estructurado en pasos |

---

## SYNC CC↔DESKTOP

CC (`~/.claude/projects/<proj>/memory/`) y Desktop (`~/.ultron/projects/<nombre>/`) son estructuras distintas sin sync automático.

Señal de divergencia: Rodrigo menciona proyecto activo en CC pero la última sesión conocida fue en Desktop (o viceversa).

Protocolo ejecutable (al inicio de HIGH/ULTRA si hay proyecto activo):
```
# Herramienta CC nativa (no shell)
Glob: ~/.claude/projects/*/memory/   → ordenar por mtime, más reciente primero
```
→ Si la fecha más reciente es >7 días: *"Última memoria CC de [proyecto] modificada hace X días — ¿hubo sesiones en Desktop desde entonces?"*
→ Si no existe directorio: *"No encuentro memoria CC para este proyecto — ¿está en Desktop?"*
No asumir que la memoria CC es completa si hubo sesiones previas en Desktop, ni viceversa.

**Tratamiento tras confirmación de divergencia:**
→ Si Rodrigo confirma sesiones Desktop recientes: *"¿Quieres resumirme los cambios clave? Marcaré el contexto CC como posiblemente incompleto hasta entonces."* + añadir advertencia `[CC_STALE: sincronizar con Desktop]` en decisiones del proyecto durante esa sesión.
→ Si Rodrigo dice que no hubo sesiones Desktop (o no hay proyecto activo en Desktop): continuar con memoria CC como fuente completa sin advertencia.

---

## PROYECTOS ACTIVOS

Ver `~/.ultron/INDEX.md` para estado actual (solo Desktop).
En CC: leer `~/.claude/projects/<proj>/MEMORY.md` o pedir a Rodrigo qué proyecto es activo.
