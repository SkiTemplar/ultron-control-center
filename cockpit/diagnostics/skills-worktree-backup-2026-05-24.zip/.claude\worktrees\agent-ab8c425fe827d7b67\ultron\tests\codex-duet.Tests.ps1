# ULTRON v8.1.0 - Pester unit tests for codex-duet.ps1 helper
# Tests validation logic WITHOUT invoking Codex (fast, deterministic, free).
#
# Run: Invoke-Pester C:\Users\Rodrigo\.claude\skills\ultron\tests\codex-duet.Tests.ps1
#
# Pester 3.x compatible (Windows PowerShell 5.1 default).
# All tests use the helper's early-validation paths so they exit before any
# external CLI invocation. Net cost: ~0 tokens, ~0.5s per full suite.

$helper = Join-Path $PSScriptRoot "..\scripts\codex-duet.ps1"
$helper = (Resolve-Path $helper).Path

Describe "codex-duet helper - parameter validation" {

    It "exists and is parseable PowerShell" {
        Test-Path $helper | Should Be $true
        # Parse the script (will throw on syntax errors)
        $null = [scriptblock]::Create((Get-Content -Raw $helper))
    }

    It "rejects invalid Mode parameter" {
        { & $helper -Mode "InvalidMode" -Round 1 -Prompt "test" -ErrorAction Stop } | Should Throw
    }

    It "rejects MiniDual with Round != 1" {
        $err = $null
        try { & $helper -Mode Mini -Round 2 -Prompt "test" 2>&1 | Out-Null } catch { $err = $_ }
        # Either the helper throws or exits with non-zero; LASTEXITCODE captures the latter
        ($err -ne $null -or $LASTEXITCODE -ne 0) | Should Be $true
    }

    It "rejects Round > 1 without SessionId" {
        $err = $null
        try { & $helper -Mode Dual -Round 2 -Prompt "test" 2>&1 | Out-Null } catch { $err = $_ }
        ($err -ne $null -or $LASTEXITCODE -ne 0) | Should Be $true
    }

    It "rejects when neither -PromptFile nor -Prompt provided" {
        $err = $null
        try { & $helper -Mode Mini -Round 1 2>&1 | Out-Null } catch { $err = $_ }
        ($err -ne $null -or $LASTEXITCODE -ne 0) | Should Be $true
    }

    It "rejects non-existent PromptFile" {
        $bogus = Join-Path $env:TEMP "ultron-test-nonexistent-$(Get-Random).txt"
        $err = $null
        try { & $helper -Mode Mini -Round 1 -PromptFile $bogus 2>&1 | Out-Null } catch { $err = $_ }
        ($err -ne $null -or $LASTEXITCODE -ne 0) | Should Be $true
    }
}

Describe "codex-duet helper - file dependencies" {

    It "JSON schema file exists and is valid JSON" {
        $schema = Join-Path $PSScriptRoot "..\references\codex-duet-schema.json"
        Test-Path $schema | Should Be $true
        { Get-Content -Raw $schema | ConvertFrom-Json } | Should Not Throw
    }

    It "schema declares required Dual Mode response fields" {
        $schema = Join-Path $PSScriptRoot "..\references\codex-duet-schema.json"
        $parsed = Get-Content -Raw $schema | ConvertFrom-Json
        $parsed.required -contains "round_type" | Should Be $true
        $parsed.required -contains "verdict" | Should Be $true
        $parsed.required -contains "critique" | Should Be $true
        $parsed.required -contains "suggestions" | Should Be $true
    }

    It "node.exe is locatable (helper depends on it)" {
        $node = "C:\Program Files\nodejs\node.exe"
        if (-not (Test-Path $node)) {
            $node = (Get-Command node -ErrorAction SilentlyContinue).Source
        }
        Test-Path $node | Should Be $true
    }
}

Describe "codex-duet helper - script structure" {

    $content = Get-Content -Raw $helper

    It "uses Start-Process backend (refactor v8.0.1)" {
        $content -match 'Start-Process' | Should Be $true
    }

    It "passes --sandbox read-only in non-resume rounds" {
        $content -match "'--sandbox';\s+\`$argsList \+= 'read-only'" | Should Be $true
    }

    It "uses --ignore-user-config to avoid broken MCPs" {
        $content -match "'--ignore-user-config'" | Should Be $true
    }

    It "writes SESSION_ID to file (not just Write-Host)" {
        $content -match "last-session-id\.txt" | Should Be $true
    }

    It "handles resume with reduced flag set (gotcha #8)" {
        $content -match '\$isResume' | Should Be $true
    }

    It "extracts agent_message from STDERR for resume rounds" {
        $content -match "errFile" | Should Be $true
        $content -match "foundCodex" | Should Be $true
    }

    It "enforces hard caps via Test-DualCaps function (v8.1.2 fix 4.4)" {
        $content -match 'function Test-DualCaps' | Should Be $true
        $content -match 'dual-caps\.json' | Should Be $true
    }

    It "exposes BypassCaps switch for explicit Rodrigo override (v8.1.2 fix 4.4)" {
        $content -match '\[switch\]\$BypassCaps' | Should Be $true
    }

    It "Mini cap is unlimited, Dual=3, Max=1 (v8.1.2 fix 4.4)" {
        $content -match "Dual = 3; Max = 1" | Should Be $true
    }
}
