# Business Model & Pricing — Jordan Belfort

## Modelo Base: SaaS B2B con Licencia Recurrente

### Por qué licencia mensual y no venta única
- Flujo de caja predecible vs. impredecible
- Valoración del negocio: 5-10x ARR vs. 1-2x ingresos
- Con 100 clientes a €100/mes = €10.000/mes fijos sin esfuerzo adicional

---

## Modelos de Pricing

### Modelo A: Plano por Negocio (Recomendado para empezar)
Un precio fijo por negocio, independiente de usuarios o transacciones.
Ventaja: simple de entender, vender y cobrar.

```
STARTER      €49/mes  → 1 usuario, funciones core
PRO          €99/mes  → 3 usuarios, informes
BUSINESS    €199/mes  → usuarios ilimitados, API, soporte prioritario
```

### Modelo B: Por Módulos
Core barato + módulos de pago adicionales. Bueno para upsell natural.

### Modelo C: Por Transacciones/Volumen
Para cuando el valor escala directamente con el volumen del negocio.

---

## Estrategia de Precios (Fases)

### Fase validación (primeros 10 clientes)
- Precio "early adopter": 50% descuento durante 12 meses
- A cambio de: feedback activo + testimonios + referidos

### Fase crecimiento (10-50 clientes)
- Precio completo de mercado
- Descuento anual: 2 meses gratis (paga 10, obtén 12)
- Trial 14 días sin tarjeta

### Regla de Anchoring
Siempre presentar el plan más caro primero.
Si el cliente ve €199 primero, el €99 parece una ganga.

---

## Métricas Clave

```
MRR = Nº clientes × Precio medio mensual
→ Objetivo Mes 6:  €2.000 MRR (~25 clientes a €79/mes)
→ Objetivo Año 1:  €5.000 MRR (~50-60 clientes)
→ Objetivo Año 2:  €15.000 MRR (~150 clientes)

Churn mensual objetivo: <3%

LTV = Precio mensual / Churn
→ €99/mes con 3% churn = LTV de €3.300

CAC objetivo: <LTV/3 → Si LTV €3.300, CAC máximo €1.100
```

---

## Costes Fijos Estimados (Año 1)

```
Infraestructura (hosting, DB):  €100-300/mes
Herramientas (Stripe, etc.):     €50-100/mes
Dominio + SSL:                      €15/mes
Marketing básico:               €200-500/mes
─────────────────────────────────────────────
Total:                          €365-915/mes
```

Break-even:
- A €49/mes: 8-19 clientes
- A €99/mes: 4-10 clientes
- A €149/mes: 3-7 clientes → Con 20 clientes ya cubres costes cómodamente

---

## Consideraciones Legales (España)
- Facturación: Autónomo o SL (recomendado SL a partir de €30K/año)
- IVA: 21% para software (B2B: deducible para el cliente, no es un freno)
- Pagos recurrentes: Stripe España — el más sencillo para SaaS
- RGPD: si manejas datos de clientes finales, necesitas DPA
