# ULTRON — Routing Matrix
## Arbol de decisiones para enrutamiento

---

## ⚡ INSTANT ROUTING — Aplicar ANTES que el árbol completo

Para el 90% de los casos, la señal en el texto es suficiente. Enrutar sin deliberación:

| Si el texto contiene… | → Delegar a | Sin preguntar |
|---|---|---|
| `.cpp`, `.cs`, `.ts`, `.py`, `bug`, `error`, `commit`, `deploy`, `test`, `refactor` | **terry-davis** | ✓ |
| `UI`, `UX`, `diseño`, `interfaz`, `colores`, `layout`, `wireframe`, `mockup` | **mike-tyson** | ✓ |
| `monetizar`, `pricing`, `clientes`, `ventas`, `pitch`, `mercado`, `SaaS`, `competidores` | **jordan-belfort** | ✓ |
| `investiga`, `explica`, `aprendo`, `paper`, `ciencia`, `historia`, `filosofía` | **einstein** (excepción: C++/Gráfica/GPU/IA técnica/bajo nivel → **novalbos**) | ✓ |
| `email`, `reunión`, `agenda`, `calendario`, `Notion`, `Spotify`, `música`, `Blackboard` | **pana** | ✓ |
| `cinemática`, `dinámica`, `energía`, `colisión`, `sólido rígido`, `fluidos`, `examen Física` | **profesor-fisica** | ✓ |
| `gasto`, `fondo`, `KutxaBank`, `ahorro`, `presupuesto`, `movimientos bancarios` | **tio-gilito** | ✓ |
| `corrige`, `evalúa`, `nota`, `entrega académica`, `corrígeme el T` | **repo-evaluator** | ✓ |
| `proceso`, `registro`, `PowerShell`, `driver`, `RAM`, `CPU`, `carpeta local` | **alfred** | ✓ |
| `fútbol`, `partido`, `Liga`, `Champions`, `resultado` | **manolo-lama** | ✓ |
| `UE5`, `Unreal`, `Unity`, `Blueprint`, `GAS`, `netcode`, `game dev`, `PDVJ`, `shader de juego` | **don-claudio** | ✓ |
| `C++ profundo`, `shader`, `OpenGL`, `Vulkan`, `CUDA`, `SIMD`, `GPU`, `bajo nivel`, `ASM`, `compilador`, `backprop`, `transformer` | **novalbos** | ✓ |
| `capítulo`, `escena`, `personaje`, `plot`, `libro`, `narrativa`, `escribe la historia` | **tolkien** | ✓ |
| `bolsa`, `inversión`, `cartera`, `ETF`, `acciones`, `dividendos`, `mercado`, `análisis fundamental`, `¿compro X?` | **warren** | ✓ |

> **Fuente autoritativa:** SKILL.md FAST PATH es la fuente de verdad para routing.
> Este archivo es referencia complementaria — en caso de conflicto, SKILL.md tiene precedencia.
> **Tiebreak INSTANT ROUTING:** si el mensaje contiene `.cpp` Y `UE5`/`Unreal` simultáneamente → la fila de UE5 tiene precedencia sobre la fila de `.cpp`. Resultado: **don-claudio**.

**Si hay match → enrutar YA. Si no hay match claro → usar el árbol completo abajo.**

---

## ARBOL PRINCIPAL

¿La tarea es sobre proyectos/contexto de Rodrigo?
  SI → ULTRON directo (leer memoria, responder)

¿Involucra codigo o sistemas tecnicos?
  SI → terry-davis (+engineering:* si es complejo)
  Excepcion: archivos Windows → alfred
  Excepcion: codigo UE5/Unreal/Blueprint/GAS → don-claudio

¿Involucra investigacion o aprendizaje?
  SI → einstein
  Excepcion: C++/Gráfica/GPU/IA técnica/bajo nivel → novalbos

¿Involucra negocio o estrategia comercial?
  SI → jordan-belfort

¿Involucra diseno visual o UX?
  SI → mike-tyson

¿Involucra Gmail, Calendar, Notion, Spotify?
  SI → pana

¿Involucra fisica universitaria?
  SI → profesor-fisica

¿Involucra finanzas personales?
  SI → tio-gilito

¿Involucra evaluacion academica de codigo?
  SI → repo-evaluator

¿Involucra deportes/futbol?
  SI → manolo-lama

¿Involucra game dev, UE5, Unity, netcode, shaders de juego?
  SI → don-claudio

¿Involucra C++ profundo, GPU, OpenGL, Vulkan, CUDA, IA técnica, bajo nivel?
  SI → novalbos

¿Involucra inversiones, bolsa, ETF, mercados, análisis fundamental?
  SI → warren

¿Involucra narrativa, worldbuilding, personajes, escritura?
  SI → tolkien

¿Cruza multiples dominios?
  SI → ULTRON orquesta (divide y delega)

Ninguno → ULTRON ejecuta directamente

---

## SENALES POR DOMINIO

### Codigo
.cpp (sin UE5/Unreal) → terry-davis (+ feature-dev:code-architect si ADR)
.cpp + UE5/Unreal/Blueprint/GAS → don-claudio (ver SKILL.md FAST PATH)
.cs + Unity → terry-davis
.ts, React → terry-davis
bug/error → terry-davis (+ superpowers:systematic-debugging si produccion)
commit/PR → terry-davis (+ pr-review-toolkit:code-reviewer si audit)
deploy → terry-davis (+ superpowers:verification-before-completion si critico)

### Diseno
UI/UX, colores, tipografia → mike-tyson
accesibilidad, WCAG → mike-tyson (+ ui-ux-pro-max)
wireframe, mockup → mike-tyson

### Negocio
monetizar, pricing → jordan-belfort
clientes, pitch → jordan-belfort
competidores → jordan-belfort

### Game Dev
UE5, Unreal, Blueprint, GAS → don-claudio
Unity (sin .cs) → don-claudio
netcode, replicación, gameplay → don-claudio
shader de juego / material UE5 → don-claudio
.cs + Unity → terry-davis (tiebreak: .cs código → terry)
arquitectura de juego sin código → don-claudio

### C++ Bajo Nivel
C++ profundo, templates, SFINAE → novalbos
OpenGL, Vulkan, DX12, Metal → novalbos
CUDA, SIMD, AVX → novalbos
GPU pipeline, compute shaders → novalbos
backprop, transformer (implementación) → novalbos
ASM, compilador, linker → novalbos
apuntes técnicos → novalbos

### Investigación / Aprendizaje
investiga, explica, por qué X → einstein
paper, ciencia, teoría → einstein
investiga + dominio específico → persona de ese dominio (ver SKILL.md tiebreak einstein)
investiga + C++/GPU/bajo nivel → novalbos

### Física Universitaria
cinemática, dinámica, colisiones → profesor-fisica
mecánica, energía, trabajo, potencia → profesor-fisica
sólido rígido, inercia → profesor-fisica
examen Física, ejercicio Física → profesor-fisica
física + código → profesor-fisica (física), terry (implementa)

### Finanzas Personales
gasto, ahorro, presupuesto → tio-gilito
KutxaBank, banco, saldo → tio-gilito
movimientos bancarios, categorizar gastos → tio-gilito

### Inversiones
bolsa, acciones, ETF, dividendos → warren
cartera, análisis fundamental → warren
¿compro X?, macro, sector → warren
inversión + código → warren (valida), terry (implementa)

### Productividad Personal
email, Gmail → pana
Calendar, agenda, reunión → pana
Notion, Spotify → pana
briefing, organización personal → pana
operación sistema/PC → alfred (tiebreak sobre pana)

### Windows / Sistema
PowerShell, proceso, driver → alfred
carpeta local, registro Windows → alfred
RAM, CPU, gestión de sistema → alfred
archivo local, ruta Windows → alfred

### Deportes / Fútbol
fútbol, Liga, Champions → manolo-lama
partido, gol, resultado → manolo-lama
épica deportiva → manolo-lama

### Narrativa / Worldbuilding
capítulo, escena, personaje → tolkien
plot, estructura narrativa → tolkien
libro, historia, worldbuilding → tolkien

### Evaluación Académica
corrige, evalúa, ponme nota → repo-evaluator
entrega académica, repo universitario → repo-evaluator
kirkardo, corrígeme el T → repo-evaluator

---

## CUANDO HAY CONFLICTO

1. Codigo presente → Terry tiene prioridad (excepto: Windows → Alfred, Fisica → Profesor, UE5/Unreal → don-claudio)
2. Inversiones + código → Warren primero (valida/diseña), Terry implementa
3. Diseno + codigo → Mike primero (disena), luego Terry (implementa)
4. Investigacion + implementacion → Einstein (investiga) → Terry (implementa)
5. Todo mezclado → ULTRON divide en fases
6. Finanzas + codigo → Warren primero (valida/diseña), Terry implementa
7. Fisica + codigo → Profesor-fisica primero (define física), Terry implementa
