#!/usr/bin/env python3
"""
ULTRON v10.4 - Schedule Editor (terminal AI chat for schedule-config.json).

Edit schedule-config.json via natural language or direct toggles.
After any edit: reminds Rodrigo to run `ultron schedule install` to apply
changes to Windows Task Scheduler.

Usage:
    schedule_editor.py list                       Show task status
    schedule_editor.py enable <task-name>         Instant toggle
    schedule_editor.py disable <task-name>        Instant toggle
    schedule_editor.py edit <task> <query...>     AI edit (Haiku, dry-run)
    schedule_editor.py edit <task> ... --apply    Commit
    schedule_editor.py chat <query...>            Free-form (Sonnet, dry-run)
    schedule_editor.py chat ... --apply           Commit
"""
from __future__ import annotations

import argparse
import difflib
import json
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

sys.path.insert(0, str(Path(__file__).parent))
from cockpit_base import COCKPIT_DIR  # noqa: E402

SCHEDULE_JSON = COCKPIT_DIR / "schedule-config.json"
EDIT_MODEL = "claude-haiku-4-5"      # Single-task edits = simple JSON patch
CHAT_MODEL = "claude-sonnet-4-6"      # Multi-task / free-form = needs reasoning
EDIT_TIMEOUT = 60

VALID_FREQUENCIES = [
    "on_login", "once_per_day", "weekly_sunday", "weekly_friday",
    "weekly_monday", "weekday_morning", "every_10_minutes", "every_hour",
]


def load_config() -> dict:
    return json.loads(SCHEDULE_JSON.read_text(encoding="utf-8-sig"))


def save_config(data: dict) -> Path:
    if SCHEDULE_JSON.exists():
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = SCHEDULE_JSON.with_suffix(f".json.{stamp}.bak")
        shutil.copy2(SCHEDULE_JSON, backup)
        print(f"[schedule] Backup: {backup.name}")
    data["_last_updated"] = datetime.now().strftime("%Y-%m-%d")
    tmp = SCHEDULE_JSON.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(SCHEDULE_JSON)
    return SCHEDULE_JSON


def find_task(cfg: dict, name: str) -> tuple[str, dict] | None:
    tasks = cfg.get("tasks", {})
    if name in tasks:
        return name, tasks[name]
    q = name.lower()
    matches = [k for k in tasks.keys() if q in k.lower()]
    if len(matches) == 1:
        return matches[0], tasks[matches[0]]
    if len(matches) > 1:
        print(f"[schedule] Ambiguous '{name}': {matches}")
    return None


def cmd_list(_args) -> int:
    cfg = load_config()
    tasks = cfg.get("tasks", {})
    print(f"SCHEDULE TASKS ({len(tasks)})")
    print("=" * 80)
    print(f"{'Task':<30} {'Enabled':<8} {'Delay':>6} {'Frequency':<22}")
    print("-" * 80)
    for name in sorted(tasks.keys()):
        t = tasks[name]
        enabled = "✓ ON" if t.get("enabled") else "  off"
        delay = f"{t.get('delay_minutes', 0)}m"
        freq = t.get("frequency", "?")
        print(f"{name:<30} {enabled:<8} {delay:>6} {freq:<22}")
    print()
    print("To apply changes: ultron schedule install")
    return 0


def cmd_toggle(args, new_state: bool) -> int:
    cfg = load_config()
    found = find_task(cfg, args.task)
    if not found:
        print(f"[schedule] Task not found: {args.task}")
        return 1
    name, t = found
    old_state = t.get("enabled")
    if old_state == new_state:
        print(f"[schedule] {name} already {'enabled' if new_state else 'disabled'}.")
        return 0
    cfg["tasks"][name]["enabled"] = new_state
    save_config(cfg)
    state_word = "ENABLED" if new_state else "DISABLED"
    print(f"[schedule] {state_word}: {name}")
    print("Run: ultron schedule install   (to apply to Task Scheduler)")
    return 0


def call_claude(model: str, system: str, user: str) -> str | None:
    claude_bin = shutil.which("claude")
    if not claude_bin:
        print("[schedule] claude CLI not found in PATH", file=sys.stderr)
        return None
    cmd = [claude_bin, "--print", "--dangerously-skip-permissions",
           "--model", model, "--append-system-prompt", system, user]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True,
                                 timeout=EDIT_TIMEOUT, encoding="utf-8")
        if result.returncode != 0:
            print(f"[schedule] claude failed exit={result.returncode}", file=sys.stderr)
            if result.stderr:
                print(f"[schedule] stderr: {result.stderr[:300]}", file=sys.stderr)
            return None
        return (result.stdout or "").strip()
    except subprocess.TimeoutExpired:
        print(f"[schedule] timeout after {EDIT_TIMEOUT}s", file=sys.stderr)
        return None


def extract_json(text: str) -> dict | None:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        lines = cleaned.split("\n")
        if lines[-1].strip().startswith("```"):
            lines = lines[1:-1]
        else:
            lines = lines[1:]
        cleaned = "\n".join(lines)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError as e:
        print(f"[schedule] JSON parse failed: {e}", file=sys.stderr)
        return None


def cmd_edit(args) -> int:
    """Edit ONE task entry via Haiku (cheap, fast)."""
    cfg = load_config()
    found = find_task(cfg, args.task)
    if not found:
        print(f"[schedule] Task not found: {args.task}")
        return 1
    name, current = found

    system = (
        f"Editor de configuración de tarea programada. Schema: "
        f"{{enabled: bool, delay_minutes: int, frequency: str (one of "
        f"{VALID_FREQUENCIES}), description: str}}. Devuelve SOLO el JSON "
        f"modificado de la tarea (sin code fences, sin explicación). "
        f"Si la instrucción es ambigua, mantén lo existente."
    )
    user = (f"Tarea actual ({name}):\n{json.dumps(current, indent=2)}\n\n"
            f"Instrucción: {args.query}\n\n"
            f"Devuelve SOLO el JSON modificado completo de la tarea.")

    print(f"[schedule] Editing '{name}' via {EDIT_MODEL}...")
    response = call_claude(EDIT_MODEL, system, user)
    if not response:
        return 1
    new_entry = extract_json(response)
    if not new_entry:
        return 1
    if new_entry.get("frequency") and new_entry["frequency"] not in VALID_FREQUENCIES:
        print(f"[schedule] WARN: frequency '{new_entry['frequency']}' not in valid list")

    print()
    print("--- DIFF ---")
    for k in sorted(set(current) | set(new_entry)):
        if current.get(k) != new_entry.get(k):
            print(f"  {k}:\n    - {current.get(k)}\n    + {new_entry.get(k)}")
    print()

    if not args.apply:
        print("[schedule] Dry-run. Pass --apply to commit.")
        return 0
    cfg["tasks"][name] = new_entry
    save_config(cfg)
    print(f"[schedule] Updated: {name}")
    print("Run: ultron schedule install")
    return 0


def cmd_chat(args) -> int:
    """Free-form Sonnet edit across multiple tasks."""
    cfg = load_config()

    system = (
        f"Eres editor de schedule-config.json. Schema: "
        f"{{tasks: {{<name>: {{enabled, delay_minutes, frequency, description}}}}}}. "
        f"Frequencies válidas: {VALID_FREQUENCIES}. "
        f"Devuelve SOLO el JSON completo modificado del objeto 'tasks' "
        f"(sin _comment, sin _version, sin code fences). Mantén tareas no mencionadas."
    )
    user = (f"Tasks actuales:\n{json.dumps(cfg.get('tasks', {}), indent=2)}\n\n"
            f"Instrucción del usuario: {args.query}\n\n"
            f"Devuelve SOLO el objeto 'tasks' completo modificado.")

    print(f"[schedule] Chatting via {CHAT_MODEL}...")
    response = call_claude(CHAT_MODEL, system, user)
    if not response:
        return 1
    new_tasks = extract_json(response)
    if not new_tasks:
        return 1

    print()
    print("--- DIFF (per task) ---")
    old_tasks = cfg.get("tasks", {})
    all_keys = sorted(set(old_tasks) | set(new_tasks))
    changed = 0
    for k in all_keys:
        if old_tasks.get(k) != new_tasks.get(k):
            changed += 1
            print(f"\n  [{k}]")
            if k not in old_tasks:
                print(f"    NEW: {new_tasks[k]}")
            elif k not in new_tasks:
                print(f"    DELETED")
            else:
                for sk in sorted(set(old_tasks[k]) | set(new_tasks[k])):
                    if old_tasks[k].get(sk) != new_tasks[k].get(sk):
                        print(f"    {sk}: {old_tasks[k].get(sk)} → {new_tasks[k].get(sk)}")
    if changed == 0:
        print("  (no changes detected)")
        return 0

    if not args.apply:
        print()
        print("[schedule] Dry-run. Pass --apply to commit.")
        return 0
    cfg["tasks"] = new_tasks
    save_config(cfg)
    print(f"\n[schedule] Updated ({changed} task(s))")
    print("Run: ultron schedule install")
    return 0


def main():
    p = argparse.ArgumentParser(description="ULTRON Schedule Editor")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list").set_defaults(func=cmd_list)

    sp = sub.add_parser("enable")
    sp.add_argument("task")
    sp.set_defaults(func=lambda a: cmd_toggle(a, True))

    sp = sub.add_parser("disable")
    sp.add_argument("task")
    sp.set_defaults(func=lambda a: cmd_toggle(a, False))

    sp = sub.add_parser("edit")
    sp.add_argument("task")
    sp.add_argument("query", nargs="+")
    sp.add_argument("--apply", action="store_true")
    sp.set_defaults(func=lambda a: cmd_edit(_join(a, "query")))

    sp = sub.add_parser("chat")
    sp.add_argument("query", nargs="+")
    sp.add_argument("--apply", action="store_true")
    sp.set_defaults(func=lambda a: cmd_chat(_join(a, "query")))

    args = p.parse_args()
    return args.func(args)


def _join(args, attr):
    setattr(args, attr, " ".join(getattr(args, attr)))
    return args


if __name__ == "__main__":
    sys.exit(main())
