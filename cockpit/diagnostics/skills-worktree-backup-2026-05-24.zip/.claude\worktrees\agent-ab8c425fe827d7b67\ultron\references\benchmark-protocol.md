# BENCHMARK DE NOTAS — Protocolo Completo

**Triggers:** `benchmark de X` · `nota de X` · `cómo va X` · `puntuación del proyecto` · `estado de Tortunabo`

## Protocolo de ejecución

1. Leer PROJECT.md → extraer estado real (bugs, features, backlog, commits recientes)
2. Leer benchmark.md existente → obtener última entrada para calcular Δ
3. Puntuar cada dimensión (0.0–10.0) con 1 línea de justificación honesta
4. Calcular media → redondear a 1 decimal
5. **Append** en benchmark.md (NUNCA sobreescribir — el historial es SAGRADO)
6. Mostrar tabla con deltas al usuario

## Dimensiones

| Dimensión (proyectos de juego) | Dimensión (proyectos generales) | Mide |
|---|---|---|
| 🎮 MVP Progress | Progress | % features MVP implementadas y estables |
| 🔧 Code Quality | Code Quality | Limpieza, arquitectura, naming, deuda técnica |
| 🌐 Net Stability | Architecture | Replicación correcta / solidez arquitectónica |
| 🧪 Test Coverage | Documentation | Smoke tests validados / documentación |
| 📋 Backlog Health | Testing | Items bien definidos y priorizados |
| ⚡ Velocity | Velocity | Ritmo de cierre de bugs/features en la última sesión |

## Formato de entrada en benchmark.md

```
## YYYY-MM-DD | <contexto breve>

| Dimensión         | Nota | Δ    | Justificación              |
|-------------------|------|------|----------------------------|
| 🎮 MVP Progress   | X.X  | ↑+X  | <1 línea>                  |
| 🔧 Code Quality   | X.X  | →    | <1 línea>                  |
| 🌐 Net Stability  | X.X  | ↑+X  | <1 línea>                  |
| 🧪 Test Coverage  | X.X  | ↓-X  | <1 línea>                  |
| 📋 Backlog Health | X.X  | →    | <1 línea>                  |
| ⚡ Velocity       | X.X  | ↑+X  | <1 línea>                  |

**Media: X.X/10** ↑ vs anterior (X.X) | o "— (primera entrada)"
```

## Reglas

- Primera entrada: Δ = `—` en todas las dimensiones
- Δ siempre vs la entrada inmediatamente anterior
- Nunca inventar — si faltan datos en PROJECT.md, indicarlo y pedir contexto
- Si no existe `benchmark.md` → crearlo con la primera entrada
- El historial de benchmark es `[SAGRADO]` — append only, nunca modificar entradas anteriores
