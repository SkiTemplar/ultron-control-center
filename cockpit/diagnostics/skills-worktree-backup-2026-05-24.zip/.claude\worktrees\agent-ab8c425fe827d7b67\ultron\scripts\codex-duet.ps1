# ULTRON v8.0 Dual Mode — Codex CLI helper (refactored v8.0.1)
# Invokes Codex with sandbox=read-only, captures session_id for round 2+ resume.
# Backend for /minidual /dual /maxdual overlays.
#
# Refactor v8.0.1: Start-Process -RedirectStandardInput with prompt file.
# More predictable than cmd /c with stdin redirect, works on Windows PowerShell 5.1
# (which lacks ArgumentList collection, Kill($true), and reliable ReadToEndAsync).
#
# See knowledge: ~/.ultron/knowledge/claude-platform/codex-cli.md

[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateSet('Mini','Dual','Max')][string]$Mode,
    [Parameter(Mandatory)][int]$Round,
    [string]$PromptFile,
    [string]$Prompt,
    # v10.4 H: prompt template support. -PromptTemplate <md-file> with {TASK},
    # {CONTEXT}, {TARGET}, {ROLE} placeholders. -TemplateVars '<json>' fills them.
    # Templates live in references/prompt-templates/ (eval.md, critique.md, etc).
    [string]$PromptTemplate,
    [string]$TemplateVars,
    [string]$SessionId,
    [string]$Model = 'gpt-5.5',
    # Fallback intentionally empty by default: with ChatGPT auth, only gpt-5.5 is supported.
    # Set to a different model (e.g. 'gpt-5.4-codex') if you have API key auth.
    [string]$FallbackModel = '',
    [string]$OutputDir = (Join-Path $env:TEMP 'ultron-duet'),
    [int]$TimeoutSec = 180,
    # v8.1.2: hard cap enforcement via per-session counter file. Skip with -BypassCaps
    # (Rodrigo can override after explicit confirmation). Caps: Mini=unlimited, Dual=3, Max=1
    [switch]$BypassCaps
)

$ErrorActionPreference = 'Stop'

# ── v8.1.2: Hard cap enforcement (4.4 fix) ───────────────────────────────────
# Counter file lives at ~/.ultron/sessions/<YYYY-MM-DD>/dual-caps.json.
# Only round 1 of Dual/Max counts as "an invocation"; subsequent rounds within the
# same invocation share session_id, so don't double-count.
function Test-DualCaps {
    param([string]$Mode, [int]$Round, [bool]$Bypass)

    if ($Bypass) {
        Write-Host "[Dual] Caps bypassed via -BypassCaps flag (Rodrigo override)"
        return
    }
    # MiniDual: unlimited per design (each call is a 1-round sanity check)
    if ($Mode -eq 'Mini') { return }
    # Only count the first round of a multi-round invocation
    if ($Round -ne 1) { return }

    $today = Get-Date -Format 'yyyy-MM-dd'
    $sessionDir = Join-Path $env:USERPROFILE ".ultron\sessions\$today"
    New-Item -ItemType Directory -Force -Path $sessionDir | Out-Null
    $capFile = Join-Path $sessionDir 'dual-caps.json'

    $caps = if (Test-Path $capFile) {
        try { Get-Content -Raw $capFile | ConvertFrom-Json } catch { $null }
    } else { $null }
    if (-not $caps) {
        $caps = [pscustomobject]@{ mini = 0; dual = 0; max = 0 }
    }

    $limits = @{ Dual = 3; Max = 1 }
    $key = $Mode.ToLower()
    $current = [int]$caps.$key

    if ($current -ge $limits[$Mode]) {
        Write-Error ("[Dual] Hard cap reached for $Mode mode: " +
                     "$current/$($limits[$Mode]) invocations today. " +
                     "Pass -BypassCaps if Rodrigo confirms explicit override. " +
                     "Counter file: $capFile")
        exit 7
    }

    $caps.$key = $current + 1
    $caps | ConvertTo-Json -Compress | Set-Content -Path $capFile -Encoding utf8 -NoNewline
    Write-Host "[Dual] Cap counter: $Mode = $($caps.$key)/$($limits[$Mode]) today"
}

Test-DualCaps -Mode $Mode -Round $Round -Bypass:$BypassCaps

# ── Resolve binaries ─────────────────────────────────────────────────────────
# Invoke node.exe with codex.js directly (skip codex.cmd/.ps1 wrappers — they
# pipe stdin from PowerShell which Codex rejects with "stdin is not a terminal").
$nodeExe = "C:\Program Files\nodejs\node.exe"
if (-not (Test-Path $nodeExe)) {
    $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
    if ($nodeCmd) { $nodeExe = $nodeCmd.Source }
}
if (-not (Test-Path $nodeExe)) {
    Write-Error "Node.js not found. Install Node.js to use Codex CLI."
    exit 1
}

$codexJs = "$env:APPDATA\npm\node_modules\@openai\codex\bin\codex.js"
if (-not (Test-Path $codexJs)) {
    Write-Error "Codex CLI not found at $codexJs. Install with: npm i -g @openai/codex"
    exit 1
}

# ── Resolve prompt and write to file (Start-Process needs a file for stdin) ──
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$promptTmpFile = Join-Path $OutputDir "prompt-r$Round-$timestamp.txt"

if ($PromptTemplate) {
    # Resolve template path: relative to references/prompt-templates/ if not absolute
    if (-not [System.IO.Path]::IsPathRooted($PromptTemplate)) {
        $tmplDir = (Resolve-Path (Join-Path $PSScriptRoot '..\references\prompt-templates')).Path
        $tmplPath = Join-Path $tmplDir $PromptTemplate
    } else {
        $tmplPath = $PromptTemplate
    }
    if (-not (Test-Path $tmplPath)) {
        Write-Error "Prompt template not found: $tmplPath"
        exit 2
    }
    $promptText = Get-Content -Raw $tmplPath
    if ($TemplateVars) {
        try {
            $vars = $TemplateVars | ConvertFrom-Json
            foreach ($key in $vars.PSObject.Properties.Name) {
                $placeholder = '{' + $key + '}'
                $value = [string]$vars.$key
                $promptText = $promptText.Replace($placeholder, $value)
            }
        } catch {
            Write-Error "Failed to parse -TemplateVars JSON: $_"
            exit 2
        }
    }
} elseif ($PromptFile) {
    if (-not (Test-Path $PromptFile)) {
        Write-Error "Prompt file not found: $PromptFile"
        exit 2
    }
    $promptText = Get-Content -Raw $PromptFile
} elseif ($Prompt) {
    $promptText = $Prompt
} else {
    Write-Error "One of -PromptTemplate, -PromptFile, or -Prompt must be provided"
    exit 3
}
[System.IO.File]::WriteAllText($promptTmpFile, $promptText, (New-Object System.Text.UTF8Encoding $false))

# ── Setup output paths ───────────────────────────────────────────────────────
$outFile = Join-Path $OutputDir "round-$Round-$timestamp.json"
$logFile = Join-Path $OutputDir "round-$Round-$timestamp.jsonl"
$errFile = Join-Path $OutputDir "round-$Round-$timestamp.err.txt"
$schemaFile = (Resolve-Path (Join-Path $PSScriptRoot '..\references\codex-duet-schema.json')).Path

# ── Validate gating ──────────────────────────────────────────────────────────
if ($Mode -eq 'Mini' -and $Round -ne 1) {
    Write-Error "MiniDual is single-round (received Round=$Round)"
    exit 4
}
if ($Round -gt 1 -and -not $SessionId) {
    Write-Error "Round $Round requires -SessionId from a previous round"
    exit 5
}

# ── Build argument string (PS 5.1 Start-Process needs string Arguments) ──────
function Quote-Arg([string]$s) {
    if ($s -match '\s|"') { return '"' + ($s -replace '"','\"') + '"' }
    return $s
}

$argsList = @()
$argsList += Quote-Arg $codexJs
$argsList += 'exec'

# Per `codex exec resume --help`, the 'resume' subcommand has a REDUCED flag set:
# only -c, --last, --all, --enable, --disable, -i, -m, --full-auto are accepted.
# It does NOT accept --sandbox, --output-schema, -o, --json, --skip-git-repo-check,
# or --ignore-user-config. Sandbox/config are inherited from the original session.
# So rounds 2+ use a minimal arg set and we extract the JSON from stdout manually.
$isResume = ($Round -gt 1 -and $Mode -ne 'Mini')

if ($Mode -eq 'Mini') {
    $argsList += '--ephemeral'
}
if ($isResume) {
    $argsList += 'resume'
    # 'resume'-only flags
    $argsList += '-m'; $argsList += $Model
    $argsList += $SessionId   # positional SESSION_ID before PROMPT
} else {
    # Round 1 (Mini/Dual/Max): full flag set
    $argsList += '--sandbox';          $argsList += 'read-only'
    $argsList += '-m';                  $argsList += $Model
    $argsList += '--output-schema';    $argsList += (Quote-Arg $schemaFile)
    $argsList += '-o';                  $argsList += (Quote-Arg $outFile)
    $argsList += '--json'
    $argsList += '--skip-git-repo-check'
    $argsList += '--ignore-user-config'
}

$argsList += '-'   # read prompt from stdin (positional PROMPT arg)

$argString = $argsList -join ' '

# ── Invoke via Start-Process with stdin redirected from prompt file ──────────
function Invoke-CodexProcess {
    param([string]$NodeExe, [string]$ArgString, [string]$PromptFilePath,
          [string]$StdoutPath, [string]$StderrPath, [int]$TimeoutSec)

    $proc = Start-Process -FilePath $NodeExe `
                          -ArgumentList $ArgString `
                          -RedirectStandardInput $PromptFilePath `
                          -RedirectStandardOutput $StdoutPath `
                          -RedirectStandardError $StderrPath `
                          -NoNewWindow -PassThru

    if (-not $proc.WaitForExit($TimeoutSec * 1000)) {
        try { $proc.Kill() } catch {}
        Write-Warning "Codex timed out after $TimeoutSec seconds - process killed"
        return 124
    }
    return $proc.ExitCode
}

Write-Host "[Dual] Mode=$Mode Round=$Round Model=$Model Sandbox=read-only Timeout=${TimeoutSec}s"
$startTime = Get-Date

$exitCode = Invoke-CodexProcess -NodeExe $nodeExe -ArgString $argString `
                                -PromptFilePath $promptTmpFile `
                                -StdoutPath $logFile -StderrPath $errFile `
                                -TimeoutSec $TimeoutSec

# Auth-error fallback to alternate model
if ($exitCode -ne 0 -and $FallbackModel -and $Model -ne $FallbackModel) {
    Write-Warning "Primary model ($Model) failed (exit=$exitCode), retrying with $FallbackModel"
    $argString = $argString -replace [regex]::Escape(" -m $Model "), " -m $FallbackModel "
    $exitCode = Invoke-CodexProcess -NodeExe $nodeExe -ArgString $argString `
                                    -PromptFilePath $promptTmpFile `
                                    -StdoutPath $logFile -StderrPath $errFile `
                                    -TimeoutSec $TimeoutSec
}

# ── For resume rounds: extract agent_message from STDERR into $outFile ───────
# (resume doesn't support -o or --json. Codex prints the human-readable response
# to STDERR after a "codex\n" marker line. We parse that text and write to $outFile.)
if ($isResume) {
    foreach ($srcFile in @($errFile, $logFile)) {
        if (-not (Test-Path $srcFile)) { continue }
        try {
            $srcLines = Get-Content $srcFile
            $foundCodex = $false
            $captured = @()
            foreach ($line in $srcLines) {
                if ($foundCodex) {
                    # Stop at next section marker or telemetry
                    if ($line -match '^\s*$' -and $captured.Count -gt 0) { break }
                    if ($line -match '^(tokens used|--------|user)\s*$') { break }
                    if ($line -match '^\d{4}-\d{2}-\d{2}T.*ERROR') { continue }   # skip MCP warnings
                    $captured += $line
                } elseif ($line -match '^codex\s*$') {
                    $foundCodex = $true
                }
            }
            if ($captured.Count -gt 0) {
                $extracted = ($captured -join "`n").Trim()
                Set-Content -Path $outFile -Value $extracted -Encoding utf8 -NoNewline
                break
            }
        } catch {
            Write-Warning "Failed to extract from $srcFile : $($_.Exception.Message)"
        }
    }
}

# ── Determine success: prefer file-existence + JSON validity over exit code ──
$outOk = $false
$jsonValid = $false
if (Test-Path $outFile) {
    $outSize = (Get-Item $outFile).Length
    if ($outSize -gt 0) {
        $outOk = $true
        try {
            $null = Get-Content -Raw $outFile | ConvertFrom-Json
            $jsonValid = $true
        } catch {
            Write-Warning "Output file exists but contains invalid JSON: $($_.Exception.Message)"
        }
    }
}

if (-not $outOk) {
    if (Test-Path $errFile) {
        $errContent = Get-Content -Raw $errFile
        if ($errContent) { Write-Warning "Stderr: $errContent" }
    }
    Write-Error "Codex exec failed (exit=$exitCode, no valid output file). See log: $logFile"
    exit 1
}
if (-not $jsonValid) {
    Write-Error "Codex output is not valid JSON. See: $outFile"
    exit 6
}

# ── Extract session_id (thread_id) for resume in rounds 2+ ───────────────────
if ($Round -eq 1 -and $Mode -ne 'Mini') {
    $sidMatch = Select-String -Path $logFile -Pattern '"thread_id"\s*:\s*"([^"]+)"' |
                Select-Object -First 1
    if (-not $sidMatch) {
        $sidMatch = Select-String -Path $logFile -Pattern '"session_id"\s*:\s*"([^"]+)"' |
                    Select-Object -First 1
    }
    if ($sidMatch) {
        $sid = $sidMatch.Matches[0].Groups[1].Value
        Write-Host "SESSION_ID=$sid"
        # Also write to known file so external callers (test runner) can read it reliably
        # without depending on Write-Host being captured (which fails when piped through 2>&1).
        Set-Content -Path (Join-Path $OutputDir 'last-session-id.txt') -Value $sid -Encoding ascii -NoNewline
    } else {
        Write-Warning "Could not extract session_id from log. Round 2+ resume will not work."
    }
}

# ── Report duration + token usage + output JSON ──────────────────────────────
$elapsed = ((Get-Date) - $startTime).TotalSeconds
$tokenInfo = ''
$usageMatch = Select-String -Path $logFile -Pattern '"usage"\s*:\s*\{[^}]+\}' |
              Select-Object -First 1
if ($usageMatch) {
    try {
        $usageJson = $usageMatch.Matches[0].Value -replace '^"usage"\s*:\s*', ''
        $usage = $usageJson | ConvertFrom-Json
        $tokenInfo = " - tokens(in=$($usage.input_tokens), out=$($usage.output_tokens))"
    } catch {}
}
$elapsedRounded = [math]::Round($elapsed, 1)
Write-Host "[Dual] Round $Round complete in ${elapsedRounded}s$tokenInfo"

Write-Host "--- OUTPUT JSON ---"
Get-Content -Raw $outFile
