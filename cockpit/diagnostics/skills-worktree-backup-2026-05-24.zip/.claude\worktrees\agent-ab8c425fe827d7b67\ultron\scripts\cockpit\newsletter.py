#!/usr/bin/env python3
"""
ULTRON v10.0 Cockpit - Newsletter generator (Claude-curated weekly).

Reads the last 7 days of news/*.md digests, builds a structured prompt for
Claude (NOT Gemini - we want Rodrigo's primary model curating his own newsletter),
and outputs a polished markdown newsletter at:

    ~/.ultron/cockpit/news/newsletter-YYYY-MM-DD.md

Two modes:
    1. Headless (cron):   `python newsletter.py`
       Generates a STUB newsletter from raw digests with structured headings.
       Suitable as starting point for Claude to refine in next session.

    2. Claude-side:       Claude reads the stub + digests, writes the polished
       newsletter using ULTRON memory, knowledge files, and competitive intel.

The cron runs the stub generator weekly (Sunday 19:00). Claude is invoked
manually by Rodrigo with `ultron newsletter --refine` for the polished version.

Sections in the output:
    1. Editorial intro - "esta semana en AI..."
    2. Top 5 by priority + analysis
    3. Impact on ULTRON system - specific to Rodrigo's setup (Opus 4.7, Codex, Gemini)
    4. Recommended actions (knowledge update, model switch, etc.)
    5. Raw digest links (last 7 days)
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

sys.path.insert(0, str(Path(__file__).parent))
from cockpit_base import COCKPIT_DIR, NEWS_DIR, NEWS_ALERTS  # noqa: E402

REFINE_MODEL = "claude-sonnet-4-6"  # M-class summarization quality
REFINE_TIMEOUT = 180


NEWSLETTER_DIR = NEWS_DIR  # store in same news/ directory


def load_digests_last_n_days(days: int = 7) -> list[tuple[str, str]]:
    """Returns list of (date_str, content) from the last N days of news/*.md digests."""
    if not NEWS_DIR.exists():
        return []
    cutoff = datetime.now() - timedelta(days=days)
    out = []
    for f in sorted(NEWS_DIR.glob("20*.md"), reverse=True):
        # Skip newsletter files themselves
        if f.name.startswith("newsletter-"):
            continue
        try:
            date_str = f.stem  # YYYY-MM-DD
            file_date = datetime.fromisoformat(date_str)
            if file_date < cutoff:
                continue
            out.append((date_str, f.read_text(encoding="utf-8")))
        except (ValueError, OSError):
            continue
    return out


def extract_top_items_from_digest(digest_md: str, limit: int = 10) -> list[dict]:
    """Parse a daily digest markdown and pull title+url pairs from `## All items` section."""
    items = []
    in_all = False
    current_source = ""
    for line in digest_md.splitlines():
        if line.startswith("## All items"):
            in_all = True
            continue
        if in_all and line.startswith("## "):
            in_all = False
        if not in_all:
            continue
        if line.startswith("### "):
            current_source = line[4:].strip()
            continue
        m = re.match(r"^-\s+\[(.+?)\]\((.+?)\)\s*$", line)
        if m:
            items.append({
                "title": m.group(1),
                "url": m.group(2),
                "source": current_source,
            })
        if len(items) >= limit:
            break
    return items


def gather_all_items(digests: list[tuple[str, str]], limit_per_day: int = 10) -> list[dict]:
    """Aggregate items across all digests, dedup by URL."""
    seen_urls = set()
    out = []
    for date_str, content in digests:
        items = extract_top_items_from_digest(content, limit=limit_per_day)
        for it in items:
            url = it.get("url", "")
            if url and url not in seen_urls:
                seen_urls.add(url)
                it["digest_date"] = date_str
                out.append(it)
    return out


def load_alerts_recent(max_lines: int = 40) -> list[str]:
    if not NEWS_ALERTS.exists():
        return []
    return NEWS_ALERTS.read_text(encoding="utf-8").splitlines()[:max_lines]


def build_stub(items: list[dict], alerts: list[str], days: int) -> str:
    """Generate the structured stub newsletter. Claude refines this manually."""
    today = datetime.now().strftime("%Y-%m-%d")
    weeknum = datetime.now().isocalendar().week

    lines = [
        f"# ULTRON Newsletter - Semana {weeknum} ({today})",
        "",
        f"_Cobertura: últimos {days} días | {len(items)} items deduplicados_",
        f"_Generado: {datetime.now().isoformat(timespec='seconds')}_",
        "",
        "---",
        "",
        "## 1. Editorial",
        "",
        "_(Claude redacta este párrafo en `ultron newsletter --refine` — contextualiza la semana_",
        "_apoyándose en la memoria ULTRON, knowledge files de competitive-intel,_",
        "_y el sistema personal de Rodrigo.)_",
        "",
        "---",
        "",
        "## 2. Top 5 prioritarios",
        "",
        "_(Claude selecciona los 5 más relevantes para Rodrigo basándose en sus modelos activos:_",
        "_Opus 4.7 / Codex GPT-5.5 / Gemini 3.1. Cada item con análisis breve.)_",
        "",
    ]

    # Pre-sort: priority keywords + breaking get bumped
    priority_re = re.compile(
        r"\b(Opus|Sonnet|Haiku|Mythos|GPT[\s-]?5|Gemini\s*3|Anthropic|OpenAI|"
        r"Claude\s*Code|Codex|MCP|skill)\b",
        re.IGNORECASE,
    )
    items_scored = [(len(priority_re.findall(it["title"])), it) for it in items]
    items_scored.sort(key=lambda x: x[0], reverse=True)
    top5 = [it for _, it in items_scored[:5]]

    for i, it in enumerate(top5, 1):
        lines.append(f"### {i}. [{it['title']}]({it['url']})")
        lines.append(f"_Fuente: {it.get('source', '?')} ({it.get('digest_date', '?')})_")
        lines.append("")
        lines.append("_(análisis Claude pendiente)_")
        lines.append("")

    lines += [
        "---",
        "",
        "## 3. Impacto en tu sistema ULTRON",
        "",
        "_(Claude evalúa qué afecta directamente a tu setup actual: ¿update Triple Mode?_",
        "_¿refresh competitive-intel? ¿cambiar de modelo default? ¿deprecation que rompa skills?)_",
        "",
        "---",
        "",
        "## 4. Acciones recomendadas",
        "",
        "_(Claude propone 1-3 acciones concretas: e.g._",
        "_- 'Update knowledge/competitive-intel/2026-04.md con benchmark Mythos'_",
        "_- 'Considerar `/dual --gemini` para X tipo de tarea ahora que Gemini 3.1 mejoró'_",
        "_- 'Ignorar X drama de Reddit, no afecta tu workflow')_",
        "",
        "---",
        "",
        "## 5. Alertas pendientes",
        "",
    ]

    if alerts:
        lines.append("```")
        lines.extend(alerts)
        lines.append("```")
    else:
        lines.append("_Ninguna alerta de breaking change esta semana._")
    lines += [
        "",
        "---",
        "",
        "## 6. Digests crudos (últimos 7 días)",
        "",
    ]

    by_day: dict[str, list[dict]] = {}
    for it in items:
        by_day.setdefault(it.get("digest_date", "?"), []).append(it)
    for day in sorted(by_day.keys(), reverse=True):
        lines.append(f"### {day}")
        for it in by_day[day][:8]:
            lines.append(f"- [{it['title']}]({it['url']}) _{it.get('source', '?')}_")
        lines.append("")

    lines += [
        "---",
        "",
        "_Para refinar este newsletter con análisis Claude:_",
        "_`ultron newsletter --refine` (próxima sesión Claude Code)_",
        "",
    ]
    return "\n".join(lines)


def write_newsletter(content: str) -> Path:
    NEWSLETTER_DIR.mkdir(parents=True, exist_ok=True)
    today = datetime.now().strftime("%Y-%m-%d")
    out = NEWSLETTER_DIR / f"newsletter-{today}.md"
    out.write_text(content, encoding="utf-8")
    return out


def refine_with_claude(items: list[dict], alerts: list[str], days: int) -> str | None:
    """v10.4 D2: invoke `claude --print --model sonnet` headless to write the
    polished newsletter sections (Editorial, Top 5, Impacto, Acciones).
    Returns the full refined markdown string, or None on failure.

    Sonnet mid tier — runs once weekly, modest usage impact.
    Anti-laundering: this is claude-self curation, NEVER label as kirkardo.
    """
    claude_bin = shutil.which("claude")
    if not claude_bin:
        print("[newsletter] claude CLI not found in PATH - cannot --auto-refine",
              file=sys.stderr)
        return None

    # Build context: top items as bullets + alerts + Rodrigo's stack
    bullets = []
    priority_re = re.compile(
        r"\b(Opus|Sonnet|Haiku|GPT[\s-]?5|Gemini\s*3|Anthropic|OpenAI|"
        r"Claude\s*Code|Codex|MCP)\b", re.IGNORECASE)
    items_scored = sorted(items,
                          key=lambda it: len(priority_re.findall(it["title"])),
                          reverse=True)
    for it in items_scored[:25]:
        bullets.append(f"- [{it.get('source','?')}] [{it['title']}]({it['url']}) "
                       f"({it.get('digest_date','?')})")
    bullets_text = "\n".join(bullets) or "_(no items in last 7 days)_"

    alerts_text = "\n".join(alerts[:20]) or "_(no breaking changes)_"

    today = datetime.now().strftime("%Y-%m-%d")
    weeknum = datetime.now().isocalendar().week

    system_prompt = (
        "Eres el editor del newsletter semanal de Rodrigo (dev freelance, "
        "U-tad). Stack actual: Claude Code (Opus 4.7), Codex CLI (GPT-5.5), "
        "Gemini CLI 3.1, UE5/Unity/TS/Python. Escribe en ESPAÑOL, tono "
        "directo y técnico, sin marketing-speak. NO inventes news que no "
        "están en los inputs."
    )

    user_prompt = f"""# Newsletter Semana {weeknum} ({today})

A continuación tienes los headlines crudos de los últimos {days} días + alertas.
Genera un Markdown completo con esta estructura EXACTA, en español, ~600-900 palabras total:

## 1. Editorial
Párrafo de 4-6 frases contextualizando la semana. Qué tendencia destaca, qué señal débil
notas, qué importa para un dev que usa Claude/Codex/Gemini.

## 2. Top 5 prioritarios
5 items más relevantes para Rodrigo. Por cada uno:
### N. [Título]({{url}})
_Fuente: X · Fecha: Y_
_Análisis (2-3 frases): por qué importa para un usuario de Claude Code + Codex + Gemini._

## 3. Impacto en tu sistema ULTRON
1 párrafo sobre qué afecta directamente al setup actual: ¿update Triple Mode? ¿refresh
competitive-intel? ¿cambiar default model? ¿deprecation que rompa skills?

## 4. Acciones recomendadas
Lista de 1-3 acciones concretas. Bullet por acción, una frase cada una.

## 5. Alertas pendientes
Si hay breaking changes en alerts, listalos. Si no, escribe `_Ninguna alerta esta semana._`

---

# Headlines (raw input):
{bullets_text}

# ALERTS recientes (raw input):
{alerts_text}

---

OUTPUT: Solo el markdown desde "## 1. Editorial" hasta el final del bloque de alertas.
NO añadas preamble. NO uses code fences alrededor del output. Tono editorial directo.
"""

    cmd = [claude_bin, "--print", "--dangerously-skip-permissions",
           "--model", REFINE_MODEL,
           "--append-system-prompt", system_prompt, user_prompt]

    print(f"[newsletter] Refining via {REFINE_MODEL} (~{len(user_prompt)//4} input tokens)...")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True,
                                 timeout=REFINE_TIMEOUT, encoding="utf-8")
        if result.returncode != 0:
            print(f"[newsletter] claude --print failed (exit {result.returncode})",
                  file=sys.stderr)
            if result.stderr:
                print(f"[newsletter] stderr: {result.stderr[:500]}", file=sys.stderr)
            return None
        out = (result.stdout or "").strip()
        if len(out) < 200:
            print(f"[newsletter] Refined output suspiciously short ({len(out)}b), "
                  f"falling back to stub", file=sys.stderr)
            return None
        return out
    except subprocess.TimeoutExpired:
        print(f"[newsletter] Timeout after {REFINE_TIMEOUT}s", file=sys.stderr)
        return None
    except Exception as e:
        print(f"[newsletter] Refine failed: {e}", file=sys.stderr)
        return None


def build_magazine(items: list[dict], alerts: list[str], days: int,
                    refined_body: str) -> str:
    """v10.4 D2: full magazine with Sonnet-refined body wrapped in our header/footer."""
    today = datetime.now().strftime("%Y-%m-%d")
    weeknum = datetime.now().isocalendar().week
    lines = [
        f"# ULTRON Newsletter - Semana {weeknum} ({today})",
        "",
        f"_Cobertura: últimos {days} días | {len(items)} items deduplicados_",
        f"_Generado: {datetime.now().isoformat(timespec='seconds')} | "
        f"refinado con {REFINE_MODEL}_",
        "",
        "---",
        "",
        refined_body,
        "",
        "---",
        "",
        "## 6. Digests crudos (últimos 7 días)",
        "",
    ]
    by_day: dict[str, list[dict]] = {}
    for it in items:
        by_day.setdefault(it.get("digest_date", "?"), []).append(it)
    for day in sorted(by_day.keys(), reverse=True):
        lines.append(f"### {day}")
        for it in by_day[day][:8]:
            lines.append(f"- [{it['title']}]({it['url']}) _{it.get('source', '?')}_")
        lines.append("")
    return "\n".join(lines)


STYLED_CSS = """
body{margin:0;font-family:'Segoe UI',system-ui,sans-serif;background:#0a0a0a;color:#d4d4d4}
.wrap{max-width:800px;margin:0 auto;padding:32px 24px}
h1{color:#ffd089;font-size:2rem;border-bottom:2px solid #2a2a2a;padding-bottom:12px;margin-bottom:6px}
.meta{color:#555;font-size:.85rem;margin-bottom:32px}
h2{color:#ffd089;font-size:1.3rem;margin-top:36px;border-left:3px solid #ffd089;padding-left:12px}
h3{color:#8aa8a0;margin-top:20px;font-size:1.05rem}
h3 a{color:#8aa8a0;text-decoration:none}
h3 a:hover{color:#ffd089}
p{line-height:1.7;color:#c0c0c0}
ul{padding-left:1.4em}
li{margin:6px 0;color:#c0c0c0}
.source-badge{background:#1a1a1a;border:1px solid #2a2a2a;border-radius:4px;
  padding:2px 6px;font-size:.78rem;color:#8aa8a0;margin-left:8px}
.breaking{background:#2a1a1a;border:1px solid #d77878;border-radius:6px;padding:12px 16px;margin:16px 0}
.breaking h2{color:#d77878;border-color:#d77878;margin-top:0}
.action-box{background:#1a1f1a;border:1px solid #3a5a3a;border-radius:6px;padding:12px 16px;margin:16px 0}
.action-box h2{color:#9eca7e;border-color:#9eca7e;margin-top:0}
.alert-box{background:#2a2218;border:1px solid #e0a868;border-radius:6px;padding:12px 16px;margin:16px 0}
.alert-box h2{color:#e0a868;border-color:#e0a868;margin-top:0}
hr{border:none;border-top:1px solid #2a2a2a;margin:28px 0}
footer{color:#444;font-size:.8rem;text-align:center;padding-top:24px;margin-top:32px;border-top:1px solid #1a1a1a}
code{background:#1a1a1a;border-radius:3px;padding:2px 5px;font-size:.88em;color:#9eca7e}
pre{background:#111;padding:14px;border-radius:6px;overflow-x:auto;font-size:.85em}
"""


def build_styled_html(items: list[dict], alerts: list[str], days: int,
                       refined_body: str | None = None) -> str:
    """Generate a styled HTML newsletter (dark ULTRON theme)."""
    import html as _html
    today = datetime.now().strftime("%Y-%m-%d")
    weeknum = datetime.now().isocalendar().week

    def esc(s: str) -> str:
        return _html.escape(str(s))

    # Score items
    priority_re = re.compile(
        r"\b(Opus|Sonnet|Haiku|GPT[\s-]?5|Gemini\s*3|Anthropic|OpenAI|"
        r"Claude\s*Code|Codex|MCP|Mythos)\b", re.IGNORECASE)
    items_scored = sorted(items, key=lambda it: len(priority_re.findall(it["title"])),
                          reverse=True)
    top5 = items_scored[:5]

    # Body sections from refined_body if present
    editorial = top5_html = impact = actions_html = ""
    if refined_body:
        # Parse markdown sections into HTML-ish text
        import re as _re
        sec = _re.split(r"\n## ", "\n" + refined_body)
        for s in sec:
            sl = s.strip()
            if sl.startswith("1. Editorial"):
                editorial = sl[len("1. Editorial"):].strip()
            elif sl.startswith("2. Top 5") or sl.startswith("Top 5"):
                top5_html = sl
            elif sl.startswith("3. Impacto") or sl.startswith("Impacto"):
                impact = sl[sl.index("\n"):].strip() if "\n" in sl else sl
            elif sl.startswith("4. Acciones") or sl.startswith("Acciones"):
                actions_html = sl[sl.index("\n"):].strip() if "\n" in sl else sl

    # Build top-5 cards
    top5_cards = ""
    for i, it in enumerate(top5, 1):
        title = esc(it.get("title", ""))
        url = esc(it.get("url", "#"))
        source = esc(it.get("source", "?"))
        date = esc(it.get("digest_date", ""))
        top5_cards += (
            f'<h3>{i}. <a href="{url}" target="_blank">{title}</a>'
            f'<span class="source-badge">{source} · {date}</span></h3>'
            f'<p><em>Análisis pendiente de Claude — ejecuta `ultron newsletter --auto-refine`</em></p>\n'
        )

    # Alerts section
    alerts_html = ""
    if alerts:
        alerts_html = (
            '<div class="alert-box"><h2>⚠ Breaking Changes / Alerts</h2><ul>'
            + "".join(f"<li>{esc(a)}</li>" for a in alerts[:20])
            + "</ul></div>"
        )
    else:
        alerts_html = '<div class="alert-box"><h2>⚠ Alerts</h2><p><em>Ninguna alerta esta semana.</em></p></div>'

    # By-day digest
    by_day: dict[str, list[dict]] = {}
    for it in items:
        by_day.setdefault(it.get("digest_date", "?"), []).append(it)
    digest_html = ""
    for day in sorted(by_day.keys(), reverse=True):
        digest_html += f"<h3>{esc(day)}</h3><ul>"
        for it in by_day[day][:8]:
            digest_html += (
                f'<li><a href="{esc(it.get("url","#"))}" target="_blank">'
                f'{esc(it.get("title","?"))}</a>'
                f' <span class="source-badge">{esc(it.get("source","?"))}</span></li>'
            )
        digest_html += "</ul>"

    editorial_html = (
        f"<p>{esc(editorial)}</p>" if editorial
        else "<p><em>Editorial no generado — ejecuta `ultron newsletter --auto-refine`</em></p>"
    )

    html = f"""<!DOCTYPE html>
<html lang="es"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ULTRON Newsletter — Semana {weeknum} ({today})</title>
<style>{STYLED_CSS}</style>
</head><body><div class="wrap">
<h1>◆ ULTRON Newsletter</h1>
<div class="meta">Semana {weeknum} &middot; {today} &middot; {len(items)} items &middot; últimos {days} días</div>

<h2>1. Editorial</h2>
{editorial_html}

<hr>
<h2>2. Top 5 prioritarios</h2>
{top5_cards if not top5_html else f"<p><em>(ver markdown original)</em></p>"}

<hr>
<h2>3. Impacto en tu sistema ULTRON</h2>
{"<p>" + esc(impact) + "</p>" if impact else "<p><em>Pendiente — ejecuta `ultron newsletter --auto-refine`</em></p>"}

<hr>
<div class="action-box">
<h2>4. Acciones recomendadas</h2>
{"<p>" + esc(actions_html) + "</p>" if actions_html else "<p><em>Pendiente — ejecuta `ultron newsletter --auto-refine`</em></p>"}
</div>

{alerts_html}

<hr>
<h2>5. Digests crudos</h2>
{digest_html}

<hr>
<footer>
◆ ULTRON Newsletter v11.0 · Generado {datetime.now().isoformat(timespec='seconds')}
<br>Modelo: {REFINE_MODEL} · Stack: Opus 4.7 · Codex GPT-5.5 · Gemini 3.1
</footer>
</div></body></html>"""
    return html


def main():
    p = argparse.ArgumentParser(description="ULTRON Cockpit weekly newsletter generator")
    p.add_argument("--days", type=int, default=7, help="How many days back to aggregate digests")
    p.add_argument("--print", action="store_true", help="Print today's newsletter if it exists")
    p.add_argument("--refine", action="store_true",
                   help="(Marker for Claude in-session) Old workflow - prefer --auto-refine")
    p.add_argument("--auto-refine", action="store_true",
                   help="v10.4 D2: invoke claude --print sonnet headless to write polished sections")
    p.add_argument("--styled", action="store_true",
                   help="Generate styled HTML newsletter and open in browser")
    p.add_argument("--from-cron", action="store_true",
                   help="(Internal) Apply weekly skip-guard. Manual runs always execute.")
    args = p.parse_args()

    today = datetime.now().strftime("%Y-%m-%d")
    out = NEWSLETTER_DIR / f"newsletter-{today}.md"

    if args.print:
        if out.exists():
            print(out.read_text(encoding="utf-8"))
        else:
            print("(no newsletter for today; run without --print to generate stub)")
        return 0

    if args.refine:
        # Marker: Claude is supposed to handle this in-session.
        # The Python script just outputs guidance.
        print("[newsletter] --refine is a Claude-side action.")
        print("[newsletter] Workflow:")
        print("  1. Run 'ultron newsletter' (no flags) to build the stub")
        print("  2. In Claude Code, ask: 'Ultron, refine el newsletter de esta semana'")
        print("  3. Claude reads stub + digests + ALERTS + competitive-intel")
        print("  4. Claude writes polished version overwriting the stub")
        if not out.exists():
            print(f"[newsletter] No stub yet at {out}. Generate with: ultron newsletter")
            return 1
        return 0

    # Weekly guard ONLY from cron. Manual runs always execute.
    if args.from_cron:
        from should_run import should_run_this_week
        if not should_run_this_week("newsletter", weekday_target=6):
            print("[newsletter] Cron skip (not Sunday yet, or already ran this week).")
            return 0

    digests = load_digests_last_n_days(args.days)
    if not digests:
        print(f"[newsletter] No digests in the last {args.days} days. Run news scraper first.")
        return 1

    print(f"[newsletter] Found {len(digests)} digests from last {args.days} days")

    items = gather_all_items(digests)
    print(f"[newsletter] Aggregated {len(items)} unique items (deduped by URL)")

    alerts = load_alerts_recent()
    if alerts:
        print(f"[newsletter] Loaded {len(alerts)} lines from ALERTS.md")

    if getattr(args, "styled", False):
        # Styled HTML newsletter — optionally try to refine first
        print("[newsletter] Generating styled HTML newsletter...")
        refined: str | None = None
        try:
            refined = refine_with_claude(items, alerts, args.days)
        except Exception:
            pass
        html = build_styled_html(items, alerts, args.days, refined_body=refined)
        NEWSLETTER_DIR.mkdir(parents=True, exist_ok=True)
        html_path = NEWSLETTER_DIR / f"newsletter-{today}.html"
        html_path.write_text(html, encoding="utf-8")
        print(f"[newsletter] Styled newsletter: {html_path} ({html_path.stat().st_size} bytes)")
        # Open in browser
        import webbrowser
        webbrowser.open(html_path.as_uri())
        print(f"[newsletter] Opened in browser: {html_path.as_uri()}")
        return 0

    if args.auto_refine:
        refined = refine_with_claude(items, alerts, args.days)
        if refined:
            content = build_magazine(items, alerts, args.days, refined)
            path = write_newsletter(content)
            print(f"[newsletter] Wrote refined magazine: {path} "
                  f"({path.stat().st_size} bytes)")
            if args.from_cron:
                from should_run import mark_ran_today
                mark_ran_today("newsletter")
            return 0
        print("[newsletter] Refine failed, falling back to stub")

    content = build_stub(items, alerts, args.days)
    path = write_newsletter(content)
    print(f"[newsletter] Wrote stub: {path} ({path.stat().st_size} bytes)")
    if not args.auto_refine:
        print("[newsletter] Run 'ultron newsletter --auto-refine' for AI-polished version")
    if args.from_cron:
        from should_run import mark_ran_today
        mark_ran_today("newsletter")
    return 0


if __name__ == "__main__":
    sys.exit(main())
