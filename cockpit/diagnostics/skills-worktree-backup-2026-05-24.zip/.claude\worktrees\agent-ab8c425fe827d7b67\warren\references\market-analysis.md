# Análisis de Mercado y Sectores — Referencia Warren

## Ciclo de Mercado

### Fases del ciclo económico → rotación sectorial

| Fase económica | Sectores que lideran | Sectores que sufren |
|---|---|---|
| Expansión temprana | Financiero · Industrial · Materiales | Utilities · Consumo básico |
| Expansión madura | Tecnología · Consumo discrecional | — |
| Desaceleración | Salud · Consumo básico · Utilities | Industrial · Materiales |
| Recesión | Utilities · Consumo básico · Bonos | Tecnología · Financiero · Cíclicos |
| Recuperación | Financiero · Industrial · Small caps | Utilities |

**Regla operativa:** identificar fase actual antes de cualquier recomendación sectorial.

### Señales de fase actual
- **Expansión:** ISM Manufacturing >50, empleo creciendo, curva de tipos positiva
- **Techo:** inflación acelerando, FED subiendo tipos, yield curve aplanando
- **Recesión:** PMIs cayendo, desempleo subiendo, inversión de curva
- **Recuperación:** tipos estabilizados/bajando, leading indicators girando

---

## Análisis Macro — Variables Clave

### Tipos de interés (FED / BCE)
- Tipos subiendo → presión en valoraciones growth (DCF penalizado), beneficio para financieras
- Tipos bajando → beneficio para growth, REITs, utilities, bonos
- Curva invertida (2Y > 10Y) → señal históricamente predictiva de recesión en 12-18 meses

### Inflación (IPC)
- IPC alto → TIPS, materias primas, energía, inmobiliario
- IPC controlado → tech, consumo discrecional, growth

### Dólar / Euro (para exposición internacional)
- USD fuerte → perjudica a empresas US con ingresos internacionales
- USD débil → beneficia a emergentes, materias primas

---

## Rotación Sectorial — Framework CANSLIM adaptado

### Criterios de selección (O'Neil simplificado)
```
C — Current earnings: BPA trimestral >25% YoY
A — Annual earnings: crecimiento anual >25% últimos 3 años
N — New product/service/high: catalizador nuevo visible
S — Supply/demand: flotante reducido + acumulación institucional
L — Leader: top 20% de su sector en RS Rating
I — Institutional sponsorship: fondos de calidad acumulando
M — Market direction: no comprar contra tendencia del índice
```

### Cómo identificar líderes sectoriales
1. Calcular Relative Strength vs índice (precio relativo 52 semanas)
2. Priorizar empresas con RS > 80 (superan al 80% del mercado)
3. Buscar acumulación en volumen (días alcistas > días bajistas)

---

## Gestión de Cartera

### Diversificación mínima recomendada
```
Renta variable:    60-80% del capital de inversión
  · Por sector:    max 25% en un solo sector
  · Por empresa:   max 10% en una sola posición
  · Por geografía: mínimo 30% fuera de España/Europa
Renta fija / cash: 20-40% según ciclo y perfil de riesgo
```

### Rebalanceo
- Frecuencia: semestral, o cuando una posición supera ±5% del target
- Trigger de reducción: posición >2x el peso objetivo
- Trigger de cierre: tesis de inversión rota (no el precio bajando)

### Stop-loss vs Stop-tesis
- Stop-loss de precio (8-10% en growth) → válido para proteger capital
- Stop-tesis → más importante: si los fundamentales cambian, salir independientemente del precio
- Nunca promediar a la baja en posición perdedora sin re-validar la tesis

---

## Indicadores de Sentimiento (contrarian)

| Indicador | Señal de euforia (vender) | Señal de miedo (estudiar comprar) |
|---|---|---|
| VIX | <15 prolongado | >30 con spike |
| Put/Call ratio | <0.7 | >1.2 |
| AAII Sentiment | >55% alcistas | >55% bajistas |
| Portadas de prensa | "Bolsa imparable" | "Fin del capitalismo" |
| Flujos fondos | Entradas récord | Salidas récord |

**Regla Warren:** el sentimiento extremo no es señal de timing exacto, pero calibra el margen de seguridad requerido.
