# UE5 Enhanced Input — Referencia Don Claudio

> Fuente: DSTN2000/claude-unreal-engine-skill · Adaptado para uso en CC

## Componentes Core

### Input Actions
Data assets que representan comportamientos del jugador (saltar, moverse, disparar).
Cuatro tipos de valor:
- `Digital` → bool (botón on/off)
- `Axis1D` → float (trigger analógico)
- `Axis2D` → FVector2D (stick, ratón)
- `Axis3D` → FVector (motion controllers)

### Input Mapping Contexts
Vinculan inputs físicos (teclas, botones) con Input Actions.
- Se pueden apilar con niveles de prioridad
- Múltiples contextos activos simultáneamente
- Cambiar contextos en runtime para cambiar control scheme (vehículo vs a pie)

---

## Setup Correcto

### BeginPlay — añadir mapping context
```cpp
void AMyCharacter::BeginPlay()
{
    Super::BeginPlay();

    if (APlayerController* PC = Cast<APlayerController>(GetController()))
    {
        if (UEnhancedInputLocalPlayerSubsystem* Subsystem =
            ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PC->GetLocalPlayer()))
        {
            Subsystem->AddMappingContext(DefaultMappingContext, 0);
        }
    }
}
```

### SetupPlayerInputComponent — binding correcto
```cpp
void AMyCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
    if (UEnhancedInputComponent* EIC = Cast<UEnhancedInputComponent>(PlayerInputComponent))
    {
        EIC->BindAction(JumpAction, ETriggerEvent::Started, this, &AMyCharacter::Jump);
        EIC->BindAction(MoveAction, ETriggerEvent::Triggered, this, &AMyCharacter::Move);
        EIC->BindAction(LookAction, ETriggerEvent::Triggered, this, &AMyCharacter::Look);
    }
}
```

### Extracción de valor en callback
```cpp
void AMyCharacter::Move(const FInputActionValue& Value)
{
    FVector2D MovementVector = Value.Get<FVector2D>();
    // usar MovementVector.X y .Y
}
```

---

## Trigger Events

| Evento | Cuándo se activa |
|---|---|
| `Started` | Primer frame que la condición se cumple |
| `Ongoing` | Mientras la condición continúa |
| `Triggered` | Condición completamente cumplida (default para Hold) |
| `Canceled` | Condición interrumpida antes de completarse |
| `Completed` | Condición completada y finalizada (release) |

---

## Debugging

```
Console: showdebug enhancedinput
```

**Verificaciones si no funciona:**
1. Plugin Enhanced Input habilitado en `.uproject`
2. Módulo `"EnhancedInput"` en `Build.cs`
3. `Cast<UEnhancedInputComponent>` — NO usar la clase base
4. Input Action asset asignado en la propiedad del Character
5. Mapping Context asignado y prioridad correcta

---

## Pitfalls Comunes

- **Error:** usar `UInputComponent` base en lugar de `UEnhancedInputComponent` → bindings silenciosos
- **Error:** olvidar añadir el Mapping Context en BeginPlay → input no responde
- **Error:** usar `ETriggerEvent::Started` para movimiento continuo → solo responde en el primer frame
- **Correcto:** movimiento continuo → `ETriggerEvent::Triggered`
