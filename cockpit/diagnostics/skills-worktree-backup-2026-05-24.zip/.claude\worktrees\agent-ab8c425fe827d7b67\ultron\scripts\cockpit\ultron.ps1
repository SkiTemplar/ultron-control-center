# ULTRON v10.7.0 CORE - Central command (CENTRALITA)
# Internal path `scripts/cockpit/` preserved for backwards compat with cron jobs.
#
# Single entry point for the cockpit. Subcommands:
#   ultron status                  - dashboard view
#   ultron open <project>          - launch project in its IDE
#   ultron projects [--list|active|search <q>]
#   ultron scan [--verbose|--dry-run]
#   ultron auth <add|get|list|switch|remove|status> ...
#   ultron mcp <list|catalog|install|uninstall|validate> ...
#   ultron schedule <install|status|uninstall>
#   ultron desktop [install|uninstall]
#   ultron track [snapshot|summary]
#   ultron retention [--dry-run]
#   ultron news                    - show today's digest + ALERTS
#   ultron help [<command>]
#
# Each subcommand delegates to a focused script in scripts\cockpit\.
# Made to be aliased: see "ultron alias" subcommand.

param(
    [Parameter(Position=0)]
    [string]$Command = "tui",

    [Parameter(Position=1, ValueFromRemainingArguments=$true)]
    [string[]]$Rest
)

$ErrorActionPreference = "Stop"

$CockpitDir = $PSScriptRoot
$Python = "python"

function Invoke-Py($script, $arglist) {
    $scriptPath = Join-Path $CockpitDir $script
    & $Python $scriptPath @arglist
    return $LASTEXITCODE
}

function Invoke-Ps($script, $arglist) {
    $scriptPath = Join-Path $CockpitDir $script
    & powershell -NoProfile -ExecutionPolicy Bypass -File $scriptPath @arglist
    return $LASTEXITCODE
}

function Show-Help {
    Write-Host ""
    Write-Host "ULTRON CORE - Central command" -ForegroundColor Cyan
    Write-Host "============================="
    Write-Host ""
    Write-Host "USAGE:" -ForegroundColor Yellow
    Write-Host "  ultron <command> [args]"
    Write-Host ""
    Write-Host "COMMANDS:" -ForegroundColor Yellow
    Write-Host "  status                   Dashboard - projects, vault, telemetry, alerts"
    Write-Host "  open <project>           Launch project in its IDE (writes .claude/context.md)"
    Write-Host "  projects [--list|--search <q>]"
    Write-Host "                           Browse registry"
    Write-Host "  scan [--verbose|--dry-run]"
    Write-Host "                           Re-scan filesystem for projects"
    Write-Host "  auth <action> ...        Auth vault: add|get|list|switch|remove|status"
    Write-Host "  mcp <action> ...         MCP installer: list|catalog|install|uninstall|validate|wrap|unwrap"
    Write-Host "  notes <id> <save|list|export>"
    Write-Host "                           Per-project persistent notes (warm-start context)"
    Write-Host "  schedule <action>        Task Scheduler: install|status|uninstall"
    Write-Host "  desktop [install|uninstall]"
    Write-Host "                           Create/remove ULTRON CORE shortcut on Desktop"
    Write-Host "  track [snapshot|summary] Activity tracker"
    Write-Host "  retention [--dry-run]    Run rotation/cleanup policy"
    Write-Host "  news [--no-gemini]       Run AI news scraper -> news/YYYY-MM-DD.md + ALERTS"
    Write-Host "  dashboard [--print]      Generate (or show) DASHBOARD.md"
    Write-Host "  standup [--print|--gemini]"
    Write-Host "                           Generate (or show) today's standup"
    Write-Host "  newsletter [--print|--refine]"
    Write-Host "                           Generate weekly stub newsletter (Claude refines manually)"
    Write-Host "  calendar [--sample|--print|--events <file>|--stdin]"
    Write-Host "                           Match Calendar events to projects -> deadlines.json"
    Write-Host ""
    Write-Host "  Sessions & quick-ask (v10.4):" -ForegroundColor Green
    Write-Host "  ask <pregunta>           Quick-ask via Haiku + mini-memoria (no comillas)"
    Write-Host "  claude [args]            Spawn interactive Claude session in cwd (new tab)"
    Write-Host "  gemini [args]            Spawn interactive Gemini session in cwd"
    Write-Host "  codex  [args]            Spawn interactive Codex session in cwd"
    Write-Host ""
    Write-Host "  Apps & usage (v10.4):" -ForegroundColor Green
    Write-Host "  app <name> [args]        Launch GUI app (claude-desktop, chatgpt, spotify, ...)"
    Write-Host "  apps [list|discover|add|remove]"
    Write-Host "                           Manage GUI app registry"
    Write-Host "  usage [--json]           Token usage tracker (last 1h/24h/7d)"
    Write-Host "  audit list               List personas/skills available for audit"
    Write-Host "  audit run <persona> [--quick]"
    Write-Host "                           Kirkardo independent audit (Opus full / Sonnet quick)"
    Write-Host ""
    Write-Host "  AI editing & autoupdater (v10.4):" -ForegroundColor Green
    Write-Host "  project edit <id> <q>    AI edit project (Haiku/Sonnet via env, dry-run)"
    Write-Host "  project add|delete|tag   project_editor.py wrappers"
    Write-Host "  schedule edit|chat       AI schedule mutation (Haiku/Sonnet)"
    Write-Host "  auth wizard new|chat     Vault profile interactive Q&A or NL"
    Write-Host "  skill create             Q&A interactive skill scaffold (Sonnet)"
    Write-Host "  skills export <s>        SKILL.md → AGENTS.md (Codex) + GEMINI.md"
    Write-Host "  mcp scaffold <idea>      Sonnet MCP server scaffold"
    Write-Host "  self-improve scan        L1 AutoUpdater: rank audit candidates"
    Write-Host "  self-improve audit <s> [--quick]"
    Write-Host "                           L1: trigger Kirkardo (Sonnet quick / Opus full)"
    Write-Host "  self-improve propose <audit>"
    Write-Host "                           L2: Sonnet patches (NO apply, FP filter)"
    Write-Host "  self-improve apply <proposals>"
    Write-Host "                           L3: spawn Claude review session (human-gated)"
    Write-Host "  newsletter --auto-refine Sonnet-curated weekly magazine"
    Write-Host "  limits [status|check|set]  Daily caps per model (turn count)"
    Write-Host "  health                   System health check (all deps + scripts + configs)"
    Write-Host "  jobs <submit|list|status|logs|cancel|clean>"
    Write-Host "                           Background job supervisor (persistent state + logs)"
    Write-Host ""
    Write-Host "  Gaming pause (v10.4):" -ForegroundColor Green
    Write-Host "  pause [hours]            Pause all crons (default 4h, RAM-saving)"
    Write-Host "  resume                   Clear pause marker"
    Write-Host "  games <list|add|remove|reset>"
    Write-Host "                           Manage game-process detection list"
    Write-Host ""
    Write-Host "  alias                    Print PowerShell profile alias to copy"
    Write-Host "  help [<command>]         This message"
    Write-Host ""
    Write-Host "EXAMPLES:" -ForegroundColor Yellow
    Write-Host "  ultron status"
    Write-Host "  ultron ask que es Mythos"
    Write-Host "  ultron open tortunabo"
    Write-Host "  ultron claude               # (otra ventana, sesion interactiva)"
    Write-Host "  ultron pause 2              # 2h sin que corran crons"
    Write-Host "  ultron schedule install"
    Write-Host ""
}

function Show-Status {
    Write-Host ""
    Write-Host "ULTRON CORE Status" -ForegroundColor Cyan
    Write-Host "=================="
    Write-Host ""

    $cockpitHome = Join-Path $env:USERPROFILE ".ultron\cockpit"
    $projectsJson = Join-Path $cockpitHome "projects.json"
    $alertsMd = Join-Path $cockpitHome "news\ALERTS.md"

    # Projects summary
    if (Test-Path $projectsJson) {
        $data = Get-Content -Raw -Encoding UTF8 $projectsJson | ConvertFrom-Json
        $projects = $data.projects
        $byStatus = @{}
        foreach ($p in $projects) {
            $s = if ($p.status) { $p.status } else { "?" }
            if (-not $byStatus.ContainsKey($s)) { $byStatus[$s] = 0 }
            $byStatus[$s] += 1
        }

        Write-Host "[Projects]" -ForegroundColor Green
        Write-Host ("  Total: {0}  |  Last scan: {1}" -f $projects.Count, $data.last_scan)
        foreach ($k in $byStatus.Keys | Sort-Object) {
            Write-Host ("    {0,-18} {1}" -f $k, $byStatus[$k])
        }

        # Top 5 by last_active (active or auto-detected only)
        Write-Host ""
        Write-Host "  Recent activity:" -ForegroundColor DarkGray
        $recent = $projects |
            Where-Object { $_.status -in @("active","auto-detected") -and $_.last_active } |
            Sort-Object -Property last_active -Descending |
            Select-Object -First 5
        foreach ($p in $recent) {
            Write-Host ("    {0,-32} {1,-14} last={2}" -f $p.id, $p.ide, $p.last_active)
        }
    } else {
        Write-Host "[Projects]" -ForegroundColor Yellow
        Write-Host "  No registry yet. Run: ultron scan"
    }

    Write-Host ""

    # Auth vault summary
    Write-Host "[Auth Vault]" -ForegroundColor Green
    & $Python (Join-Path $CockpitDir "auth_vault.py") status 2>&1 | ForEach-Object { Write-Host "  $_" }

    Write-Host ""

    # Activity tracker summary
    $activityJsonl = Join-Path $cockpitHome "activity.jsonl"
    Write-Host "[Activity (last 7d)]" -ForegroundColor Green
    if (Test-Path $activityJsonl) {
        & $Python (Join-Path $CockpitDir "track_activity.py") summary --days 7 2>&1 |
            Select-Object -First 8 |
            ForEach-Object { Write-Host "  $_" }
    } else {
        Write-Host "  No activity logged yet (run: ultron track snapshot)"
    }

    Write-Host ""

    # Alerts
    Write-Host "[Alerts]" -ForegroundColor Green
    if (Test-Path $alertsMd) {
        $alertsContent = Get-Content -Raw $alertsMd
        if ($alertsContent.Trim()) {
            Write-Host "  ALERTS pending - read: $alertsMd" -ForegroundColor Red
        } else {
            Write-Host "  No alerts"
        }
    } else {
        Write-Host "  No news scraper output yet (4.L pending)"
    }

    Write-Host ""

    # Usage (last 1h + 24h compact summary)
    Write-Host "[Usage] (Claude Code + Codex - 5h rolling + weekly windows)" -ForegroundColor Green
    $usageScript = Join-Path $CockpitDir "usage_tracker.py"
    if (Test-Path $usageScript) {
        $py = Get-Command python -ErrorAction SilentlyContinue
        if (-not $py) { $py = Get-Command python3 -ErrorAction SilentlyContinue }
        if ($py) {
            & $py.Source $usageScript --json 2>$null |
                ForEach-Object -Begin {$buf = ""} -Process {$buf += $_} -End {
                    if ($buf) {
                        try {
                            $data = $buf | ConvertFrom-Json
                            $h1 = $data.last_1h.total
                            $h24 = $data.last_24h.total
                            $d7 = $data.last_7d.total
                            function fmt($n) { if ($n -ge 1000000) { "{0:N1}M" -f ($n/1000000) } elseif ($n -ge 1000) { "{0:N1}K" -f ($n/1000) } else { "$n" } }
                            $b1 = $h1.in + $h1.out + $h1.cache_create + $h1.cache_read
                            $b24 = $h24.in + $h24.out + $h24.cache_create + $h24.cache_read
                            $b7 = $d7.in + $d7.out + $d7.cache_create + $d7.cache_read
                            Write-Host ("  Last 1h:  {0,-8} ({1} turns)" -f (fmt $b1), $h1.count)
                            Write-Host ("  Last 24h: {0,-8} ({1} turns)" -f (fmt $b24), $h24.count)
                            Write-Host ("  Last 7d:  {0,-8} ({1} turns)" -f (fmt $b7), $d7.count)
                            Write-Host "  (full report: ultron usage)" -ForegroundColor DarkGray
                        } catch {
                            Write-Host "  (usage data unavailable)" -ForegroundColor DarkGray
                        }
                    }
                }
        }
    }
    Write-Host ""

    # Scheduler
    Write-Host "[Scheduler]" -ForegroundColor Green
    $schedulerScript = Join-Path $CockpitDir "install-scheduler.ps1"
    if (Test-Path $schedulerScript) {
        & powershell -NoProfile -ExecutionPolicy Bypass -File $schedulerScript -Status 2>&1 |
            Select-Object -First 6 |
            ForEach-Object { Write-Host "  $_" }
    }
    Write-Host ""
}

function Show-News {
    $newsDir = Join-Path $env:USERPROFILE ".ultron\cockpit\news"
    if (-not (Test-Path $newsDir)) {
        Write-Host "[News] Not enabled yet"
        return
    }

    $alerts = Join-Path $newsDir "ALERTS.md"
    if ((Test-Path $alerts) -and ((Get-Item $alerts).Length -gt 0)) {
        Write-Host "[ALERTS]" -ForegroundColor Red
        Get-Content $alerts
        Write-Host ""
    }

    $today = Get-Date -Format "yyyy-MM-dd"
    $digest = Join-Path $newsDir "$today.md"
    if (Test-Path $digest) {
        Write-Host "[Digest $today]" -ForegroundColor Cyan
        Get-Content $digest
    } else {
        Write-Host "[News] No digest for $today (next run: see scheduler)"
    }
}

function Show-Alias {
    Write-Host ""
    Write-Host "Add this to your PowerShell profile (`$PROFILE):" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  function ultron { & '$PSCommandPath' @args }" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Or one-liner to install it now:" -ForegroundColor Cyan
    Write-Host ""
    $line = "function ultron { & '" + $PSCommandPath + "' @args }"
    Write-Host "  Add-Content -Path `$PROFILE -Value `"$line`"" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Then in any new PowerShell session: ultron status" -ForegroundColor DarkGray
    Write-Host ""
}

# ---- Dispatch ---------------------------------------------------------------

switch ($Command.ToLower()) {

    "help"      { Show-Help }
    "-h"        { Show-Help }
    "--help"    { Show-Help }

    "status"    { Show-Status }
    "alias"     { Show-Alias }

    "news" {
        # If args present (e.g. --no-gemini, --verbose) -> RUN scraper.
        # If no args -> SHOW today's digest.
        if ($Rest -and $Rest.Count -gt 0) {
            Invoke-Py "news_scraper.py" $Rest
        } else {
            Show-News
        }
    }

    "open" {
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "Usage: ultron open <project>" -ForegroundColor Yellow
            exit 1
        }
        Invoke-Py "launch_project.py" $Rest
    }

    "projects" {
        if (-not $Rest -or $Rest.Count -eq 0) {
            Invoke-Py "launch_project.py" @("--list")
        } else {
            Invoke-Py "launch_project.py" $Rest
        }
    }

    "scan"      { Invoke-Py "scan_projects.py" $Rest }
    "track"     { Invoke-Py "track_activity.py" $Rest }
    "retention" { Invoke-Py "retention.py" $Rest }

    "dashboard" {
        # If --print is the only arg, just cat DASHBOARD.md. Otherwise rebuild.
        if ($Rest -and $Rest[0] -eq "--print") {
            $dash = Join-Path $env:USERPROFILE ".ultron\cockpit\DASHBOARD.md"
            if (Test-Path $dash) { Get-Content $dash } else { Write-Host "(no DASHBOARD.md yet)" }
        } else {
            Invoke-Py "build_dashboard.py" $Rest
        }
    }

    "standup" {
        if ($Rest -and $Rest -contains "--print") {
            Invoke-Py "ai_standup.py" @("--print")
        } else {
            Invoke-Py "ai_standup.py" $Rest
        }
    }

    "newsletter" {
        Invoke-Py "newsletter.py" $Rest
    }

    "research" {
        Invoke-Py "research.py" $Rest
    }

    "tui" {
        Invoke-Py "tui.py" $Rest
    }

    "calendar" {
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "Usage: ultron calendar <--sample|--print|--events <file>|--stdin>" -ForegroundColor Yellow
            exit 1
        }
        Invoke-Py "calendar_match.py" $Rest
    }

    "schedule" {
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "Usage: ultron schedule <install|status|uninstall>" -ForegroundColor Yellow
            Write-Host "       ultron schedule list                       (show all tasks)" -ForegroundColor Yellow
            Write-Host "       ultron schedule enable|disable <task>      (toggle, instant)" -ForegroundColor Yellow
            Write-Host "       ultron schedule edit <task> <query...> [--apply]   (Haiku, dry-run)" -ForegroundColor Yellow
            Write-Host "       ultron schedule chat <query...> [--apply]  (Sonnet, multi-task)" -ForegroundColor Yellow
            exit 1
        }
        $action = $Rest[0].ToLower()
        $remaining = if ($Rest.Count -gt 1) { $Rest[1..($Rest.Count-1)] } else { @() }
        switch ($action) {
            "install"   { Invoke-Ps "install-scheduler.ps1" @() }
            "status"    { Invoke-Ps "install-scheduler.ps1" @("-Status") }
            "uninstall" { Invoke-Ps "install-scheduler.ps1" @("-Uninstall") }
            "list"      { Invoke-Py "schedule_editor.py" @("list") }
            "enable"    { Invoke-Py "schedule_editor.py" (@("enable") + $remaining) }
            "disable"   { Invoke-Py "schedule_editor.py" (@("disable") + $remaining) }
            "edit"      { Invoke-Py "schedule_editor.py" (@("edit") + $remaining) }
            "chat"      { Invoke-Py "schedule_editor.py" (@("chat") + $remaining) }
            default {
                Write-Host "Unknown schedule action: $action" -ForegroundColor Red
                exit 1
            }
        }
    }

    "mcp" {
        # ultron mcp <action> [args]  → mcp_installer.py or mcp_creator.py
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "Usage:" -ForegroundColor Yellow
            Write-Host "  ultron mcp <list|catalog|install|uninstall|validate> [args]"
            Write-Host "  ultron mcp wrap <id>     Route MCP through zero-trust broker"
            Write-Host "  ultron mcp unwrap <id>   Restore direct connection"
            Write-Host "  ultron mcp scaffold <idea...> [--lang python|ts] [--apply]   (Sonnet, dry-run)"
            exit 1
        }
        $action = $Rest[0].ToLower()
        if ($action -eq "scaffold") {
            $remaining = if ($Rest.Count -gt 1) { $Rest[1..($Rest.Count-1)] } else { @() }
            Invoke-Py "mcp_creator.py" (@("scaffold") + $remaining)
        } else {
            Invoke-Py "mcp_installer.py" $Rest
        }
    }

    "notes" {
        # ultron notes <id> [save "text"|list|export]
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "Usage:" -ForegroundColor Yellow
            Write-Host "  ultron notes <id> save <text...>    Append timestamped note"
            Write-Host "  ultron notes <id> list [--n N]      Show last N notes (default 10)"
            Write-Host "  ultron notes <id> export [--n N]    Markdown block for context.md"
            Write-Host "  ultron notes <id> delete <n>        Delete note by index (1=oldest, -1=newest)"
            exit 1
        }
        $projectId = $Rest[0]
        $remaining = if ($Rest.Count -gt 1) { $Rest[1..($Rest.Count-1)] } else { @() }
        $pyArgs = @($remaining[0]) + @($projectId) + $(if ($remaining.Count -gt 1) { $remaining[1..($remaining.Count-1)] } else { @() })
        Invoke-Py "project_notes.py" $pyArgs
    }

    "auth" {
        # Map: ultron auth <action> [args]  -> auth-vault.ps1 OR auth_wizard.py
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "Usage:" -ForegroundColor Yellow
            Write-Host "  ultron auth <add|get|list|switch|remove|status> [args]   (raw vault ops)"
            Write-Host "  ultron auth wizard new <service>                         (interactive Q&A)"
            Write-Host "  ultron auth wizard chat <query...> [--apply]             (Haiku NL→action)"
            exit 1
        }
        $action = $Rest[0].ToLower()
        $remaining = if ($Rest.Count -gt 1) { $Rest[1..($Rest.Count-1)] } else { @() }
        if ($action -eq "wizard") {
            if ($remaining.Count -eq 0) {
                Write-Host "Usage: ultron auth wizard <new|list|chat> ..." -ForegroundColor Yellow
                exit 1
            }
            Invoke-Py "auth_wizard.py" $remaining
        } else {
            $actionMap = @{
                "add"="Add"; "get"="Get"; "list"="List";
                "switch"="Switch"; "remove"="Remove"; "status"="Status"
            }
            if (-not $actionMap.ContainsKey($action)) {
                Write-Host "Unknown auth action: $action" -ForegroundColor Red
                exit 1
            }
            $argsList = @("-Action", $actionMap[$action]) + $remaining
            Invoke-Ps "auth-vault.ps1" $argsList
        }
    }

    "desktop" {
        $action = if ($Rest -and $Rest.Count -gt 0) { $Rest[0].ToLower() } else { "install" }
        switch ($action) {
            "install"   { Invoke-Ps "desktop-shortcut.ps1" @() }
            "uninstall" { Invoke-Ps "desktop-shortcut.ps1" @("-Uninstall") }
            default {
                Write-Host "Unknown desktop action: $action" -ForegroundColor Red
                Write-Host "Try: ultron desktop install | ultron desktop uninstall" -ForegroundColor Yellow
                exit 1
            }
        }
    }

    "pause" {
        # ultron pause [hours]  - pause all crons (RAM-saving for gaming)
        $args = @("pause")
        if ($Rest -and $Rest.Count -gt 0) { $args += $Rest[0] }
        Invoke-Py "should_run.py" $args
    }

    "resume" {
        Invoke-Py "should_run.py" @("resume")
    }

    "status" {
        # Show pause + gaming detection state. Exit 2 if cron jobs would be skipped.
        Invoke-Py "should_run.py" @("status")
    }

    "games" {
        # ultron games [list|add <proc>|remove <proc>|reset]
        $args = @("games")
        if ($Rest -and $Rest.Count -gt 0) { $args += $Rest }
        Invoke-Py "should_run.py" $args
    }

    "claude" {
        # Spawn interactive Claude session in current cwd. Uses Windows Terminal
        # if available, otherwise PowerShell window. Pass-through args go to claude.
        $cwd = Get-Location
        if (Get-Command wt.exe -ErrorAction SilentlyContinue) {
            $wtArgs = @("new-tab", "--title", "Claude", "-d", $cwd.Path, "claude", "--dangerously-skip-permissions")
            if ($Rest) { $wtArgs += $Rest }
            Start-Process wt.exe -ArgumentList $wtArgs
            Write-Host "[claude] Spawned new tab in Windows Terminal (cwd=$cwd)" -ForegroundColor Green
        } else {
            $cmdLine = "claude --dangerously-skip-permissions"
            if ($Rest) { $cmdLine += " " + ($Rest -join " ") }
            Start-Process powershell.exe -ArgumentList "-NoExit", "-Command", $cmdLine -WorkingDirectory $cwd
            Write-Host "[claude] Spawned PowerShell window (cwd=$cwd)" -ForegroundColor Green
        }
    }

    "gemini" {
        # Spawn interactive Gemini session in current cwd.
        $cwd = Get-Location
        if (Get-Command wt.exe -ErrorAction SilentlyContinue) {
            $wtArgs = @("new-tab", "--title", "Gemini", "-d", $cwd.Path, "gemini")
            if ($Rest) { $wtArgs += $Rest }
            Start-Process wt.exe -ArgumentList $wtArgs
            Write-Host "[gemini] Spawned new tab in Windows Terminal (cwd=$cwd)" -ForegroundColor Green
        } else {
            $cmdLine = "gemini"
            if ($Rest) { $cmdLine += " " + ($Rest -join " ") }
            Start-Process powershell.exe -ArgumentList "-NoExit", "-Command", $cmdLine -WorkingDirectory $cwd
            Write-Host "[gemini] Spawned PowerShell window (cwd=$cwd)" -ForegroundColor Green
        }
    }

    "codex" {
        # Spawn interactive Codex session in current cwd.
        $cwd = Get-Location
        if (Get-Command wt.exe -ErrorAction SilentlyContinue) {
            $wtArgs = @("new-tab", "--title", "Codex", "-d", $cwd.Path, "codex")
            if ($Rest) { $wtArgs += $Rest }
            Start-Process wt.exe -ArgumentList $wtArgs
            Write-Host "[codex] Spawned new tab in Windows Terminal (cwd=$cwd)" -ForegroundColor Green
        } else {
            $cmdLine = "codex"
            if ($Rest) { $cmdLine += " " + ($Rest -join " ") }
            Start-Process powershell.exe -ArgumentList "-NoExit", "-Command", $cmdLine -WorkingDirectory $cwd
            Write-Host "[codex] Spawned PowerShell window (cwd=$cwd)" -ForegroundColor Green
        }
    }

    "ask" {
        # Quick-ask via Haiku + mini-memoria. NOT interactive - prints answer + returns.
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "Usage: ultron ask <pregunta>  (sin comillas)" -ForegroundColor Yellow
            Write-Host "       ultron ask --no-memory <pregunta>  (sin contexto INDEX)" -ForegroundColor Gray
            exit 1
        }
        Invoke-Py "quick_ask.py" $Rest
    }

    "usage" {
        # Subscription windows tracker - 5h rolling + weekly Claude Code + Codex.
        # `ultron usage live` spawns interactive `claude /usage` for the real
        # Anthropic-side window stats (client-side slash command, not parsable
        # via --print).
        $args = @()
        if ($Rest) { $args += $Rest }
        Invoke-Py "usage_tracker.py" $args
    }

    "app" {
        # ultron app <name> [extra args]  - launch GUI app
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "Usage: ultron app <name> [args]" -ForegroundColor Yellow
            Write-Host "       ultron apps list  (to see available)" -ForegroundColor Gray
            exit 1
        }
        $args = @("launch") + $Rest
        Invoke-Py "apps_launcher.py" $args
    }

    "apps" {
        # ultron apps <list|add|remove|discover>
        if (-not $Rest -or $Rest.Count -eq 0) {
            Invoke-Py "apps_launcher.py" @("list")
        } else {
            Invoke-Py "apps_launcher.py" $Rest
        }
    }

    "audit" {
        # ultron audit list  -or-  ultron audit run <persona>
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "Usage: ultron audit list                  (show personas)" -ForegroundColor Yellow
            Write-Host "       ultron audit run <persona-name>    (Kirkardo eval, Opus FULL)" -ForegroundColor Yellow
            exit 1
        }
        Invoke-Py "persona_audit.py" $Rest
    }

    "project" {
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "Usage:" -ForegroundColor Yellow
            Write-Host "  ultron project edit <id> <query...>          (Sonnet, dry-run)"
            Write-Host "  ultron project edit <id> <query...> --apply  (commits change)"
            Write-Host "  ultron project add <description...>          (Sonnet, dry-run)"
            Write-Host "  ultron project add <description...> --apply  (commits new entry)"
            Write-Host "  ultron project delete <id> [-y]              (with confirmation)"
            Write-Host "  ultron project tag <id> add|remove <tag>     (no LLM, instant)"
            exit 1
        }
        Invoke-Py "project_editor.py" $Rest
    }

    "health" {
        # ultron health - quick health check of all CORE subsystems
        $args = @()
        if ($Rest) { $args += $Rest }
        Invoke-Py "health.py" $args
    }

    "skills" {
        # ultron skills export <skill> --target codex|gemini|both [--out <dir>]
        # ultron skills check <skill>
        # ultron skills sync-all
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "Usage:" -ForegroundColor Yellow
            Write-Host "  ultron skills export <skill> [--target codex|gemini|both] [--out <dir>]"
            Write-Host "                                    Translate Claude SKILL.md to AGENTS.md/GEMINI.md"
            Write-Host "  ultron skills check <skill> [--out <dir>]"
            Write-Host "                                    Compare drift vs target files"
            Write-Host "  ultron skills sync-all [--target both] [--out <base>]"
            Write-Host "                                    Translate ALL skills"
            exit 1
        }
        Invoke-Py "skill_sync.py" $Rest
    }

    "self-improve" {
        # AutoUpdater L1+L2+L3: scan/audit/propose/apply (human-gated)
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "ULTRON AutoUpdater (full L1+L2+L3 pipeline)" -ForegroundColor Cyan
            Write-Host "Usage:" -ForegroundColor Yellow
            Write-Host "  ultron self-improve scan          L1: rank audit candidates"
            Write-Host "  ultron self-improve audit <skill> [--quick]"
            Write-Host "                                    L1: run Kirkardo on target"
            Write-Host "  ultron self-improve history       L1: audit log with notas"
            Write-Host "  ultron self-improve news-flags    L1: news → skill update triggers"
            Write-Host "  ultron self-improve propose <audit-md>"
            Write-Host "                                    L2: Sonnet generates patches (NO apply)"
            Write-Host "  ultron self-improve proposals     L2: list pending proposals"
            Write-Host "  ultron self-improve apply <proposals-json>"
            Write-Host "                                    L3: spawn Claude to review/apply (human-gated)"
            Write-Host "  ultron self-improve full <skill>"
            Write-Host "                                    Full pipeline: audit → propose → apply (human-gated)"
            exit 1
        }
        Invoke-Py "auto_updater.py" $Rest
    }

    "skill" {
        # ultron skill create  → interactive skill scaffold
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "Usage:" -ForegroundColor Yellow
            Write-Host "  ultron skill create [--force]    Q&A interactive (Sonnet)"
            exit 1
        }
        $action = $Rest[0].ToLower()
        $remaining = if ($Rest.Count -gt 1) { $Rest[1..($Rest.Count-1)] } else { @() }
        if ($action -eq "create") {
            Invoke-Py "skill_creator.py" (@("new") + $remaining)
        } else {
            Write-Host "Unknown skill action: $action" -ForegroundColor Red
            exit 1
        }
    }

    "limits" {
        # ultron limits status|check|set <model> <field> <value>
        if (-not $Rest -or $Rest.Count -eq 0) {
            Invoke-Py "usage_limits.py" @("status")
        } else {
            Invoke-Py "usage_limits.py" $Rest
        }
    }

    "jobs" {
        # ultron jobs submit|status|list|cancel|logs|clean
        if (-not $Rest -or $Rest.Count -eq 0) {
            Write-Host "Usage:" -ForegroundColor Yellow
            Write-Host "  ultron jobs submit <label> -- <cmd...>   Launch background job"
            Write-Host "  ultron jobs list [--all] [--n N]         List recent jobs"
            Write-Host "  ultron jobs status <job_id>              Show job status + runtime"
            Write-Host "  ultron jobs logs <job_id> [--tail N]     Print last N lines stdout"
            Write-Host "  ultron jobs cancel <job_id>              Terminate running job"
            Write-Host "  ultron jobs clean [--days N]             Remove old finished jobs"
            exit 1
        }
        Invoke-Py "job_supervisor.py" $Rest
    }

    default {
        Write-Host "Unknown command: $Command" -ForegroundColor Red
        Write-Host "Try: ultron help" -ForegroundColor Yellow
        exit 1
    }
}
