#!/usr/bin/env python3
"""
ULTRON HOOK · auto-approve-readonly · v1.0
Auto-aprueba tools de solo lectura (Read, Glob, Grep, WebFetch, WebSearch) en PreToolUse.
Reduce permission prompts para flujo de exploración.

Uso en ~/.claude/settings.json:
{
  "hooks": {
    "PreToolUse": [{
      "hooks": [{
        "type": "command",
        "command": "python C:/Users/Rodrigo/.claude/skills/ultron/hooks/auto-approve-readonly.py"
      }]
    }]
  }
}
"""
import json
import sys

READ_ONLY_TOOLS = {"Read", "Glob", "Grep", "WebFetch", "WebSearch", "TaskList", "TaskGet", "TaskOutput"}


def main():
    try:
        input_data = json.loads(sys.stdin.read())
    except (json.JSONDecodeError, ValueError):
        # No valid input → no decision (let CC default behavior take over)
        sys.exit(0)

    if input_data.get("hook_event_name") != "PreToolUse":
        sys.exit(0)

    tool = input_data.get("tool_name", "")
    if tool in READ_ONLY_TOOLS:
        print(json.dumps({
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "allow",
                "permissionDecisionReason": f"Read-only tool '{tool}' auto-approved by ULTRON hook"
            }
        }))


if __name__ == "__main__":
    main()
