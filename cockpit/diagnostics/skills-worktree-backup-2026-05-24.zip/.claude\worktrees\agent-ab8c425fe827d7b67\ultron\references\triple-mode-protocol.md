# ULTRON — TRIPLE MODE PROTOCOL · v1.0
## Codex + Gemini Debate via DUET Pattern (parallel peers)

> **Introducido en:** ULTRON v9.0.0 "Triumvirate" (2026-04)
> **Backends:**
>   - OpenAI Codex CLI (`codex exec`) — `gpt-5.5`, sandbox `read-only` — `scripts/codex-duet.ps1`
>   - Google Gemini CLI (`gemini -p`) — `gemini-3-pro` o `flash`, `--approval-mode plan` — `scripts/gemini-duet.ps1`
> **Hard rule:** ambos peers son **read-only**. JAMÁS escriben en filesystem. Si proponen cambio → lo escribe Claude.
> **Objetivo:** dos modelos peer en paralelo iterando con Claude para obtener ángulos divergentes en una decisión técnica.

---

## 🤝 Los 3 sub-modos

| Sub-modo | Rounds default | Cap configurable | Output max por peer | Disponible en | Caso de uso |
|---|---|---|---|---|---|
| **MiniTriple** | **1** (CRITIQUE x 2 peers) | No — siempre 1 | ~500 tk | HIGH (trigger), ULTRA | sanity check con 2 ángulos · "¿esto rompe algo?" |
| **Triple** | **3** (PROPOSE→CRITIQUE x2→REFINE) | Sí: `/triple --rounds=N` (1-5) | ~2K tk | ULTRA siempre · HIGH bajo trigger explícito | feature nueva con divergencia probable · diseño de sistema |
| **MaxTriple** | **5** (CRITIQUE x2 → REFINE x2 → VERIFY x2) | Sí: `/maxtriple --rounds=N` (3-8) | ~5K tk | **ULTRA siempre** | arquitectura crítica · código a producción · diseñar el propio ULTRON |

**Hard rules:**
- LOW / MEDIUM → Triple **prohibido** (waste de tokens — Triple = 2 peer calls por round)
- HIGH → MiniTriple disponible, Triple solo bajo trigger explícito de Rodrigo
- ULTRA → cualquiera disponible

---

## 🔁 Protocolo round por round

### MiniTriple (1 round, 2 peers paralelos)

```
[ROUND 1: CRITIQUE x 2 peers]
  Claude (interno) → formula propuesta + contexto compacto (≤1500 tk)
  Claude → escribe prompt común a archivo temporal
  Claude → invoca EN PARALELO:
    - codex-duet.ps1 -Mode Mini -Round 1 -PromptFile <tmp>
    - gemini-duet.ps1 -Mode Mini -Round 1 -PromptFile <tmp>
  Espera ambos (foreground o background con notificación)
  Cada peer → JSON estructurado (verdict + critique + suggestions)
  Claude → síntesis: "Codex dice X, Gemini dice Y. Convergencia: Z. Divergencia: W"
```

### Triple (3 rounds default)

```
[ROUND 1: PROPOSE → CRITIQUE x 2]
  Claude → propuesta + restricciones (≤2K tk input)
  Codex || Gemini → cada uno critica de forma independiente
  Captura SESSION_ID de cada peer.
  Síntesis: ¿coinciden? ¿divergen?

[ROUND 2: REFINE x 2]
  Claude → integra ambas críticas, refina propuesta
  Claude → resume sesión con cada peer (≤500 tk):
    "He aplicado: [diff resumen]. ¿Concerns restantes?"
  Cada peer → JSON (verdict final independiente)

[ROUND 3: CONFIRM (opcional)]
  Solo si los dos peers siguen divergiendo en R2 → 1 ronda final
  Claude → "Codex prefiere A, Gemini prefiere B. Mi tie-break: C porque ..."
  Decisión de Claude prevalece, registrada en benchmark.md como "post-debate".
```

### MaxTriple (5 rounds — ULTRA only)

Como Triple pero añade VERIFY del diff post-implementación:

```
[ROUNDS 1-3] → como Triple
[ROUND 4: VERIFY del diff x 2 peers]
  Claude → diff aplicado + tests results
  Cada peer → "¿el diff implementa lo acordado? ¿edge cases nuevos?"
[ROUND 5: REFINE final si VERIFY detecta gaps]
```

---

## 🎯 Cuándo Triple vs Dual vs second-opinion

| Caso | Mejor herramienta |
|---|---|
| Sanity check rápido (1 ángulo) | **MiniDual** (Codex o Gemini, no ambos) |
| Decisión técnica con incertidumbre (1 ángulo) | **Dual** |
| 2 ángulos divergentes esperados | **MiniTriple** |
| Decisión arquitectónica (debate sustancial) | **Triple** 3 rounds |
| Código a producción / arquitectura crítica | **MaxTriple** ULTRA |
| Review final del PR/diff (puntual) | `second-opinion` skill (no overlay) |
| Análisis de codebase >150 archivos | `/dual --gemini` (Gemini 1M context) |

---

## 🏗️ Backend técnico

### Helpers

- **Codex:** `scripts/codex-duet.ps1`
  - Invoca `node.exe codex.js exec` directamente (evita .cmd wrapper)
  - JSON Schema: `references/codex-duet-schema.json`
  - Resume rounds 2+ via `codex exec resume <SESSION_ID>`
- **Gemini:** `scripts/gemini-duet.ps1` (v10.4: removed `-s` sandbox flag)
  - Invoca `gemini -p` directo (Start-Process incompat con .ps1 wrapper)
  - JSON Schema: `references/gemini-duet-schema.json`
  - Resume rounds 2+ via `gemini -r <SESSION_ID>`

### Hard caps por sesión (separados de Dual)

Counter file: `~/.ultron/sessions/<YYYY-MM-DD>/triple-caps.json`

| Modo | Cap diario sin permiso explícito |
|---|---|
| MiniTriple | **ilimitado** |
| Triple | **3 invocaciones/día** |
| MaxTriple | **1 invocación/día** |

Override: `-BypassCaps` flag en cada helper, requiere confirmación previa de Rodrigo.

### Schema de síntesis

`references/triple-debate-schema.json` (TODO consolidar):

```json
{
  "round": 1,
  "claude_proposal": "...",
  "codex_response": { "verdict": "...", "critique": "...", "suggestions": [...] },
  "gemini_response": { "verdict": "...", "critique": "...", "suggestions": [...] },
  "convergence": [...],
  "divergence": [...],
  "claude_synthesis": "..."
}
```

---

## ⚠️ Gotchas

1. **Codex prompts demasiado largos** — `codex exec` puede colgar con prompts >50K tokens. Trim contexto.
2. **Gemini stdout pollution** — primera línea suele ser `Skill X is overriding...` warning. Filtrar antes de parsear JSON.
3. **PowerShell `2>$file` parsing** — al redirigir stderr de native commands, PS5.1 wrapea como ErrorRecord y exit code se ensucia. Validar por contenido del output, no por exit code.
4. **Gemini `-s` sandbox flag** — requiere docker/podman. Sin ellos: exit 44. v10.4 lo retiró del helper. `--approval-mode plan` ya enforce read-only.
5. **Caps son por día calendario** — si hay session cross-midnight, el counter resetea al cambiar día.

---

## 🔬 Validación

- **Codex helper:** `tests/codex-duet.Tests.ps1` (Pester, 18 tests, ~1s, 0 tokens)
- **Gemini helper:** `tests/gemini-duet.Tests.ps1` (Pester, 15 tests). **v10.4 fix: tests deben re-validarse tras quitar `-s` flag.**
- **Triple síntesis:** TODO añadir `tests/triple-synthesis.Tests.ps1` para validar shape de convergence/divergence.

---

*ULTRON v9.0+ · Triple Mode = debate paralelo de 2 peers para decisiones que merecen 2 ángulos. No usar en LOW/MEDIUM — caro y ruidoso para tareas simples.*
