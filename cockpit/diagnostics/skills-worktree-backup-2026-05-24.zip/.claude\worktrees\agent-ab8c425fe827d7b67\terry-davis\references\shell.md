# Terry Davis — Shell (Bash + PowerShell)

## Contexto de Rodrigo
- **PowerShell:** automatización Windows, scripts de sistema, builds
- **Bash:** scripts de CI/CD, Linux, WSL, Git hooks
- **Herramienta:** Windows-MCP PowerShell para ejecutar en el sistema real

---

## POWERSHELL — PATRONES ESENCIALES

```powershell
# Variables y tipos
$nombre = "Rodrigo"
$numero = 42
$lista = @("a", "b", "c")
$hash = @{ Key = "Value"; Otro = 123 }

# Condicionales
if ($condicion) { ... } elseif ($otra) { ... } else { ... }

# Bucles
foreach ($item in $lista) { Write-Host $item }
1..10 | ForEach-Object { Write-Host $_ }
while ($condicion) { ... }

# Funciones
function Get-Info {
    param(
        [string]$Name,
        [int]$Count = 1  # valor por defecto
    )
    return "$Name × $Count"
}

# Manejo de errores
try {
    Risky-Command
} catch [System.IO.IOException] {
    Write-Error "IO Error: $_"
} catch {
    Write-Error "Unknown: $_"
} finally {
    # siempre ejecuta
}

# ErrorAction
Get-Item "no-existe" -ErrorAction SilentlyContinue
Get-Item "critico"   -ErrorAction Stop  # convierte error en excepción
```

---

## POWERSHELL — SISTEMA / PROCESOS

```powershell
# Procesos
Get-Process | Sort-Object CPU -Descending | Select-Object -First 10
Stop-Process -Name "NombreProceso" -Force
Get-Process -Name "chrome" | Select-Object Id, CPU, WorkingSet

# Servicios
Get-Service | Where-Object { $_.Status -eq "Running" }
Start-Service -Name "wuauserv"
Stop-Service -Name "wuauserv"

# Disco
Get-PSDrive
Get-ChildItem -Path "C:\Users\Rodrigo" -Recurse -File |
    Sort-Object Length -Descending | Select-Object -First 20 FullName,
    @{N="MB"; E={[math]::Round($_.Length/1MB,2)}}

# Red
netstat -ano | findstr ":3000"
Test-NetConnection -ComputerName google.com -Port 443

# Registro de Windows
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion"
Set-ItemProperty "HKCU:\...\key" -Name "Value" -Value "data"
```

---

## BASH — PATRONES ESENCIALES

```bash
#!/bin/bash
set -euo pipefail  # e=exit on error, u=undefined vars, o pipefail

# Variables
NAME="Rodrigo"
COUNT=0
ARRAY=("a" "b" "c")

# Condicionales
if [ "$VAR" = "valor" ]; then
    echo "igual"
elif [[ "$VAR" =~ ^[0-9]+$ ]]; then
    echo "numérico"
fi

# Bucles
for item in "${ARRAY[@]}"; do echo "$item"; done
for i in {1..10}; do echo "$i"; done
while IFS= read -r line; do echo "$line"; done < file.txt

# Funciones
setup_env() {
    local dir="$1"
    mkdir -p "$dir" && cd "$dir"
}

# Manejo de errores
command || { echo "Falló"; exit 1; }
trap 'echo "Error en línea $LINENO"' ERR
trap 'rm -f /tmp/tmpfile' EXIT  # cleanup siempre
```

---

## BASH — HERRAMIENTAS UNIX ESENCIALES

```bash
# Texto
grep -r "patrón" --include="*.ts" ./src
grep -n "TODO" **/*.py
sed -i 's/old/new/g' file.txt
awk '{print $1, $3}' data.csv
sort file.txt | uniq -c | sort -rn   # frecuencia

# Archivos
find . -name "*.log" -mtime +7 -delete    # borrar logs >7 días
find . -type f -size +100M               # archivos >100MB
rsync -av --exclude='node_modules' src/ dest/

# Procesos
ps aux | grep node
kill -9 $(lsof -t -i:3000)   # matar proceso en puerto 3000
nohup command > output.log 2>&1 &  # background persistente

# Red
curl -s https://api.example.com/data | jq '.results[]'
wget -q -O - https://url/file | tar xz

# Permisos
chmod +x script.sh
chmod 600 ~/.ssh/id_rsa
chown -R user:group /path
```

---

## GIT HOOKS (Bash)

```bash
# .git/hooks/pre-commit
#!/bin/bash
set -e
npm run lint || { echo "Lint failed"; exit 1; }
npx tsc --noEmit || { echo "Type errors"; exit 1; }
echo "Pre-commit checks passed."

# .git/hooks/commit-msg
#!/bin/bash
MSG=$(cat "$1")
PATTERN="^(feat|fix|refactor|test|docs|chore|perf|style|ci|revert)\([a-z-]+\): .{1,72}$"
if ! [[ "$MSG" =~ $PATTERN ]]; then
    echo "❌ Commit message no sigue Conventional Commits"
    echo "   Formato: type(scope): descripción"
    exit 1
fi
```

---

## DOCS

```
PowerShell: Get-Help [comando] -Full
WebFetch: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/
WebSearch: "powershell [tarea] site:learn.microsoft.com"
Bash: man [comando] | WebSearch: "bash [tarea] site:tldp.org"
```
