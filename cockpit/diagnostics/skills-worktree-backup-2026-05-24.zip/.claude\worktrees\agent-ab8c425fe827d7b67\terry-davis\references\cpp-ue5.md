# Terry Davis — C++ / Unreal Engine 5

## Entorno de Rodrigo
- **IDE:** CLion para C++ / UE5
- **Engine:** Unreal Engine 5
- **Build system:** Unreal Build Tool (UBT)
- **Rutas:** `C:\Users\Rodrigo\CARRERA\` y `C:\Users\Rodrigo\Documents\`

---

## COMANDOS DE BUILD

```powershell
# Compilar desde terminal (UAT)
& "C:\Program Files\Epic Games\UE_5.x\Engine\Build\BatchFiles\Build.bat" `
  ProjectName Win64 Development "C:\Path\To\Project.uproject" -WaitMutex

# Regenerar project files
& "C:\Program Files\Epic Games\UE_5.x\Engine\Binaries\DotNET\UnrealBuildTool\UnrealBuildTool.exe" `
  -projectfiles -project="C:\Path\To\Project.uproject" -game -rocket -progress

# Live Coding: Ctrl+Alt+F11 en el editor UE5
```

---

## HEADERS MÁS COMUNES

```cpp
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GameFramework/Character.h"
#include "GameFramework/PlayerController.h"
#include "Components/StaticMeshComponent.h"
#include "AbilitySystemComponent.h"   // GAS
#include "Net/UnrealNetwork.h"         // Replicación
#include "Kismet/GameplayStatics.h"
#include "Engine/Engine.h"
```

---

## MACROS CLAVE UE5

```cpp
// UPROPERTY flags esenciales
UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Combat")
UPROPERTY(Replicated)          // replicar variable
UPROPERTY(ReplicatedUsing=OnRep_Health)  // con callback

// UFUNCTION flags
UFUNCTION(Server, Reliable)    // RPC al servidor
UFUNCTION(Client, Reliable)    // RPC al cliente
UFUNCTION(NetMulticast, Unreliable)  // broadcast
UFUNCTION(BlueprintCallable, Category="Combat")
UFUNCTION(BlueprintImplementableEvent)  // implementar en BP
UFUNCTION(BlueprintNativeEvent)  // override en BP, base en C++

// UCLASS flags
UCLASS(Blueprintable, BlueprintType)
USTRUCT(BlueprintType)
UENUM(BlueprintType)
```

---

## REPLICACIÓN — PATRONES Y GOTCHAS

```cpp
// En el .h — declarar variables replicadas
UPROPERTY(Replicated)
float Health;

UPROPERTY(ReplicatedUsing=OnRep_Health)
float Health;

UFUNCTION()
void OnRep_Health();  // llamado SOLO en clientes cuando cambia

// En el .cpp — registrar qué se replica
void AMyActor::GetLifetimeReplicatedProps(
    TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);
    DOREPLIFETIME(AMyActor, Health);
    DOREPLIFETIME_CONDITION(AMyActor, Shield, COND_OwnerOnly);
}

// ❌ Olvidar GetLifetimeReplicatedProps → variable nunca se replica
// ❌ Llamar RPC desde cliente sin Server flag → no ejecuta en servidor
// ❌ Modificar variable en cliente esperando que se sincronice al servidor
//    → Las variables replican SERVIDOR → CLIENTE, nunca al revés
```

---

## RPCs — REGLAS

```cpp
// Server RPC: cliente llama → ejecuta en servidor
UFUNCTION(Server, Reliable, WithValidation)
void ServerDoAction(FVector Location);
// Implementación: ServerDoAction_Implementation() y ServerDoAction_Validate()

// Client RPC: servidor llama → ejecuta en el cliente propietario
UFUNCTION(Client, Reliable)
void ClientNotify(const FString& Message);

// Multicast: servidor llama → ejecuta en TODOS (servidor + clientes)
UFUNCTION(NetMulticast, Unreliable)
void MulticastPlayEffect();

// ❌ Unreliable para datos críticos (puede perderse)
// ❌ Reliable para efectos visuales frecuentes (satura el canal)
```

---

## GAMEPLAY ABILITY SYSTEM (GAS)

```cpp
// Setup básico en Character
UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
UAbilitySystemComponent* AbilitySystemComponent;

UPROPERTY()
UMyAttributeSet* AttributeSet;

// Implementar IAbilitySystemInterface
UAbilitySystemComponent* GetAbilitySystemComponent() const override {
    return AbilitySystemComponent;
}

// Inicializar en PossessedBy (servidor) y OnRep_PlayerState (cliente)
void AMyCharacter::PossessedBy(AController* NewController) {
    Super::PossessedBy(NewController);
    AbilitySystemComponent->InitAbilityActorInfo(PlayerState, this);
}

// Dar habilidad
FGameplayAbilitySpecHandle Handle = AbilitySystemComponent->
    GiveAbility(FGameplayAbilitySpec(AbilityClass, 1, INDEX_NONE, this));

// Activar por tag
AbilitySystemComponent->TryActivateAbilitiesByTag(TagContainer);
```

---

## MEMORY / GARBAGE COLLECTION

```cpp
// ✓ Objetos UObject — el GC los gestiona SI tienen UPROPERTY()
UPROPERTY()
UMyObject* MyObj;  // protegido del GC

// ❌ Raw pointer sin UPROPERTY → GC destruye el objeto sin avisar
UMyObject* MyObj;  // puede quedar dangling

// TWeakObjectPtr — no previene GC, pero es null-safe
TWeakObjectPtr<UMyObject> WeakRef;
if (WeakRef.IsValid()) WeakRef->DoSomething();

// NewObject con outer correcto
UMyComponent* Comp = NewObject<UMyComponent>(this, UMyComponent::StaticClass());

// Para ActorComponents:
UMyComponent* Comp = CreateDefaultSubobject<UMyComponent>(TEXT("MyComp"));
// Solo válido en el constructor del Actor
```

---

## PROFILING Y DEBUG

```cpp
// Imprimir en pantalla (solo dev)
GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT("Debug msg"));
GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green,
    FString::Printf(TEXT("Health: %.1f"), Health));

// Log
UE_LOG(LogTemp, Warning, TEXT("Value: %f"), SomeFloat);
UE_LOG(LogTemp, Error, TEXT("CRITICAL: %s"), *SomeString);

// Profiling con Unreal Insights
// → Lanzar UnrealInsights.exe antes de correr el juego
// → En consola del editor: Trace.Start default

// Stat commands (en consola del juego)
stat fps
stat unit
stat game
stat scenerendering
stat memory
```

---

## DOCS UE5

```
WebFetch: https://dev.epicgames.com/documentation/en-us/unreal-engine/[tema]
WebSearch: "UE5 [clase/función] site:dev.epicgames.com"
WebSearch: "unreal engine [error] site:forums.unrealengine.com"
```
