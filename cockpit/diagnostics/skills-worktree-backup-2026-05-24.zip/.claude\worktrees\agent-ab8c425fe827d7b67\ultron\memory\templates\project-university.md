# [Nombre de la Asignatura / Proyecto Académico]
Estado: ACTIVO
Iniciado: YYYY-MM-DD
Ultima actualizacion: YYYY-MM-DD
Tipo: CARRERA

## Asignatura
- Nombre: [nombre completo de la asignatura]
- Código: [código si aplica]
- Profesor: [nombre del profesor]
- Cuatrimestre: [1C / 2C / Verano] YYYY

## Tipo de entrega
[ ] Proyecto de código  [ ] Paper / memoria  [ ] Examen práctico  [ ] Otro: ___

## Enunciado / Descripción
[Descripción de lo que hay que hacer. Pegar enunciado si es posible.]

## Criterios de Evaluación
- [criterio 1]: [peso o descripción]
- [criterio 2]: [peso o descripción]
- [criterio 3]: [peso o descripción]

## Deadline
[fecha de entrega]: [hora si aplica]

## Stack / Tecnología requerida
[lenguaje, herramientas, restricciones del enunciado]

## Repositorio
- Local: C:\Users\Rodrigo\[path]\
- GitHub / Blackboard: [URL o "local"]

## Estado Actual
Proyecto inicializado. Sin implementación todavía.

## Proximos Pasos
- [ ] Leer enunciado completo
- [ ] Planificar estructura de la solución
- [ ] Primer entregable parcial

## Dudas / Preguntas al Profesor
- [duda 1]

## Notas
[apuntes relevantes, conexiones con teoría vista en clase]
