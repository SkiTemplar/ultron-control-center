# Métodos de Valoración — Referencia Warren

## Valoración Relativa (comparables)

### P/E (Price-to-Earnings)
- **Qué mide:** cuánto paga el mercado por cada € de beneficio
- **Uso:** comparar contra sector, histórico propio, índice
- **Señal cara:** P/E > media histórica del sector sin justificación de crecimiento
- **Señal barata:** P/E < media histórica con fundamentales intactos
- **Trampa:** P/E bajo puede significar negocio en declive, no oportunidad

### P/B (Price-to-Book)
- **Qué mide:** precio vs valor contable del patrimonio neto
- **Uso:** bancos, aseguradoras, industriales con muchos activos tangibles
- **Señal:** P/B < 1 puede indicar empresa cotizando por debajo de liquidación
- **Trampa:** no sirve para empresas con intangibles grandes (tech, marcas)

### EV/EBITDA
- **Qué mide:** valor total empresa vs beneficio operativo antes de amortizaciones
- **Uso:** comparar empresas con distintas estructuras de deuda o tasas impositivas
- **Ventaja sobre P/E:** neutraliza el efecto del apalancamiento

### P/FCF (Price-to-Free Cash Flow)
- **Qué mide:** precio vs flujo de caja libre real
- **Por qué importa más que el beneficio contable:** el beneficio se puede manipular, el cash no
- **Señal clave:** empresa que genera FCF consistente pero cotiza barato en P/E suele ser oportunidad

### ROE (Return on Equity)
- **Qué mide:** rentabilidad sobre el capital propio
- **Umbral mínimo:** >15% de forma sostenida indica ventaja competitiva real
- **Trampa:** ROE alto vía apalancamiento excesivo (deuda alta) es falsa señal

---

## Valoración Absoluta (intrínseca)

### DCF (Discounted Cash Flow)
```
Valor intrínseco = Σ (FCF_t / (1+r)^t) + Valor Terminal / (1+r)^n

Variables clave:
  FCF_t    → Free Cash Flow proyectado año t
  r        → Tasa de descuento (WACC o coste de oportunidad)
  n        → Horizonte de proyección (típico: 10 años)
  Valor Terminal = FCF_n × (1+g) / (r - g)   [g = crecimiento perpetuo, ≤ PIB]
```
- **Ventaja:** da un precio objetivo concreto
- **Trampa:** garbage in, garbage out — las hipótesis de crecimiento lo condicionan todo
- **Regla Warren:** si el negocio requiere supuestos muy optimistas para justificar el precio, pasar

### Margen de Seguridad
- Comprar solo cuando precio de mercado < valor intrínseco estimado con descuento del 20-30%
- El margen compensa errores en las proyecciones
- Frase clave: "Price is what you pay, value is what you get"

---

## Indicadores de Calidad (Munger / Buffett)

| Indicador | Umbral positivo | Qué significa |
|---|---|---|
| Margen neto | >15% sostenido | Poder de fijación de precios (moat) |
| Crecimiento ingresos | >8% CAGR 5 años | Negocio en expansión real |
| Deuda/EBITDA | <2x | Balance saneado, resistente a recesión |
| Payout ratio dividendo | 40-70% | Sostenible y con margen de crecimiento |
| Recompra de acciones | Consistente | Management enfocado en accionista |
| ROIC | >12% | Capital asignado eficientemente |

---

## Red Flags de Valoración

- Crecimiento de ingresos sin crecimiento de FCF → beneficio de papel, no real
- Deuda creciente en ciclo económico bueno → problema estructural
- Guidance revisado a la baja repetidamente → management sin visibilidad
- Insiders vendiendo masivamente → señal interna negativa
- P/E muy bajo en sector sin deterioro visible → puede ser trampa de valor
