# Niche Discovery Framework — Jordan Belfort

## El Sistema de Puntuación de Nichos (0-10)

Para cada nicho potencial, puntúa del 1 al 10 en 5 dimensiones. Nichos con >35 puntos merecen validación activa.

### Dimensión 1: INTENSIDAD DEL DOLOR (0-10)
- 0-3: Tienen un software que les funciona bien
- 4-6: Usan soluciones parciales (Excel, papel, WhatsApp)
- 7-9: Proceso manual caótico, errores frecuentes, tiempo perdido
- 10: El problema les cuesta dinero real mensualmente y lo saben

### Dimensión 2: VACÍO DE MERCADO (0-10)
- 0-3: Existe software bueno, asequible y adoptado masivamente
- 4-6: Existe software pero es caro, viejo, o difícil de usar
- 7-9: Solo hay soluciones genéricas no adaptadas al sector
- 10: No existe nada específico para este sector en España

### Dimensión 3: CAPACIDAD DE PAGO (0-10)
- 0-3: Sector con márgenes muy bajos (<10%)
- 4-6: Márgenes medios, pagarían €30-50/mes máximo
- 7-9: Márgenes decentes, pagarían €70-150/mes sin problema
- 10: Sector lucrativo, €200+/mes es irrelevante vs. el valor que aporta

### Dimensión 4: VOLUMEN DE MERCADO ESPAÑA (0-10)
- 0-3: Menos de 2.000 negocios en España
- 4-6: 2.000-10.000 negocios
- 7-9: 10.000-50.000 negocios
- 10: +50.000 negocios (mercado masivo)

### Dimensión 5: FACILIDAD DE ACCESO (0-10)
- 0-3: Sector muy cerrado, difícil llegar a los dueños
- 4-6: Se puede llegar pero requiere esfuerzo (ferias, asociaciones)
- 7-9: Los dueños son accesibles, toman decisiones rápido
- 10: Puedes aparecer físicamente y hablar con el dueño en 5 minutos

---

## Análisis de Nichos Identificados

| Nicho | Dolor | Vacío | Pago | Volumen | Acceso | TOTAL | Veredicto |
|-------|-------|-------|------|---------|--------|-------|-----------|
| Talleres / Desguaces | ★★★★★ | ★★★★☆ | ★★★★☆ | ★★★★★ | ★★★★★ | 23/25 | ALTA PRIORIDAD (en desarrollo) |
| Instaladores (fontanería, electricidad) | ★★★★★ | ★★★★★ | ★★★★★ | ★★★★★ | ★★★☆☆ | 22/25 | MUY ALTA PRIORIDAD |
| Clínicas veterinarias | ★★★★☆ | ★★★☆☆ | ★★★★★ | ★★★★☆ | ★★★★☆ | 21/25 | BUENA OPORTUNIDAD |
| Academias idiomas / formación | ★★★★☆ | ★★★★☆ | ★★★☆☆ | ★★★★★ | ★★★★★ | 20/25 | VÁLIDO |
| Empresas de limpieza | ★★★★★ | ★★★★★ | ★★★☆☆ | ★★★★★ | ★★★★☆ | 20/25 | INTERESANTE, cuidado margen |
| Autoescuelas | ★★★★☆ | ★★★★☆ | ★★★★☆ | ★★★☆☆ | ★★★★★ | 19/25 | VÁLIDO, mercado limitado |
| Peluquerías / Estética | ★★★☆☆ | ★☆☆☆☆ | ★★☆☆☆ | ★★★★★ | ★★★★★ | 14/25 | DESCARTAR — Fresha es gratis |

---

## Metodología de Research Rápido (2 horas por nicho)

### Paso 1: Búsqueda de competencia (30 min)
- Google: "[sector] software gestión España"
- Capterra: buscar "[sector]" + filtrar España
- G2: mismo proceso
- Product Hunt: "[sector] management software"
Evaluar: precio, reviews, UX, penetración de mercado

### Paso 2: Tamaño de mercado (20 min)
- INE → DIRCE → buscar CNAE del sector
- Google: "número de [sector] España estadística"

### Paso 3: Comunidades del sector (20 min)
- Facebook: grupos de "[sector] España"
- Foros especializados del sector
- LinkedIn: grupos del sector
Observar de qué se quejan. Las quejas = oportunidades de negocio.

### Paso 4: Entrevistas express (50 min)
Visitar o llamar a 3 negocios. Script:
- "¿Cómo gestionas actualmente X?"
- "¿Qué es lo que más tiempo te quita?"
- "¿Has probado algún software? ¿Por qué lo dejaste?"
- "Si existiera una herramienta que hiciera X, ¿cuánto pagarías?"

---

## Red Flags (descartan un nicho)
- Software gratuito dominante (Fresha, etc.)
- Un player con +60% cuota de mercado y buenas reviews
- Facturación media del negocio <€80K/año
- Menos de 5.000 negocios en España
- Sector muy estacional

## Green Flags (confirman un nicho)
- Dueños se quejan activamente del proceso manual en grupos/foros
- Software existente con reviews de "es complicado" o "no dan soporte"
- El sector tiene ferias propias (punto de entrada para ventas)
- Hay asociaciones sectoriales activas
- Un dueño dice "si esto existiera lo compraría mañana" en la primera conversación
