#!/usr/bin/env python3
"""
ULTRON v10.4.2 - Usage limits (per-model daily caps).

Reads token usage from usage_tracker.py and warns/blocks when daily caps reached.
Config in ~/.ultron/cockpit/usage-limits.json:
  {
    "claude-opus-4-7":     {"daily_billable": 2000000000, "warn_at_pct": 80},
    "claude-sonnet-4-6":   {"daily_billable": 5000000000, "warn_at_pct": 80},
    "claude-haiku-4-5":    {"daily_billable": 10000000000, "warn_at_pct": 90},
    "gpt-5.5":             {"daily_billable": 1000000000, "warn_at_pct": 80},
    "gemini-3-pro":        {"daily_billable": 500000000, "warn_at_pct": 80}
  }

Status: status (default) · check (exit 2 if any model over warn) · set <model> <field> <value>

Usage:
    usage_limits.py status
    usage_limits.py check                         # exit 0 ok, 2 warn, 3 over-cap
    usage_limits.py set <model> daily_billable <n>
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

sys.path.insert(0, str(Path(__file__).parent))
from cockpit_base import COCKPIT_DIR  # noqa: E402

LIMITS_PATH = COCKPIT_DIR / "usage-limits.json"

# Defaults (high enough that normal use never triggers; user tunes via `set`)
DEFAULT_LIMITS = {
    "claude-opus-4-7":          {"daily_billable": 2_000_000_000, "warn_at_pct": 80},
    "claude-sonnet-4-6":         {"daily_billable": 5_000_000_000, "warn_at_pct": 80},
    "claude-haiku-4-5-20251001": {"daily_billable": 10_000_000_000, "warn_at_pct": 90},
    "gpt-5.5":                   {"daily_billable": 1_000_000_000, "warn_at_pct": 80},
    "gemini-3-pro":              {"daily_billable": 500_000_000, "warn_at_pct": 80},
}


def load_limits() -> dict:
    if not LIMITS_PATH.exists():
        return DEFAULT_LIMITS.copy()
    try:
        return json.loads(LIMITS_PATH.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return DEFAULT_LIMITS.copy()


def save_limits(data: dict) -> None:
    LIMITS_PATH.parent.mkdir(parents=True, exist_ok=True)
    LIMITS_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def fetch_usage_24h() -> dict:
    """Calls usage_tracker.py --json and returns by_model dict for last_24h."""
    script = Path(__file__).parent / "usage_tracker.py"
    try:
        r = subprocess.run([sys.executable, str(script), "--json"],
                            capture_output=True, text=True,
                            timeout=30, encoding="utf-8")
        data = json.loads(r.stdout)
        return data.get("last_24h", {}).get("by_model", {})
    except Exception as e:
        print(f"[limits] usage_tracker failed: {e}", file=sys.stderr)
        return {}


def fmt_n(n: int) -> str:
    if n >= 1_000_000_000: return f"{n/1_000_000_000:.1f}G"
    if n >= 1_000_000:     return f"{n/1_000_000:.1f}M"
    if n >= 1_000:         return f"{n/1_000:.1f}K"
    return str(n)


def billable_total(by_model_entry: dict) -> int:
    return (by_model_entry.get("in", 0) +
            by_model_entry.get("out", 0) +
            by_model_entry.get("cache_create", 0) +
            by_model_entry.get("cache_read", 0))


def cmd_status(_args) -> int:
    limits = load_limits()
    usage = fetch_usage_24h()
    print("USAGE LIMITS (last 24h)")
    print("=" * 76)
    print(f"{'Model':<32} {'Used':>10} {'Cap':>10} {'%':>6} {'State':<10}")
    print("-" * 76)
    overall = "ok"
    for model, lim in limits.items():
        used = billable_total(usage.get(model, {}))
        cap = lim.get("daily_billable", 0)
        pct = (used / cap * 100) if cap else 0
        warn_pct = lim.get("warn_at_pct", 80)
        if pct >= 100:
            state = "[red]OVER[/red]"
            overall = "over"
        elif pct >= warn_pct:
            state = "[yellow]WARN[/yellow]"
            if overall == "ok":
                overall = "warn"
        else:
            state = "[green]ok[/green]"
        # Strip rich tags for plain print
        plain_state = state.replace("[red]", "").replace("[/red]", "")\
                            .replace("[yellow]", "").replace("[/yellow]", "")\
                            .replace("[green]", "").replace("[/green]", "")
        print(f"{model:<32} {fmt_n(used):>10} {fmt_n(cap):>10} {pct:>5.0f}% {plain_state}")
    print()
    print(f"Overall: {overall}")
    print(f"Edit: ultron limits set <model> daily_billable <n>")
    return 0


def cmd_check(_args) -> int:
    """Exit code: 0 ok, 2 warn, 3 over-cap. For pre-call gating."""
    limits = load_limits()
    usage = fetch_usage_24h()
    state = 0
    for model, lim in limits.items():
        used = billable_total(usage.get(model, {}))
        cap = lim.get("daily_billable", 0)
        pct = (used / cap * 100) if cap else 0
        if pct >= 100:
            state = max(state, 3)
        elif pct >= lim.get("warn_at_pct", 80):
            state = max(state, 2)
    return state


def cmd_set(args) -> int:
    limits = load_limits()
    if args.model not in limits:
        limits[args.model] = {"daily_billable": 1_000_000_000, "warn_at_pct": 80}
    try:
        value = int(args.value) if args.field == "daily_billable" else float(args.value)
    except ValueError:
        print(f"[limits] Invalid value: {args.value}")
        return 1
    limits[args.model][args.field] = value
    save_limits(limits)
    print(f"[limits] Set {args.model}.{args.field} = {args.value}")
    return 0


def main():
    p = argparse.ArgumentParser(description="ULTRON usage limits")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status").set_defaults(func=cmd_status)
    sub.add_parser("check").set_defaults(func=cmd_check)
    sp = sub.add_parser("set")
    sp.add_argument("model")
    sp.add_argument("field", choices=["daily_billable", "warn_at_pct"])
    sp.add_argument("value")
    sp.set_defaults(func=cmd_set)
    args = p.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
