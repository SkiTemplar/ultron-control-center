---
name: focused-fix
description: >
  Reparación sistemática de features rotas o módulos con fallos complejos.
  Activar cuando: "haz que X funcione" · feature entera rota · módulo con errores en cascada
  · bug que afecta múltiples archivos · no se sabe por dónde empezar.
  NO usar para bugs triviales de 1 archivo — usar MEDIUM directo.
---

# Focused Fix — Reparación Sistemática en 5 Fases

## ⛔ REGLA ABSOLUTA

**SIN FIXES HASTA COMPLETAR FASES 1–3.**
No proponer soluciones hasta que el diagnóstico esté completo.

---

## FASE 1 — SCOPE (mapear la feature)

```
1. Identificar carpeta/módulo raíz de la feature
2. Listar TODOS los archivos involucrados (Glob)
3. Identificar entry points (exports, rutas, event handlers)
4. Identificar dependencias internas (qué importa qué)
```

Output: árbol de archivos + entry points marcados.

---

## FASE 2 — TRACE (dependencias completas)

```
INBOUND:  ¿Qué necesita esta feature del exterior?
          - Imports de otros módulos
          - Variables de entorno (.env)
          - Archivos de configuración
          - APIs/endpoints externos

OUTBOUND: ¿Qué depende de esta feature?
          - Qué módulos importan desde aquí
          - Qué páginas/componentes la consumen
          - Tests que la ejercitan
```

Output: grafo de dependencias in/out.

---

## FASE 3 — DIAGNOSE (encontrar el origen real)

Verificar en este orden:

```
[ ] Imports rotos o circulares
[ ] Tipos inconsistentes entre módulos (TypeScript errors)
[ ] Async sin await / promesas sin manejar
[ ] Variables de entorno faltantes o mal nombradas
[ ] Migraciones de BD no aplicadas
[ ] Tests fallando (y qué dicen exactamente)
[ ] Logs de error (qué dice el stack trace real)
[ ] Git blame: ¿cuándo dejó de funcionar? ¿qué cambió?
```

Para cada problema encontrado, asignar nivel:
- **HIGH**: bloquea completamente la feature
- **MED**: degrada funcionalidad pero no bloquea
- **LOW**: cosmético o edge case

---

## FASE 4 — FIX (en orden estricto)

Reparar en esta secuencia exacta:
1. Dependencias rotas (imports, env vars, migraciones)
2. Tipos e interfaces
3. Lógica de negocio
4. Tests
5. Integración con módulos externos

**Si 3+ fixes crean nuevos problemas → PARAR.**
Reportar a Rodrigo: "Esto tiene un problema arquitectónico, no de implementación."
No seguir parcheando síntomas.

---

## FASE 5 — VERIFY

```
[ ] Tests de la feature: todos pasan
[ ] Tests de módulos que dependen: todos pasan
[ ] Test suite completo: sin regresiones nuevas
[ ] Verificación manual si hay UI involucrada
[ ] Documentar en commit: qué era el bug real y cómo se resolvió
```

---

## SEÑALES DE PARADA

- Cascada de fixes que no termina → problema arquitectónico
- El fix correcto requiere cambiar la firma de 5+ módulos → refactor, no fix
- No hay tests y no hay forma de verificar → escribir tests antes de fixes
