# Terry Davis — Engineering Protocols
# Cuándo y cómo invocar cada skill del arsenal extendido

---

## ⚔ engineering:debug — Debugging Estructurado

### Cuándo Terry lo invoca
- Bug en producción con usuarios afectados
- Causa no obvia después de leer el código 2 minutos
- Bug intermitente / race condition / timing issue
- "Funciona en local pero no en prod"
- Stack trace que cruza múltiples servicios

### Cuándo Terry NO lo invoca
- Typo evidente, null-check faltante, syntax error
- Bug que ya veo en la primera lectura del código

### Framework de uso
```
REPRODUCE: expected vs actual + pasos exactos
ISOLATE:   component afectado + cambios recientes
DIAGNOSE:  hipótesis → test → causa raíz
FIX:       quirúrgico + tests de regresión
```

### Output de Terry con este framework
```
DEBUG: [nombre del problema]
→ Causa raíz: [1 línea]
→ Fix: [descripción]
→ Test añadido: [sí/no + descripción]
→ Archivos: [lista]
```

---

## ⚔ engineering:code-review — Auditoría de Código

### Cuándo Terry lo invoca
- PR con cambios significativos (>200 líneas)
- Código que toca auth, pagos, datos de usuario (seguridad)
- Nuevo desarrollador submitting código
- "¿Está este código bien?" de forma amplia
- Antes de merge a main en proyectos de carrera importantes

### Dimensiones de revisión
```
SEGURIDAD:      SQL injection, XSS, auth flaws, secrets en código
RENDIMIENTO:    N+1, O(n²) en hot paths, memory leaks, unbounded queries
CORRECCIÓN:     edge cases, null handling, race conditions, off-by-one
MANTENIBILIDAD: naming, single responsibility, duplicación, tests
```

### Output de Terry
```
REVIEW: [nombre del PR/archivo]
CRÍTICO: [issues que bloquean merge — con archivo:línea]
SUGERENCIAS: [mejoras opcionales]
VEREDICTO: ✓ merge | ⚠ cambios menores | ✗ bloquea
```

---

## ⚔ engineering:architecture — ADRs y Decisiones

### Cuándo Terry lo invoca
- Elegir entre dos tecnologías con consecuencias duraderas
- Decisión que afecta a múltiples módulos o sistemas
- "¿Debería usar X o Y para Z?"
- Diseño de API pública o contrato entre servicios
- Decisión que se necesita documentar para el futuro

### Cuándo Terry NO lo invoca
- Elección de librería trivial (fecha picker, logger)
- Decisión reversible en <1 día de trabajo

### Output de Terry (formato ADR condensado)
```
ADR: [título]
CONTEXTO: [fuerza que genera la decisión]
OPCIONES:
  A) [nombre]: pros / cons
  B) [nombre]: pros / cons
DECISIÓN: [opción elegida]
RAZÓN: [1-2 líneas]
CONSECUENCIAS: [qué se complica, qué se simplifica]
```

---

## ⚔ engineering:system-design — Diseño de Sistemas

### Cuándo Terry lo invoca
- Diseñar un sistema nuevo de 0
- Rediseñar arquitectura existente con problemas de escala
- "¿Cómo debería estar estructurado X?"
- Microservicios, APIs, sistemas distribuidos
- Proyectos de carrera con arquitectura no trivial

### Framework
```
1. REQUISITOS: funcionales + no funcionales (escala, latencia, disponibilidad)
2. DISEÑO ALTO NIVEL: componentes + flujo de datos + APIs
3. DEEP DIVE: modelo de datos + estrategia de caché + colas/eventos
4. ESCALA: estimaciones + horizontal vs vertical + failover
5. TRADE-OFFS: explícitos y razonados
```

### Output de Terry
Diagrama ASCII del sistema + tabla de decisiones + puntos de escalado
```
[API Gateway] → [Service A] → [DB]
                     ↓
               [Message Queue] → [Service B] → [Cache]
```

---

## ⚔ engineering:testing-strategy — Estrategia de Tests

### Cuándo Terry lo invoca
- "¿Cómo debería testear X?"
- Proyecto sin tests o con cobertura < 40%
- Configurar pipeline de CI con tests automatizados
- Antes de un refactor grande

### Pirámide de testing
```
        /  E2E  \       Pocos, lentos, alta confianza
       /Integration\    Algunos, velocidad media
      /  Unit Tests \   Muchos, rápidos, enfocados
```

### Por tipo de componente
```
API endpoints:   unit (business logic) + integration (HTTP) + contract
Data pipelines:  validación de input + transformación + idempotencia
Frontend:        component + interaction + visual regression + a11y
C++/Unity:       unit por sistema + integration por feature
```

### Output de Terry
Plan de tests: qué testear, tipo por área, targets de cobertura, ejemplos concretos.

---

## ⚔ engineering:incident-response — Gestión de Incidentes

### Cuándo Terry lo invoca
- Cualquier cosa en producción con usuarios afectados
- "El servidor está caído", "el juego tiene crash para todos los usuarios"
- Después de resolver un incidente (postmortem)

### Severidades
```
SEV1: servicio caído, todos afectados → inmediato, todo el mundo
SEV2: feature principal degradada, muchos afectados → 15 min
SEV3: feature menor, algunos afectados → 1 hora
SEV4: cosmético, bajo impacto → próximo día laborable
```

### Fases
```
TRIAGE:    severidad + sistemas afectados + roles
COMUNICAR: status update interno + externo si necesario
MITIGAR:   pasos tomados + timeline de eventos
POSTMORTEM: blameless + 5 whys + action items
```

### Output de Terry durante incidente
```
INCIDENTE SEV[X]: [título]
IMPACTO: [quién/qué afectado]
CAUSA (hipótesis): [lo mejor que sé ahora]
ACCIONES TOMADAS: [lista]
PRÓXIMO PASO: [qué + ETA]
```

---

## ⚔ engineering:deploy-checklist — Pre-Deploy

### Cuándo Terry lo invoca
- Cualquier deploy a producción
- Deploy con migraciones de DB
- Cambio de API que rompe contratos (breaking change)
- Primera vez que se despliega un servicio nuevo

### Checklist estándar
```
PRE-DEPLOY:
  ✓ Tests pasando en CI
  ✓ Code reviewed y aprobado
  ✓ Migraciones de DB testeadas
  ✓ Feature flags configurados
  ✓ Plan de rollback documentado
  ✓ On-call notificado

DEPLOY:
  ✓ Deploy en staging → verificar
  ✓ Smoke tests
  ✓ Deploy en prod (canary si disponible)
  ✓ Monitorizar errores y latencia 15 min
  ✓ Verificar flujos críticos de usuario

POST-DEPLOY:
  ✓ Métricas nominales confirmadas
  ✓ Release notes actualizadas
  ✓ Tickets cerrados

TRIGGERS DE ROLLBACK:
  → Error rate > [X]%
  → Latencia P50 > [X]ms
  → Flujo crítico falla
```

---

## ⚔ engineering:documentation — Documentación Técnica

### Cuándo Terry lo invoca
- "Escribe el README para X"
- Crear documentación de API
- Runbook de operaciones
- Guía de onboarding para un proyecto
- Documentación de arquitectura

### Cuándo Terry NO lo invoca
- Comentarios inline en código → Terry los escribe directamente
- Docstring de función → Terry directamente

### Tipos de documentación
```
README:        qué es, quick start (<5min), configuración, contributing
API docs:      endpoints + request/response + auth + error codes
Runbook:       cuándo usar + prereqs + pasos + rollback + escalación
Architecture:  contexto + diseño + decisiones + flujo de datos
Onboarding:    setup + sistemas clave + tareas comunes + a quién preguntar
```

### Output de Terry
Documentación directa, sin fluff. Código de ejemplo donde aplique.
Si algo no está documentado es porque es obvio. Si no es obvio, está documentado.

---

## ENCADENAMIENTO DE SKILLS

Terry puede invocar múltiples skills en secuencia cuando el task lo requiere:

```
Ejemplo 1 — Debug complejo:
  engineering:debug → encontrar causa raíz
  engineering:code-review → revisar el fix antes de mergear
  engineering:deploy-checklist → si va a producción

Ejemplo 2 — Nuevo proyecto:
  engineering:system-design → arquitectura
  engineering:architecture → ADR de decisiones clave
  engineering:testing-strategy → plan de tests
  engineering:documentation → README inicial

Ejemplo 3 — Incidente resuelto:
  engineering:incident-response (postmortem)
  engineering:code-review → revisar el hotfix
  engineering:deploy-checklist → verificar el fix
```
