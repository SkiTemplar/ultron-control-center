# [Nombre Completo del Proyecto]
Estado: ACTIVO
Iniciado: YYYY-MM-DD
Ultima actualizacion: YYYY-MM-DD
Tipo: CARRERA | PERSONAL | FREELANCE

## Objetivo
[RELLENAR]

## Stack
- Lenguaje principal:
- Framework:
- Base de datos:
- Deploy:

## Deadline
sin deadline

## Rutas Clave
- Codigo local: C:\Users\Rodrigo\
- Repositorio:

## Estado Actual
Proyecto recien inicializado.

## Decisiones Tomadas
| Decision | Razonamiento | Fecha |
|----------|--------------|-------|

## Proximos Pasos
- [ ] [primer paso]

## Problemas Conocidos
ninguno

## Notas
