# Terry Davis — Web (Node.js / TypeScript / React / Next.js)

## Stack típico de Rodrigo
- **Backend:** Node.js + Express/Fastify, TypeScript
- **Frontend:** React, Next.js (App Router), TypeScript
- **DB:** MongoDB + Mongoose / PostgreSQL + Prisma
- **Auth:** JWT, bcrypt, sessions
- **Testing:** Jest, Vitest, supertest

---

## COMANDOS DE BUILD / TEST

```bash
npm run dev          # Next.js / ts-node-dev
npm run build        # Compilar producción
npm test             # Jest / Vitest
npx tsc --noEmit     # Type check sin compilar
npm audit fix        # Parchear vulnerabilidades
npx depcheck         # Dependencias no usadas
```

---

## PATRONES DE BUG — EXPRESS/NODE

```typescript
// ❌ Promise sin await — devuelve Promise, no datos
router.get('/users', async (req, res) => {
    const users = User.find();   // falta await
    res.json(users);
});

// ❌ res tras res sin return — "Cannot set headers after sent"
router.get('/item/:id', async (req, res) => {
    if (!req.params.id) res.status(400).json({ error: 'No ID' });
    // falta return ↑ — continúa ejecutando
    const item = await Item.findById(req.params.id);
    res.json(item);
});

// ❌ Middleware de auth DESPUÉS de la ruta — nunca ejecuta
app.get('/protected', handler);
app.use(authMiddleware); // demasiado tarde

// ❌ forEach con async — no espera, ejecuta en paralelo sin control
items.forEach(async (item) => {
    await processItem(item); // las promesas no se esperan
});
// ✓ usar for...of o Promise.all
```

---

## TYPESCRIPT — ERRORES FRECUENTES

```typescript
// TS2339: Property does not exist
// → Extender el tipo o usar type assertion con cuidado
interface Request { user?: UserPayload } // en express.d.ts

// TS2345: Argument of type X is not assignable to Y
// → No usar 'as any' — buscar la causa real del mismatch

// TS2532: Object is possibly undefined
// → Optional chaining: obj?.prop o null-check explícito

// any en tipos → siempre intentar tipar correctamente
// Usar 'unknown' si de verdad no se sabe el tipo
```

---

## NEXT.JS (APP ROUTER) — GOTCHAS

```typescript
// ❌ fetch sin revalidación en Server Component → dato stale
const data = await fetch('https://api.example.com/data');
// ✓
const data = await fetch('https://api.example.com/data', {
    next: { revalidate: 60 } // revalidar cada 60s
});

// ❌ usar useState/useEffect en Server Component → crash
// → Mover a Client Component y añadir 'use client' al inicio

// ❌ Mutación de estado directa en Server Action sin revalidatePath
// → Siempre llamar revalidatePath('/ruta') o revalidateTag() tras mutations

// Estructuras de carpetas App Router:
// app/[ruta]/page.tsx     → página
// app/[ruta]/layout.tsx   → layout compartido
// app/[ruta]/loading.tsx  → loading UI (Suspense automático)
// app/[ruta]/error.tsx    → error boundary
// app/api/[ruta]/route.ts → API Route Handler
```
