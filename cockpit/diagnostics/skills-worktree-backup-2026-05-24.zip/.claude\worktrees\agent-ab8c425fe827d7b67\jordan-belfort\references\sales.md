# Ventas B2B para PYMEs — Jordan Belfort

## La Mentalidad
No vendes software. Vendes tiempo libre, menos errores, más control, más dinero.
El dueño de una PYME decide solo, compra en horas, confía en personas no en marcas.

## Pipeline
LEAD → CONTACTO (2-5min) → DEMO (30min) → PROPUESTA (24h) → SEGUIMIENTO → CIERRE → ONBOARDING

---

## Scripts por Etapa

### Contacto Inicial — Objetivo: conseguir una demo, NO vender

Presencial: "Buenos días, ¿está el dueño? Soy Rodrigo, he desarrollado software para [sector]
que ayuda a [beneficio en 5 palabras]. ¿Tienes 20 minutos esta semana para verlo?"

Email: "Asunto: Software específico para [sector] — ¿te cuento en 20 min?
Hola [nombre], soy Rodrigo. He creado una herramienta para [sector] que ayuda a [beneficio].
¿20 minutos esta semana? No te voy a vender nada, solo quiero saber si te sirve."

### Demo (30 minutos)
Estructura: 5min contexto → 15min demo enfocada → 5min dudas → 5min cierre

Los 5 minutos de contexto (clave):
"¿Cómo gestionáis actualmente [proceso X]? ¿Cuánto tiempo os lleva? ¿Qué os da más problemas?"
→ Adapta la demo a lo que te acaban de contar. Nunca hagas la demo genérica.

Cierre de demo: "¿Esto resuelve lo que me comentabas? ¿Quieres probarlo? 14 días gratis, sin compromiso."

### Propuesta (máximo 1 página, enviar en <24h)
```
Para: [Negocio]
LO QUE RESUELVE:
- [Problema que te contó] → [cómo lo resuelve]
INVERSIÓN: Plan [X]: €XX/mes
PRÓXIMOS PASOS: Prueba 14 días → si convence, activamos sin interrupciones
```

### Seguimiento (el 80% de ventas se cierran aquí)
- Día 1: enviar propuesta
- Día 3: llamada — "¿Has podido echarle un vistazo?"
- Día 7: email con caso de éxito de cliente similar
- Día 14: "¿Sigue siendo buen momento?"
- Día 21: última llamada — "Si no es para ti, sin problema, solo quiero saberlo"

---

## Manejo de Objeciones

| Objeción | Respuesta |
|----------|-----------|
| "Es muy caro" | "¿Cuánto os cuesta el problema ahora en tiempo o errores? Normalmente el software se paga solo." |
| "Ahora no es el momento" | "Entendido. ¿Cuándo sería? ¿Qué tendría que pasar para que lo fuera?" |
| "Déjame pensarlo" | "Claro. ¿Qué es lo que te genera más dudas? Así te ayudo a resolverlas." |
| "Ya tenemos algo" | "¿Puedo preguntar qué usáis? Muchos clientes vinieron de ese software y se sorprendieron." |
| "¿Y si no funciona?" | "14 días de prueba y cancelas cuando quieras. El riesgo es cero." |
| "Lo veo con mi socio" | "¿Puedo estar en esa conversación? Así resuelvo dudas al momento." |

---

## Cierre
Directo: "¿Empezamos? Solo necesito tu email y te activo en 5 minutos."
Con urgencia: "El precio de lanzamiento (€XX/mes) sube el [fecha]. Si quieres entrar al precio especial, hay que decidir esta semana."

---

## Onboarding (crítico — el cliente que no adopta en 30 días se va)
- Día 0: cuenta activa + video de bienvenida 5 min
- Día 1: llamada 20min — configurar con datos reales del cliente
- Día 7: check-in — "¿Cómo va? ¿Tienes dudas?"
- Día 14: revisión — "¿Qué funciona? ¿Qué no?"
- Día 30: llamada de éxito — "¿Qué ha mejorado?"

KPI de adopción: si usó el sistema 3+ veces en los primeros 7 días → retención >85%

---

## CRM Mínimo para Empezar
Notion DB o HubSpot gratuito. Columnas mínimas:
Nombre | Empresa | Teléfono | Estado | Próxima acción | Fecha
Lo importante: registrar todo y tener siempre una próxima acción programada.
