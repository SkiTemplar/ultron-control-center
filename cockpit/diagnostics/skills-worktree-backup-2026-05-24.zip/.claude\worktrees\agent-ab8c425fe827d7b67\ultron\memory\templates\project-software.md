# [Nombre del Proyecto]
Estado: ACTIVO
Iniciado: YYYY-MM-DD
Ultima actualizacion: YYYY-MM-DD
Tipo: PERSONAL | FREELANCE

## Objetivo
[Qué problema resuelve. Qué debe hacer cuando esté terminado.]

## Stack
- Lenguaje: [ ] TypeScript  [ ] C++/UE5  [ ] C#/Unity  [ ] Python  [ ] Otro: ___
- Framework: [Next.js / Express / UE5 / Unity / FastAPI / otro]
- Base de datos: [Supabase / SQLite / ninguna]
- Deploy: [Vercel / local / otro]
- Otras deps: [lista]

## Repositorio
- Local: C:\Users\Rodrigo\[path]\
- GitHub: [URL o "local"]
- Deploy: [URL o "N/A"]

## Deadline
[fecha o "sin deadline"]

## Arquitectura
[Descripcion breve del diseño. Módulos principales, flujo de datos.]

## Estado Actual
Proyecto inicializado. Sin implementación todavía.

## Decisiones Tecnicas
| Decisión | Razonamiento | Fecha |
|----------|--------------|-------|
| [stack elegido] | [por qué este y no otro] | YYYY-MM-DD |

## Proximos Pasos
- [ ] Definir arquitectura base
- [ ] Setup de entorno (repo, deps, config)
- [ ] Primer módulo funcional

## Problemas Conocidos
[ninguno todavía]

## Notas
[cualquier idea, restricción o contexto adicional]
