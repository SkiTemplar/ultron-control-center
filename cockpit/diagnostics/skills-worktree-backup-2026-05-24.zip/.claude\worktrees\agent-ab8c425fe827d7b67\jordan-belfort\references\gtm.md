# Go-To-Market Strategy — Jordan Belfort

## ICP (Ideal Customer Profile)
- Tamaño: 2-20 empleados
- Facturación: €100K - €2M/año
- Sector: el nicho elegido
- Decisor: dueño/gerente, decide solo o con 1 socio
- Tecnología actual: papel, Excel, WhatsApp, software obsoleto
- Señal de compra: acaba de contratar más personal y el caos aumentó / perdió un cliente por error de gestión / su competidor ya usa software

---

## Canales — Priorizado por ROI

### CANAL 1: Venta Directa Local (Mes 1-6) — Coste €0
Aparecer físicamente en los negocios del sector.
Script de entrada:
"Buenos días, soy Rodrigo. Desarrollo software para [sector] que resuelve [problema].
¿Tienes 5 minutos? No te voy a vender nada hoy, solo quiero saber si puede ser útil."
KPIs: 5-10 visitas/día → 30-40% conversión a demo → 10-20% conversión a cliente

### CANAL 2: Asociaciones Sectoriales (Mes 2-8) — Coste €0-500
Contactar al presidente/secretario y proponer descuento especial para asociados.
Asociaciones relevantes:
- Talleres: CETRAA, Faconauto, asociaciones CNAE 4520
- Veterinarias: GEVE, colegios veterinarios provinciales
- Academias: FECEI, asociaciones de centros de formación
- Instaladores: FENIE, CONAIF, FER

### CANAL 3: Referidos (Mes 3+) — Coste 1-2 meses gratis por cliente referido
"Si nos recomiendas a otro [sector] y se convierte en cliente, te regalamos 2 meses gratis."
Conversión esperada: 20-40% (el canal más eficiente).

### CANAL 4: Ferias del Sector (Mes 4-12) — Coste €200-2.000
Stand pequeño o asistir como visitante con tablet + casos de éxito impresos.

### CANAL 5: SEO + Contenido (Mes 6-18) — Resultados a largo plazo
Keywords objetivo (ejemplo talleres):
- "software gestión taller mecánico"
- "programa para taller gratis"
- "como gestionar ordenes de trabajo taller"

### CANAL 6: LinkedIn Outreach (Mes 3-9) — Funciona para sectores tech-savvy
Mensaje de conexión (sin pitch):
"Hola [nombre], estoy desarrollando software para [sector] y me interesa tu perspectiva.
¿Te importa si te hago un par de preguntas rápidas?"

---

## Funnel de Adquisición
```
ALCANCE  →  INTERÉS  →  DEMO  →  PROPUESTA  →  CLIENTE
 1.000       300         150       75            30
 personas   responden   asisten   reciben       se hacen
                        a demo    propuesta     clientes
```

---

## Mensaje Central
"Para [tipo de negocio] que sufren con [problema específico],
[Producto] es la única solución diseñada específicamente para el sector
que te permite [beneficio] sin [objeción principal: complicaciones / coste elevado].
A diferencia de [competidor], nosotros [diferenciador real]."

---

## Calendario GTM — Primeros 6 Meses
- Mes 1-2: Entrevistar 20 negocios + cerrar 3-5 clientes beta
- Mes 3-4: Venta directa sistemática (5 visitas/día) + 2 asociaciones
- Mes 5-6: Primera feria del sector + SEO básico
- Objetivo: 30-40 clientes, €3.000-4.000 MRR
