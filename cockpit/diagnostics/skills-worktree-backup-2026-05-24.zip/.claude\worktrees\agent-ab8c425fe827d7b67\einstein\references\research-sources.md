# Einstein — Fuentes de Investigación por Disciplina (v3.0)

## Principio General

1. Fuente primaria > artículo divulgativo > Wikipedia
2. WebFetch a la URL exacta cuando sea posible
3. WebSearch solo si no conozco la fuente directa
4. Para papers: leer abstract + conclusiones primero, luego profundizar

---

## FÍSICA Y MATEMÁTICAS

| Fuente | URL | Qué tiene |
|---|---|---|
| HyperPhysics | hyperphysics.phy-astr.gsu.edu | Conceptos de física interconectados |
| MIT OCW Physics | ocw.mit.edu/courses/physics | Cursos completos MIT (8.01, 8.02, etc.) |
| Khan Academy Física | khanacademy.org/science/physics | Base y ejercicios |
| PhET Simulations | phet.colorado.edu | Simulaciones interactivas |
| arXiv Physics | arxiv.org/list/physics | Papers recientes |
| Wolfram MathWorld | mathworld.wolfram.com | Conceptos matemáticos |
| Paul's Math Notes | tutorial.math.lamar.edu | Cálculo, álgebra, EDO |
| NIST (constantes) | physics.nist.gov/cuu/Constants | Constantes físicas oficiales |

```
WebFetch: https://hyperphysics.phy-astr.gsu.edu/hbase/[tema].html
WebSearch: "[concepto] site:hyperphysics.phy-astr.gsu.edu"
WebSearch: "[concepto físico] site:ocw.mit.edu"
```

---

## QUÍMICA

| Fuente | URL | Qué tiene |
|---|---|---|
| PubChem | pubchem.ncbi.nlm.nih.gov | Base de datos de compuestos y moléculas |
| NIST Chemistry WebBook | webbook.nist.gov | Propiedades termoquímicas, espectros |
| Royal Society of Chemistry | rsc.org | Artículos y recursos de química |
| ChemSpider | chemspider.com | Estructura y propiedades de compuestos |
| Khan Academy Química | khanacademy.org/science/chemistry | Base y ejercicios |
| Periodic Table (IUPAC) | iupac.org | Tabla periódica oficial |
| Chemistry LibreTexts | chem.libretexts.org | Textos abiertos de química universitaria |

```
WebSearch: "[compuesto/reacción] site:pubchem.ncbi.nlm.nih.gov"
WebSearch: "[concepto químico] site:chem.libretexts.org"
WebFetch: https://webbook.nist.gov/cgi/cbook.cgi?Name=[compuesto]
```

---

## ASTRONOMÍA Y ASTROFÍSICA

| Fuente | URL | Qué tiene |
|---|---|---|
| NASA | nasa.gov / science.nasa.gov | Misiones, imágenes, noticias espaciales |
| ESA | esa.int | Agencia Espacial Europea |
| NASA APOD | apod.nasa.gov | Foto astronómica del día + explicación |
| Simbad | simbad.u-strasbg.fr | Base de datos de objetos astronómicos |
| arXiv Astro-ph | arxiv.org/list/astro-ph | Papers de astronomía y astrofísica |
| Sky & Telescope | skyandtelescope.org | Divulgación y observación astronómica |
| Hubble ESA/NASA | hubblesite.org | Imágenes y descubrimientos del Hubble |
| NASA Exoplanet Archive | exoplanetarchive.ipac.caltech.edu | Catálogo de exoplanetas |
| Wolfram Alpha (astro) | wolframalpha.com | Cálculos: distancias, tamaños, órbitas |
| ADS (Harvard) | ui.adsabs.harvard.edu | Búsqueda de papers astronómicos |

```
WebSearch: "[objeto/fenómeno] site:nasa.gov"
WebSearch: "[concepto astrofísico] site:arxiv.org astro-ph"
WebFetch: https://apod.nasa.gov/apod/ap[AAMMDD].html
WebSearch: "[estrella/galaxia] site:simbad.u-strasbg.fr"
```

---

## BIOLOGÍA, GENÉTICA Y EVOLUCIÓN

| Fuente | URL | Qué tiene |
|---|---|---|
| NCBI / PubMed | pubmed.ncbi.nlm.nih.gov | Papers biomédicos y biológicos |
| NCBI Gene | ncbi.nlm.nih.gov/gene | Base de datos genómica |
| Ensembl | ensembl.org | Genomas anotados |
| Encyclopedia of Life | eol.org | Biodiversidad y taxonomía |
| Talk Origins | talkorigins.org | Evolución, fósiles, debate creacionismo |
| Khan Academy Bio | khanacademy.org/science/biology | Base de biología |
| Nature | nature.com | Journal científico top |
| Cell | cell.com | Biología celular y molecular |
| UCMP Berkeley | ucmp.berkeley.edu | Paleontología y evolución |
| Tree of Life | tolweb.org | Árbol filogenético de la vida |

```
WebSearch: "[tema biológico] site:pubmed.ncbi.nlm.nih.gov"
WebSearch: "[especie/gen] site:eol.org"
WebSearch: "[tema evolución] site:talkorigins.org"
```

---

## GEOLOGÍA Y CIENCIAS DE LA TIERRA

| Fuente | URL | Qué tiene |
|---|---|---|
| USGS | usgs.gov | Geología, terremotos, vulcanología, mapas |
| GeoScienceWorld | geoscienceworld.org | Journals de geociencias |
| British Geological Survey | bgs.ac.uk | Mapas y recursos geológicos |
| Mindat | mindat.org | Base de datos de minerales y rocas |
| Volcano Observatory (USGS) | volcanoes.usgs.gov | Volcanes activos y monitoreo |
| IRIS Earthquake Science | iris.edu | Sismología y terremotos |
| Smithsonian Volcanoes | volcano.si.edu | Global Volcanism Program |
| Geological Society | geolsoc.org.uk | Artículos y recursos geológicos |

```
WebSearch: "[fenómeno/proceso geológico] site:usgs.gov"
WebSearch: "[mineral/roca] site:mindat.org"
WebSearch: "[volcán/terremoto] site:volcanoes.usgs.gov"
```

---

## GEOGRAFÍA Y CLIMATOLOGÍA

| Fuente | URL | Qué tiene |
|---|---|---|
| National Geographic | nationalgeographic.com | Geografía, naturaleza, exploración |
| CIA World Factbook | cia.gov/the-world-factbook | Datos de todos los países |
| WorldAtlas | worldatlas.com | Mapas, capitales, estadísticas |
| NOAA | noaa.gov | Clima, oceanografía, atmósfera |
| NASA Climate | climate.nasa.gov | Cambio climático, datos satelitales |
| IPCC | ipcc.ch | Informes sobre cambio climático |
| Climate.gov | climate.gov | Ciencia del clima accesible |
| GeoHack (Wikipedia) | geohack.toolforge.org | Coordenadas y mapas precisos |

```
WebSearch: "[país/región] site:cia.gov/the-world-factbook"
WebSearch: "[fenómeno climático] site:noaa.gov"
WebSearch: "[tema cambio climático] site:climate.nasa.gov"
```

---

## HISTORIA Y HUMANIDADES

| Fuente | URL | Qué tiene |
|---|---|---|
| Britannica | britannica.com | Enciclopedia rigurosa y fiable |
| JSTOR | jstor.org | Artículos académicos de humanidades |
| Internet Archive | archive.org | Libros y textos históricos libres |
| Oxford Reference | oxfordreference.com | Referencias académicas de Oxford |
| World History Encyclopedia | worldhistory.org | Historia universal bien documentada |
| Perseus Digital Library | perseus.tufts.edu | Textos clásicos greco-romanos |
| History.com | history.com | Artículos divulgativos de historia |
| Avalon Project (Yale) | avalon.law.yale.edu | Documentos históricos primarios |

```
WebSearch: "[evento/período] site:britannica.com"
WebSearch: "[tema historia] site:worldhistory.org"
WebSearch: "[documento histórico] site:avalon.law.yale.edu"
```

---

## FILOSOFÍA

| Fuente | URL | Qué tiene |
|---|---|---|
| Stanford Encyclopedia | plato.stanford.edu | La referencia definitiva |
| Internet Encyclopedia | iep.utm.edu | Alternativa accesible |
| PhilPapers | philpapers.org | Base de datos de papers filosóficos |
| Project Gutenberg | gutenberg.org | Textos filosóficos clásicos (libre) |

```
WebFetch: https://plato.stanford.edu/entries/[filósofo-o-concepto]/
WebSearch: "[concepto] site:plato.stanford.edu"
```

---

## PSICOLOGÍA Y NEUROCIENCIA

| Fuente | URL | Qué tiene |
|---|---|---|
| APA PsycNet | psycnet.apa.org | Journals y papers de psicología |
| PubMed Psychology | pubmed.ncbi.nlm.nih.gov | Papers biomédicos incl. psicología |
| Neuroscience News | neurosciencenews.com | Noticias de neurociencia |
| Society for Neuroscience | sfn.org | Recursos de neurociencia |
| Nature Neuroscience | nature.com/neuro | Journal top de neurociencia |
| Simply Psychology | simplypsychology.org | Divulgación accesible y bien referenciada |
| Frontiers in Psychology | frontiersin.org/journals/psychology | Papers open access |

```
WebSearch: "[concepto psicológico] site:pubmed.ncbi.nlm.nih.gov"
WebSearch: "[tema neurociencia] site:neurosciencenews.com"
```

---

## MEDICINA Y SALUD

| Fuente | URL | Qué tiene |
|---|---|---|
| PubMed / NCBI | pubmed.ncbi.nlm.nih.gov | Papers biomédicos |
| Mayo Clinic | mayoclinic.org | Información médica clara y fiable |
| Medscape | medscape.com | Medicina clínica para profesionales |
| The Lancet | thelancet.com | Journal médico de referencia |
| NEJM | nejm.org | New England Journal of Medicine |
| NIH MedlinePlus | medlineplus.gov | Enciclopedia médica de los NIH |
| WHO | who.int | Organización Mundial de la Salud |

```
WebSearch: "[condición/fármaco] site:pubmed.ncbi.nlm.nih.gov"
WebSearch: "[síntoma/enfermedad] site:mayoclinic.org"
```

---

## CIENCIAS DE LA COMPUTACIÓN / IA

| Fuente | URL | Qué tiene |
|---|---|---|
| arXiv CS/AI | arxiv.org/list/cs.AI | Papers de IA y CS |
| Papers With Code | paperswithcode.com | Papers + código |
| Semantic Scholar | semanticscholar.org | Búsqueda académica |
| Distill.pub | distill.pub | Explicaciones visuales de ML |
| ACM Digital Library | dl.acm.org | Proceedings y journals CS |
| IEEE Xplore | ieeexplore.ieee.org | Papers de ingeniería |

```
WebSearch: "[tema IA/ML] site:arxiv.org"
WebFetch: https://distill.pub/[año]/[artículo]/
```

---

## ECONOMÍA Y CIENCIAS SOCIALES

| Fuente | URL | Qué tiene |
|---|---|---|
| NBER | nber.org | Working papers de economía |
| IMF | imf.org | Informes y datos económicos globales |
| World Bank Data | data.worldbank.org | Datos económicos y sociales por país |
| JSTOR Economics | jstor.org | Journals de economía |
| Our World in Data | ourworldindata.org | Datos mundiales con visualizaciones |
| The Economist | economist.com | Análisis económico y político |
| Federal Reserve | federalreserve.gov | Datos monetarios y económicos EE.UU. |

```
WebSearch: "[tema económico] site:nber.org"
WebFetch: https://ourworldindata.org/[tema]
```

---

## LITERATURA, ARTE Y MÚSICA

| Fuente | URL | Qué tiene |
|---|---|---|
| Project Gutenberg | gutenberg.org | Libros clásicos libres |
| JSTOR | jstor.org | Artículos académicos de humanidades |
| Google Arts & Culture | artsandculture.google.com | Arte y museos del mundo |
| MoMA | moma.org | Arte moderno y contemporáneo |
| Grove Music Online | oxfordmusiconline.com | Enciclopedia de música |
| Internet Archive | archive.org | Textos, música y cine histórico |
| Poetry Foundation | poetryfoundation.org | Poesía y análisis literario |

---

## VIDEOJUEGOS / GAME DESIGN

| Fuente | URL | Qué tiene |
|---|---|---|
| GDC Vault | gdcvault.com | Charlas de desarrolladores AAA |
| Game Developer | gamedeveloper.com | Artículos técnicos |
| Unreal Docs | dev.epicgames.com/documentation | Docs oficiales UE5 |
| Unity Docs | docs.unity3d.com | Docs oficiales Unity |

---

## BÚSQUEDA ACADÉMICA GENERAL

```
WebSearch: "[tema] scholar"
WebSearch: "[tema] filetype:pdf site:edu"
WebSearch: "[autor] [año] [título parcial] arxiv"
WebSearch: "doi:[número-doi]"
```

## CUANDO NO ENCUENTRO LA FUENTE

1. Buscar el paper/libro por título en Google Scholar
2. Buscar preprint en arXiv
3. Buscar en Semantic Scholar
4. Si es libro: buscar en Internet Archive (archive.org)
5. Si aún no → indicar a Rodrigo que requiere acceso institucional
