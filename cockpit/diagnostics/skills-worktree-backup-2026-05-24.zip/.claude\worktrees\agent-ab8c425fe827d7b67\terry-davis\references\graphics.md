# Terry Davis — Graphics Programming (HLSL / GLSL / GPU)

## Contexto
- Shaders en UE5 (HLSL, Material Editor, Custom nodes)
- Shaders en Unity (HLSL via ShaderLab, Shader Graph, URP/HDRP)
- GPU programming general: DirectX 12, Vulkan, WebGPU

---

## PIPELINE DE RENDERIZADO (orden de ejecución)

```
CPU: App → Draw Calls → Command Buffer
GPU: Input Assembler → Vertex Shader → Hull Shader (tessellation)
   → Domain Shader → Geometry Shader → Rasterizer
   → Pixel/Fragment Shader → Output Merger (depth test, blending)

Compute Shader: paralelo, fuera del pipeline gráfico
```

---

## HLSL — SINTAXIS BÁSICA

```hlsl
// Tipos básicos
float, float2, float3, float4
int, uint, bool
matrix, float4x4
sampler2D, Texture2D, SamplerState

// Operaciones vectoriales
float3 a = float3(1, 0, 0);
float3 b = float3(0, 1, 0);
float d = dot(a, b);          // producto escalar
float3 c = cross(a, b);       // producto vectorial
float3 n = normalize(a);      // normalizar
float len = length(a);        // módulo
float3 r = reflect(v, n);     // reflexión
float3 refr = refract(v, n, eta); // refracción
float x = lerp(a, b, t);      // interpolación lineal
float x = saturate(x);        // clamp(x, 0, 1)
float x = smoothstep(edge0, edge1, x);

// Samplear textura
Texture2D MyTexture;
SamplerState MySampler;
float4 color = MyTexture.Sample(MySampler, uv);
float4 color = MyTexture.SampleLevel(MySampler, uv, mipLevel);
```

---

## VERTEX SHADER — ESTRUCTURA

```hlsl
struct VertexInput {
    float3 Position : POSITION;
    float3 Normal   : NORMAL;
    float2 UV       : TEXCOORD0;
};

struct VertexOutput {
    float4 Position    : SV_POSITION;  // clip space
    float3 WorldNormal : TEXCOORD0;
    float2 UV          : TEXCOORD1;
};

VertexOutput VSMain(VertexInput input) {
    VertexOutput output;
    float4 worldPos = mul(float4(input.Position, 1.0), World);
    output.Position = mul(worldPos, ViewProjection);
    output.WorldNormal = mul(input.Normal, (float3x3)WorldInvTranspose);
    output.UV = input.UV;
    return output;
}
```

---

## PIXEL/FRAGMENT SHADER — ESTRUCTURA

```hlsl
float4 PSMain(VertexOutput input) : SV_TARGET {
    float3 normal = normalize(input.WorldNormal);
    float3 lightDir = normalize(LightPosition - input.WorldPos);

    // Diffuse (Lambert)
    float NdotL = saturate(dot(normal, lightDir));
    float3 diffuse = Albedo * NdotL * LightColor;

    // Specular (Blinn-Phong)
    float3 viewDir = normalize(CameraPosition - input.WorldPos);
    float3 halfVec = normalize(lightDir + viewDir);
    float NdotH = saturate(dot(normal, halfVec));
    float3 specular = pow(NdotH, Shininess) * LightColor;

    return float4(diffuse + specular, 1.0);
}
```

---

## SHADERS EN UE5 — MATERIAL CUSTOM NODE

```hlsl
// En Custom node del Material Editor:
// Return type: float3
// Inputs: BaseColor(float3), Roughness(float), Metallic(float)

float3 result = BaseColor * (1.0 - Metallic);
result = pow(result, 1.0 / 2.2);  // gamma correction manual
return result;

// Acceder a UVs en Custom node:
return GetMaterialTexCoord(Parameters, 0);  // UV channel 0

// Acceder a normal en world space:
return Parameters.WorldNormal;
```

---

## SHADERS EN UNITY — ShaderLab

```hlsl
Shader "Custom/MyShader" {
    Properties {
        _MainTex ("Texture", 2D) = "white" {}
        _Color ("Color", Color) = (1,1,1,1)
    }
    SubShader {
        Tags { "RenderType"="Opaque" }

        Pass {
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            struct appdata { float4 vertex : POSITION; float2 uv : TEXCOORD0; };
            struct v2f { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; };

            sampler2D _MainTex;
            float4 _Color;

            v2f vert(appdata v) {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.uv = v.uv;
                return o;
            }

            fixed4 frag(v2f i) : SV_Target {
                return tex2D(_MainTex, i.uv) * _Color;
            }
            ENDHLSL
        }
    }
}
```

---

## COMPUTE SHADERS

```hlsl
// HLSL Compute Shader
RWStructuredBuffer<float4> Result;  // read/write desde GPU
StructuredBuffer<float4> Input;     // read-only

[numthreads(64, 1, 1)]  // threads por grupo: 64×1×1
void CSMain(uint3 id : SV_DispatchThreadID) {
    // id.x = thread global index
    if (id.x >= (uint)BufferSize) return;
    Result[id.x] = Input[id.x] * 2.0;
}

// Dispatch desde CPU (DirectX):
// context->Dispatch(ceil(N / 64), 1, 1)
```

---

## PATRONES DE BUG — GPU

```
❌ División por zero en shader → NaN silencioso → artefactos visuales
   ✓ Usar max(valor, 0.0001) antes de dividir

❌ Branching divergente en GPU → threads del mismo warp toman caminos distintos
   → penalización severa de rendimiento
   ✓ Usar select() / lerp() en vez de if/else cuando sea posible

❌ Texture sampling fuera del VS/PS sin derivadas → artefactos de mip
   ✓ En compute shaders usar SampleLevel() con mip explícito

❌ Escribir en un buffer mientras la GPU lo lee → race condition
   ✓ Usar barreras de memoria / fences

❌ Olvidar normalizar normales en el PS → lighting incorrecto
   (especialmente si hay interpolación entre vértices)
```

---

## PROFILING GPU

```
UE5: stat scenerendering / RenderDoc / Unreal Insights GPU track
Unity: Frame Debugger (Window > Analysis > Frame Debugger)
       GPU Profiler en Profiler window
General: RenderDoc (gratis, multiplataforma, captura frames)
         NSight Graphics (NVIDIA), PIX (Windows/Xbox)
```

---

## DOCS

```
WebFetch: https://learn.microsoft.com/en-us/windows/win32/direct3dhlsl/dx-graphics-hlsl
WebSearch: "HLSL [función/concepto] site:learn.microsoft.com"
WebSearch: "UE5 shader [tema] site:dev.epicgames.com"
WebFetch: https://docs.unity3d.com/Manual/SL-Reference.html
WebSearch: "GLSL [tema] site:khronos.org"
```
