# POLÍTICA DE VERSIONES INTER-SKILL · v7.0

## Regla de versiones

Las versiones de ULTRON y subskills son **independientes** — un subskill sube de versión cuando cambia su propio contenido, no cuando ULTRON cambia el suyo.

## Tabla de estado actual

| Skill | Versión | Último sync con ULTRON | Pendiente en próxima versión |
|---|---|---|---|
| **ultron** | v10.6.0 | — (es el orquestador) | Job supervisor (durable async lane) · Personal Context Graph · Adaptive Model Router |
| terry-davis | v4.2 | v4.2 | knowledge layer integration pendiente (terry no tiene dominios fijos del knowledge) |
| don-claudio | **v2.1** | **v7.1.0** | knowledge layer integrado (replication, GAS, enhanced-input, multiplayer) |
| mike-tyson | v2.0 | v4.1 | — |
| jordan-belfort | v2.0 | v4.1 | — |
| einstein | v3.0 | v4.5.1 | — |
| novalbos | **v1.2** | **v7.1.0** | knowledge layer integrado (opengl, cpp-modern) |
| pana | v3.1 | v4.2 | — |
| alfred | v2.2 | v4.2 | — |
| tolkien | v1.1 | v4.5.0 | — |
| tio-gilito | v2.0 | v4.1 | — |
| manolo-lama | v2.0 | v4.1 | — |
| profesor-fisica | v1.0 | v4.5.1 | — |
| repo-evaluator | v2.0 | v4.5.1 | — |
| warren | v1.0 | v6.0.1 | — |

## Cuándo actualizar un subskill

Un subskill **debe** subir versión cuando:
- Se añade un dominio, protocolo o flujo nuevo al skill
- Se corrige un bug de routing o comportamiento incorrecto
- Se añaden herramientas o MCPs nuevos relevantes para ese skill
- ULTRON introduce un mecanismo nuevo que el skill debe integrar (ej: Learn overlay → Novalbos v1.1)

Un subskill **no necesita** subir versión porque:
- ULTRON sube de patch version (v7.0.0 → v7.0.1) sin cambios en el skill
- Se añaden personas nuevas al sistema que no afectan ese skill
- Se cambia la arquitectura de ULTRON sin impactar el comportamiento del skill

## Qué hacer cuando editas un subskill

```
1. Editar el archivo del subskill (skill-creator:skill-creator para cambios grandes)
2. Subir versión en el header del subskill (patch si es fix, minor si es feature)
3. Añadir entrada en el CHANGELOG del propio subskill (si lo tiene)
4. Actualizar la tabla de este archivo (columna "Último sync con ULTRON" = versión ULTRON actual)
5. bash "C:\Users\Rodrigo\.claude\sync.sh"  # opcional — puede no estar disponible en CC
```

## Convención de versiones SemVer

```
X.Y.Z
│ │ └── Patch: fix de bug, corrección de texto, aclaración
│ └──── Minor: feature nueva, nuevo protocolo, nuevo dominio
└────── Major: reestructuración completa del skill (knowledge layer, breaking changes)
```

## Quién escribe el changelog y cuándo

| Cambio | Quién | Cuándo |
|---|---|---|
| Edit a SKILL.md o subskill ULTRON | El propio Claude que lo edita | Al cerrar la sesión, append en `references/changelog.md` |
| Patch fix detectado por Kirkardo | Quien aplica el fix | Misma sesión, append con fuente `Kirkardo X.X/10` |
| Feature nueva (minor) | Quien la introduce | Misma sesión, sección `FEAT:` |
| Major rewrite | Coordinado, con plan previo | En PR / sesión dedicada con review |

**Reglas inamovibles:**
- Changelog es **append-only**. Nunca modificar entradas existentes.
- Cada entry incluye: versión, fecha, motivo (Kirkardo X/10, feature N, fix bug Y), lista de FIX/FEAT con archivo afectado.
- Bump de versión va en la última línea del entry (`BUMP: vX.Y.Z → vX.Y.W`).
- Si el script `consistency-check.py` detecta drift entre frontmatter y version-policy → fix antes de cerrar sesión.

## Checks de consistencia automatizados

`scripts/consistency-check.py` audita:
1. Headers de mode-*.md tienen versión semántica
2. Count de personas alineado entre frontmatter, Layer 1, JERARQUÍA y EXPECTED_PERSONA_COUNT
3. SKILL.md frontmatter alineado con tabla de version-policy
4. routing-matrix.md cubre las 14 personas
5. mode-high.md ROUTING MATRIX cubre las 14 personas
6. /learn no contamina Layer 1 señales
7. **(v7.0):** CLAUDE.md tiene la versión esperada
8. **(v7.0):** Knowledge INDEX.md existe y referencia carpetas reales
