---
name: consolidate-memory
description: "Reflective pass over your memory files — merge duplicates, fix stale facts, prune the index. Activar cuando Rodrigo diga 'consolida memoria', 'limpia el INDEX', 'ordena .ultron', 'fusiona memorias' o cuando pase tiempo sin tocar el sistema."
---

# Memory Consolidation v1.1

Pasada reflexiva sobre los archivos de memoria de ULTRON. Objetivo: que una sesión futura pueda orientarse rápido sin tener que re-preguntar.

## Localización (Rodrigo)

```
C:\Users\Rodrigo\.ultron\
├── INDEX.md
├── projects\
├── global\
├── knowledge\
└── sessions\
```

## Phase 1 — Take stock

- Listar el directorio y leer `INDEX.md`
- Skim de cada archivo. Notar overlaps, stale, thin.

## Phase 2 — Consolidate

**Separar lo durable de lo datado.**
Preferencias, working style, relaciones clave y workflows recurrentes son durables — afina y mantén.
Proyectos específicos, deadlines y one-off tasks son datados — si la fecha pasó o el trabajo terminó, retira el archivo o pliega el takeaway durable a otro.

**Merge overlaps.** Si dos archivos describen lo mismo, combina y queda con la ruta del más rico.

**Fix time references.** Convierte "next week", "this quarter", "by Friday" a fechas absolutas.

**Drop what's easy to re-find.** Si una memoria solo restata algo que puedes pull del calendar/docs/tools on demand, córtala.

## Phase 3 — Tidy the index

Update `INDEX.md` para que se quede bajo 200 líneas y ~25KB. Una línea por entrada, bajo ~150 chars: `- [Title](file.md) — one-line hook`.

- Remover punteros a memorias retiradas
- Acortar líneas con detalle que pertenece al topic file
- Añadir lo que sea nuevamente importante

Termina con un resumen corto: cuántos archivos tocaste y qué cambió.

---

## ARSENAL EXTENDIDO (skills delegables)

| Disparador | Skill a invocar |
|---|---|
| Backup completo de la memoria | `alfred` (PowerShell Compress-Archive) |
| Visualizar evolución temporal de proyectos | `data:create-viz` |
