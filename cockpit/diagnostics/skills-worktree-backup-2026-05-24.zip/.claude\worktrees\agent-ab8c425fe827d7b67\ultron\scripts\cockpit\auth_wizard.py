#!/usr/bin/env python3
"""
ULTRON v10.4 - Auth Wizard (interactive vault profile creation).

Wraps auth-vault.ps1 with a friendlier interactive flow. Asks Rodrigo for
the fields, builds the JSON config blob, invokes auth-vault.ps1 -Action Add.

For free-form NL queries about vault state, use Haiku to parse intent then
dispatch to the right auth-vault command.

Usage:
    auth_wizard.py new <service>      Interactive create new profile
    auth_wizard.py list               Alias to auth-vault list (table)
    auth_wizard.py chat <query...>    NL query/modify (Haiku, dry-run)
    auth_wizard.py chat ... --apply   Commit
"""
from __future__ import annotations

import argparse
import getpass
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

sys.path.insert(0, str(Path(__file__).parent))
from cockpit_base import COCKPIT_DIR  # noqa: E402

ULTRON_DIR = Path.home() / ".claude" / "skills" / "ultron"
AUTH_VAULT_PS1 = ULTRON_DIR / "scripts" / "cockpit" / "auth-vault.ps1"
CHAT_MODEL = "claude-haiku-4-5"
CHAT_TIMEOUT = 60

# Common service templates (extend as needed)
SERVICE_TEMPLATES = {
    "gmail": {
        "fields": ["email", "oauth_client_id", "oauth_client_secret", "refresh_token"],
        "secrets": ["oauth_client_secret", "refresh_token"],
    },
    "supabase": {
        "fields": ["project_ref", "access_token", "anon_key"],
        "secrets": ["access_token", "anon_key"],
    },
    "github": {
        "fields": ["username", "personal_access_token"],
        "secrets": ["personal_access_token"],
    },
    "notion": {
        "fields": ["workspace_label", "internal_integration_token"],
        "secrets": ["internal_integration_token"],
    },
    "openai": {
        "fields": ["account_label", "api_key", "organization_id"],
        "secrets": ["api_key"],
    },
    "anthropic": {
        "fields": ["account_label", "api_key"],
        "secrets": ["api_key"],
    },
    "generic": {
        "fields": [],   # ask user to enter raw JSON
        "secrets": [],
    },
}


def run_auth_vault(action: str, extra_args: list[str]) -> int:
    if not AUTH_VAULT_PS1.exists():
        print(f"[wizard] auth-vault.ps1 not found at {AUTH_VAULT_PS1}", file=sys.stderr)
        return 1
    cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
           "-File", str(AUTH_VAULT_PS1), "-Action", action] + extra_args
    return subprocess.call(cmd)


def cmd_list(_args) -> int:
    return run_auth_vault("List", [])


def cmd_new(args) -> int:
    service = args.service.lower()
    template = SERVICE_TEMPLATES.get(service, SERVICE_TEMPLATES["generic"])

    print()
    print(f"=== ULTRON Auth Wizard — new profile for '{service}' ===")
    print()

    profile_name = input("Profile name (lowercase, no spaces, e.g. 'personal' or 'work'): ").strip()
    if not profile_name:
        print("[wizard] profile name required")
        return 1

    label = input(f"Friendly label (optional, e.g. email or workspace name): ").strip()

    config: dict = {}
    if template["fields"]:
        print()
        print(f"Template fields for '{service}':")
        for field in template["fields"]:
            is_secret = field in template["secrets"]
            prompt = f"  {field}{' (secret, hidden)' if is_secret else ''}: "
            value = (getpass.getpass(prompt) if is_secret else input(prompt)).strip()
            if value:
                config[field] = value
    else:
        print()
        print("Generic mode — paste your full JSON config blob.")
        print("End with empty line:")
        lines = []
        while True:
            line = input()
            if not line:
                break
            lines.append(line)
        try:
            config = json.loads("\n".join(lines))
        except json.JSONDecodeError as e:
            print(f"[wizard] Invalid JSON: {e}")
            return 1

    print()
    print("=== Profile preview ===")
    redacted = {k: ("***" if k in template["secrets"] else v)
                 for k, v in config.items()}
    print(f"  Service:     {service}")
    print(f"  Profile:     {profile_name}")
    print(f"  Label:       {label or '(none)'}")
    print(f"  Config:      {json.dumps(redacted, indent=2)}")
    print()

    confirm = input("Save to vault? (yes/no): ").strip().lower()
    if confirm not in ("y", "yes", "si"):
        print("[wizard] Aborted.")
        return 0

    # Write config to temp file (auth-vault.ps1 expects -ConfigPath)
    tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".json",
                                       delete=False, encoding="utf-8")
    try:
        json.dump(config, tmp, indent=2)
        tmp.close()
        extra = ["-Service", service, "-ProfileName", profile_name,
                 "-ConfigPath", tmp.name]
        if label:
            extra += ["-Label", label]
        rc = run_auth_vault("Add", extra)
        return rc
    finally:
        try:
            Path(tmp.name).unlink()
        except OSError:
            pass


def cmd_chat(args) -> int:
    """Free-form NL → Haiku parses intent → dispatches to auth-vault action.
    Dry-run mode shows what would be done; --apply executes."""
    claude_bin = shutil.which("claude")
    if not claude_bin:
        print("[wizard] claude CLI not found", file=sys.stderr)
        return 1

    system = (
        "Eres parser de intent para auth vault. Acciones disponibles: "
        "list (mostrar todos los profiles), get <service> <profile> "
        "(mostrar uno), switch <service> <profile> (cambiar el activo), "
        "remove <service> <profile> (borrar). Si la pregunta es informativa, "
        "elige 'list' o 'get'. Si pide cambio destructivo, elige la acción "
        "correspondiente. Output SOLO JSON: "
        "{\"action\":\"...\",\"args\":{\"service\":\"x\",\"profile\":\"y\"}, "
        "\"explanation\":\"...\"}. Si no estás seguro, action=\"list\"."
    )
    user = f"Query: {args.query}"

    cmd = [claude_bin, "--print", "--dangerously-skip-permissions",
           "--model", CHAT_MODEL,
           "--append-system-prompt", system, user]
    print(f"[wizard] Parsing intent via {CHAT_MODEL}...")
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                            timeout=CHAT_TIMEOUT, encoding="utf-8")
        if r.returncode != 0:
            print(f"[wizard] claude failed exit={r.returncode}", file=sys.stderr)
            return 1
        response = (r.stdout or "").strip()
    except subprocess.TimeoutExpired:
        print(f"[wizard] timeout after {CHAT_TIMEOUT}s", file=sys.stderr)
        return 1

    if response.startswith("```"):
        lines = response.split("\n")
        if lines[-1].strip().startswith("```"):
            lines = lines[1:-1]
        else:
            lines = lines[1:]
        response = "\n".join(lines)
    try:
        intent = json.loads(response)
    except json.JSONDecodeError as e:
        print(f"[wizard] intent parse failed: {e}", file=sys.stderr)
        print(f"[wizard] raw: {response[:300]}", file=sys.stderr)
        return 1

    action = intent.get("action", "list")
    explanation = intent.get("explanation", "")
    iargs = intent.get("args") or {}

    print()
    print(f"=== Intent ===")
    print(f"  Action: {action}")
    print(f"  Explanation: {explanation}")
    if iargs:
        print(f"  Args: {iargs}")
    print()

    if not args.apply:
        print("[wizard] Dry-run — pass --apply to execute.")
        return 0

    action_map = {"list": "List", "get": "Get",
                  "switch": "Switch", "remove": "Remove"}
    ps_action = action_map.get(action.lower())
    if not ps_action:
        print(f"[wizard] unsupported action: {action}")
        return 1
    extra = []
    if iargs.get("service"):
        extra += ["-Service", iargs["service"]]
    if iargs.get("profile"):
        extra += ["-ProfileName", iargs["profile"]]
    return run_auth_vault(ps_action, extra)


def main():
    p = argparse.ArgumentParser(description="ULTRON Auth Wizard")
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("new")
    sp.add_argument("service")
    sp.set_defaults(func=cmd_new)

    sub.add_parser("list").set_defaults(func=cmd_list)

    sp = sub.add_parser("chat")
    sp.add_argument("query", nargs="+")
    sp.add_argument("--apply", action="store_true")
    sp.set_defaults(func=lambda a: (setattr(a, "query", " ".join(a.query)),
                                     cmd_chat(a))[1])

    args = p.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
