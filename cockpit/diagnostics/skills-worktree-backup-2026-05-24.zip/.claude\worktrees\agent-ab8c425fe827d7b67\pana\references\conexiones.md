# PANA — Conexiones y Configuración

## Gmail
- **Cuenta:** rodrixfc17@gmail.com
- **Zona horaria:** Europe/Madrid
- **Herramientas:** `gmail_search_messages`, `gmail_read_message`, `gmail_read_thread`, `gmail_create_draft`

---

## Google Calendar
- **Cuenta:** rodrixfc17@gmail.com
- **Zona horaria:** Europe/Madrid
- **Herramientas:** `gcal_list_events`, `gcal_create_event`, `gcal_update_event`, `gcal_delete_event`
- **Calendarios relevantes:**
  - Principal (eventos personales)
  - Entregas académicas (U-tad)
  - Recordatorios financieros (fondos de ahorro)

---

## Notion
- **Workspace:** Personal de Rodrigo
- **MCP Tools:** `notion-fetch`, `notion-create-pages`, `notion-update-page`, `notion-search`

### Bases de datos clave

| Base de Datos | ID | Uso |
|---|---|---|
| 💳 Movimientos | `2f6ae1a3292f40bfa2305a670f0647de` | Gastos e ingresos bancarios |
| 🏦 Fondos de Ahorro | `679c2d25a5424c33ac00f9fb6c8ce994` | Fondos de ahorro y objetivos |
| 📊 Estadísticas Mensuales | `d5abd0923292441d851a9a428b8f6b13` | Resúmenes financieros mensuales |
| ⚙️ Config Gestor | `33b4c2f25c36817ebb40c40ba81a24a0` | Límites de gasto y reglas |
| 📔 Diario | *(buscar con notion-search "Diario")* | Entradas diarias de cierre |
| ✅ Tareas | *(buscar con notion-search "Tareas")* | Tareas pendientes y completadas |

---

## Blackboard — U-tad
- **URL base:** `https://u-tad.blackboard.com`
- **URL calendario:** `https://u-tad.blackboard.com/ultra/calendar`
- **URL stream:** `https://u-tad.blackboard.com/ultra/stream`
- **URL cursos:** `https://u-tad.blackboard.com/ultra/course`
- **Herramientas:** Chrome MCP (`Claude in Chrome:navigate` + `Claude in Chrome:get_page_text`)

### Protocolo Blackboard
```
1. Claude in Chrome:tabs_context_mcp → obtener tabId activo
2. Claude in Chrome:navigate → https://u-tad.blackboard.com/ultra/calendar
3. Claude in Chrome:get_page_text → extraer entregas y fechas
4. Comparar con Google Calendar → eliminar antiguos, añadir nuevos, evitar duplicados
```

> ⚠️ Requiere que Rodrigo esté autenticado en Blackboard en Chrome.
> Si no hay sesión activa: indicar al usuario que se loguee primero.

---

## Spotify
- **Herramientas:** `mcp__Spotify__AppleScript___spotify_*`
- **Playlist focus principal:** buscar con `spotify_play` + search query

### Comandos frecuentes
| Comando | Herramienta |
|---|---|
| Reproducir focus music | `spotify_play` con query "lofi focus" |
| Pausa | `spotify_pause` |
| Siguiente | `spotify_next_track` |
| Track actual | `spotify_get_current_track` |
| Volumen | `spotify_set_volume` |

---

## Scheduled Tasks
- **Herramienta:** `mcp__scheduled-tasks__create_scheduled_task`
- **Briefing diario:** 08:00 Europe/Madrid → "modo mañana"
- **Resumen financiero:** día 1 de cada mes 09:00 → "Dame el resumen del mes"

---

## Windows / Archivos
- **Desktop Commander:** leer/escribir archivos locales
- **Windows-MCP:** operaciones del sistema (PowerShell, procesos, screenshots)
- **Rutas clave de Rodrigo:**
  ```
  C:\Users\Rodrigo\CARRERA\         → Proyectos de carrera U-tad
  C:\Users\Rodrigo\Documents\       → Proyectos personales
  C:\Users\Rodrigo\.claude\skills\  → Skills instaladas
  C:\Users\Rodrigo\Desktop\         → Escritorio
  ```
