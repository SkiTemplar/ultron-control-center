# sync.sh — Skills Sync

Sincroniza skills entre Claude Code (`~/.claude/skills/`) y Claude Desktop.

## Uso

```bash
# Desde Git Bash, en ~/.claude/skills/
bash sync.sh                        # Sincroniza todas las skills comunes CC→Desktop
bash sync.sh --cc-to-desktop        # Igual que el default
bash sync.sh --desktop-to-cc ultron # Sincroniza una skill específica Desktop→CC
bash sync.sh --status               # Muestra estado de sincronización
bash sync.sh --dry-run              # Preview sin hacer cambios (combinable con cualquier modo)
bash sync.sh --dry-run --cc-to-desktop
```

## Skills sincronizadas (CC ↔ Desktop)

`ultron`, `terry-davis`, `don-claudio`, `mike-tyson`, `einstein`, `pana`, `alfred`,
`manolo-lama`, `repo-evaluator`, `tio-gilito`, `jordan-belfort`, `profesor-fisica`,
`consolidate-memory`, `ui-ux-pro-max`

## NO sincronizadas

| Motivo | Skills |
|--------|--------|
| Solo Desktop (Layer 3 nativas) | `canvas-design`, `docx`, `pdf`, `pptx`, `schedule`, `setup-cowork`, `web-artifacts-builder`, `xlsx`, `the-creator`, `macpollo` |
| Equivalencias distintas | CC `mcp-builder` ↔ Desktop `macpollo` / CC `skill-creator` ↔ Desktop `the-creator` |

## Output

- `✓ skill synced` — OK
- `✗ skill MISSING` — no existe en origen
- `~ skill (CC=X, Desktop=Y)` — desincronizada (distinto line count)
