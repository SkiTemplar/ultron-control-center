#!/usr/bin/env bash
# sync.sh — Sync skills between Claude Code and Claude Desktop

CC_DIR="$HOME/.claude/skills"
DESKTOP_DIR="/c/Users/Rodrigo/AppData/Local/Packages/Claude_pzs8sxrjxfjjc/LocalCache/Roaming/Claude/local-agent-mode-sessions/skills-plugin/5a8a6f88-ca6e-470a-a9b5-a59f763a054e/22430ac8-c38b-4266-bf6a-f064dd43b738/skills"

COMMON_SKILLS=(ultron terry-davis don-claudio mike-tyson einstein pana alfred manolo-lama repo-evaluator tio-gilito jordan-belfort profesor-fisica consolidate-memory ui-ux-pro-max)

DESKTOP_NATIVE=(canvas-design docx pdf pptx schedule setup-cowork web-artifacts-builder xlsx the-creator macpollo)

DRY_RUN=false
MODE="cc-to-desktop"
SKILL_NAME=""

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

usage() {
  echo "Usage: bash sync.sh [OPTIONS]"
  echo ""
  echo "Options:"
  echo "  --cc-to-desktop          Sync all common skills CC→Desktop (default)"
  echo "  --desktop-to-cc NAME     Sync a specific skill Desktop→CC"
  echo "  --status                 Show sync status for all common skills"
  echo "  --dry-run                Show what would be done without doing it"
  echo "  --help                   Show this help"
  exit 0
}

is_native() {
  local skill="$1"
  for n in "${DESKTOP_NATIVE[@]}"; do
    [[ "$n" == "$skill" ]] && return 0
  done
  return 1
}

count_lines() {
  local dir="$1"
  wc -l < "$dir/SKILL.md" 2>/dev/null || echo "0"
}

sync_skill() {
  local src="$1"
  local dst="$2"
  local skill="$3"

  local src_path="$src/$skill"
  local dst_path="$dst/$skill"

  if [[ ! -d "$src_path" ]]; then
    echo -e "${RED}✗ $skill MISSING in source${NC}"
    return 1
  fi

  if $DRY_RUN; then
    echo -e "${YELLOW}[dry-run] would cp: $src_path → $dst_path${NC}"
    return 0
  fi

  rm -rf "$dst_path"
  cp -r "$src_path" "$dst_path"
  if [[ $? -eq 0 ]]; then
    echo -e "${GREEN}✓ $skill synced${NC}"
  else
    echo -e "${RED}✗ $skill SYNC FAILED${NC}"
    return 1
  fi
}

show_status() {
  echo -e "${CYAN}=== Skill Sync Status ===${NC}"
  echo ""
  for skill in "${COMMON_SKILLS[@]}"; do
    local cc_path="$CC_DIR/$skill"
    local dt_path="$DESKTOP_DIR/$skill"

    local cc_exists=false
    local dt_exists=false
    [[ -d "$cc_path" ]] && cc_exists=true
    [[ -d "$dt_path" ]] && dt_exists=true

    if $cc_exists && $dt_exists; then
      local cc_lines
      local dt_lines
      cc_lines=$(count_lines "$cc_path")
      dt_lines=$(count_lines "$dt_path")
      if [[ "$cc_lines" == "$dt_lines" ]]; then
        echo -e "${GREEN}✓ $skill (in sync, ~${cc_lines} lines)${NC}"
      else
        echo -e "${YELLOW}~ $skill (CC=${cc_lines} lines, Desktop=${dt_lines} lines — DIFF)${NC}"
      fi
    elif $cc_exists && ! $dt_exists; then
      echo -e "${YELLOW}→ $skill (CC only, not in Desktop)${NC}"
    elif ! $cc_exists && $dt_exists; then
      echo -e "${YELLOW}← $skill (Desktop only, not in CC)${NC}"
    else
      echo -e "${RED}✗ $skill (MISSING everywhere)${NC}"
    fi
  done

  echo ""
  echo -e "${CYAN}=== Desktop-native (not synced) ===${NC}"
  for skill in "${DESKTOP_NATIVE[@]}"; do
    echo -e "  - $skill"
  done

  echo ""
  echo -e "${CYAN}=== Special equivalences (manual sync only) ===${NC}"
  echo -e "  CC mcp-builder ↔ Desktop macpollo"
  echo -e "  CC skill-creator ↔ Desktop the-creator"
}

# Parse args
while [[ $# -gt 0 ]]; do
  case "$1" in
    --cc-to-desktop) MODE="cc-to-desktop"; shift ;;
    --desktop-to-cc)
      MODE="desktop-to-cc"
      SKILL_NAME="$2"
      shift 2
      ;;
    --status) MODE="status"; shift ;;
    --dry-run) DRY_RUN=true; shift ;;
    --help) usage ;;
    *) echo "Unknown option: $1"; usage ;;
  esac
done

# Validate paths
if [[ ! -d "$CC_DIR" ]]; then
  echo -e "${RED}ERROR: CC skills dir not found: $CC_DIR${NC}"
  exit 1
fi
if [[ ! -d "$DESKTOP_DIR" ]]; then
  echo -e "${RED}ERROR: Desktop skills dir not found: $DESKTOP_DIR${NC}"
  exit 1
fi

case "$MODE" in
  status)
    show_status
    ;;

  cc-to-desktop)
    $DRY_RUN && echo -e "${YELLOW}[dry-run mode — no changes will be made]${NC}\n"
    echo -e "${CYAN}Syncing CC → Desktop...${NC}"
    for skill in "${COMMON_SKILLS[@]}"; do
      sync_skill "$CC_DIR" "$DESKTOP_DIR" "$skill"
    done
    echo -e "\n${CYAN}Done.${NC}"
    ;;

  desktop-to-cc)
    if [[ -z "$SKILL_NAME" ]]; then
      echo -e "${RED}ERROR: --desktop-to-cc requires a skill name${NC}"
      exit 1
    fi
    if is_native "$SKILL_NAME"; then
      echo -e "${RED}ERROR: '$SKILL_NAME' is a Desktop-native skill and should not be synced to CC${NC}"
      exit 1
    fi
    $DRY_RUN && echo -e "${YELLOW}[dry-run mode — no changes will be made]${NC}\n"
    echo -e "${CYAN}Syncing Desktop → CC: $SKILL_NAME${NC}"
    sync_skill "$DESKTOP_DIR" "$CC_DIR" "$SKILL_NAME"
    echo -e "\n${CYAN}Done.${NC}"
    ;;
esac
