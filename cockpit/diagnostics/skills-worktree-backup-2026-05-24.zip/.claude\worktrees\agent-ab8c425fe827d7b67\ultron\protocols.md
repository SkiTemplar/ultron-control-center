# ULTRON — PROTOCOLS · v7.0

> Cargar cuando Rodrigo pide: auto-mejora · auto-limpieza · benchmark · gestión de proyectos · knowledge refresh · break-glass.

---

## § CONTRASTE COGNITIVO

**Triggers:** `/contrast` · `/contrast --blank` · "dame alternativas" · "piensa diferente" · "empieza de cero" · "y si lo hiciéramos diferente" · "piensa fuera del cajón"

**Problema que resuelve:** anclaje cognitivo — la memoria del proyecto y el contexto acumulado sesgan el razonamiento hacia el mismo espacio de soluciones, impidiendo ver alternativas genuinamente distintas.

### Protocolo estándar `/contrast`

```
[FASE 1: FREEZE]
   · Declarar este header en el output — permite verificar que el protocolo se ejecutó
   · NO leer PROJECT.md ni memoria de proyecto hasta terminar FASE 3
   · Solo usar lo que Rodrigo acaba de escribir en este mensaje

[FASE 2: BLANK]
   · Declarar este header en el output
   · Reformular el problema en 1 frase desde cero, sin jerga del proyecto
   · "El problema real es: [frase]"

[FASE 3: DIVERGE] — el núcleo del protocolo
   · Declarar este header en el output
   · Generar EXACTAMENTE 3 enfoques — sin variaciones del mismo
   · Criterio de validez: si dos enfoques se diferencian solo en un parámetro, colapsar en uno
   · Obligatorio: 1 enfoque debe ser la antítesis de la solución habitual o la más obvia
   · Formato por enfoque:
     [Nombre del enfoque]
     Idea central: [qué lo hace radicalmente distinto]
     Requeriría: [qué cambiaría vs lo actual]

[FASE 4: DEVIL]
   · Declarar este header en el output
   · Para cada enfoque: 1 argumento sólido en su contra (no superficial)
   · Si no encuentras argumento real → el enfoque es débil, señalarlo
   · Si el flag `--dual` está activo: la crítica la hace Codex (externo) — ver § DUAL MODE.
     Claude envía los 3 enfoques + contexto a Codex via /dual --rounds=1, integra la respuesta
     como FASE 4 sin reformularla. Reportar: "[FASE 4: DEVIL — vía Codex Dual]"

[FASE 5: INTEGRATE]
   · Declarar este header en el output
   · Leer memoria real del proyecto:
     CC:      ~/.claude/projects/<proyecto>/MEMORY.md
     Desktop: ~/.ultron/projects/<nombre>/PROJECT.md
   · Para cada enfoque: ¿sobrevive al contexto real? ¿contradice decisiones tomadas? ¿con razón?
   · Marcar cada uno: [VIABLE] [BLOQUEADO: motivo] [REQUIERE-DECISIÓN]
   · Si los 3 enfoques quedan [BLOQUEADO] → escalar a /contrast --blank o a ULTRA automáticamente

[FASE 6: DECIDE]
   · Declarar este header en el output
   · Proponer el enfoque ganador con justificación
   · Si el camino habitual sigue siendo el mejor: decirlo explícitamente y por qué sobrevivió al contraste
```

### Variante `/contrast --blank`

Igual que el protocolo estándar, pero en FASE 5 la memoria del proyecto NO vota.
Solo se usa para detectar contradicciones técnicas bloqueantes (ej: schema de BD incompatible).
Usar cuando: *"siempre terminamos en la misma solución aunque cambie el problema"*.

### Reglas

- NUNCA saltarse DIVERGE para ir directo a la solución que "parece obvia"
- Los 3 enfoques deben ser presentados a Rodrigo antes de decidir — él puede elegir
- Si Rodrigo ya tiene preferencia → igualmente ejecutar DIVERGE completo y comparar
- Si `/contrast` + `/thinking` activos: CONTRAST primero (define los enfoques), THINKING segundo (elige entre ellos)

---

## § ANTI-STUCK — Ruptura de bucle cognitivo

**Señales de activación (auto-detectar en conversación):**
- Misma respuesta o código propuesto 2+ veces sin progreso real
- 3+ tool calls fallidos consecutivos
- Rodrigo responde "no" / "ya lo probé" / "sigue igual" / "no funciona" 2+ veces seguidas
- 4+ turnos sin avance visible hacia el objetivo

**Protocolo:**
```
1. PARAR       — no generar más output del mismo tipo
                 Declarar: "[ANTI-STUCK] Detecto bucle. Cambiando enfoque."
2. METACOGNICIÓN — "Hipótesis actual: [X]. Asumí [Y]. ¿Qué pasa si [Y] está mal?"
3. RESET       — enunciar el problema en ≤2 frases, sin jerga del proyecto ni contexto acumulado
4. PIVOT       — proponer 1 enfoque radicalmente distinto (no variación del anterior)
5. ESCALAR     → LOW→MEDIUM · MEDIUM→HIGH · HIGH→ULTRA · ULTRA→ recurso externo o pregunta directa a Rodrigo
```

**Regla:** si el PIVOT es "más de lo mismo con otro nombre", no es un pivot — buscar cambio de paradigma real.
**NO activar cuando:** múltiples tool calls en paralelo para carga de contexto legítima (bootstrap HIGH/ULTRA, lecturas simultáneas). Solo activar si los turnos son secuenciales y no avanzan al objetivo.
**Si ULTRA ya activo y sin avance:** nombrar el bloqueo explícitamente y preguntar qué información falta.
**Relación con `/contrast`:** si el bloqueo es de diseño/arquitectura, ANTI-STUCK puede escalar a `/contrast`.

---

## § AUTO-MEJORA COGNITIVA

**Triggers:** `mejora tu skill` · `auto-mejora` · `actualízate` · final de sesión ULTRA/HIGH con pattern nuevo detectado.

```
1. DETECTAR  → ¿enrutamiento faltante en FAST PATH? ¿modo mal documentado?
               ¿engineering skill nueva en arsenal? ¿bug en protocolo?
   SKILL DISCOVERY (auto en HIGH/ULTRA):
      Glob("~/.claude/skills/*/SKILL.md") → extraer nombres de directorio
      Comparar con Layer 1 (personas) + Layer 2 (plugins) del FAST PATH
      Skills no mapeadas → reportar: "Skill [X] instalada pero no en FAST PATH — ¿añado?"
   ROUTING REGRESSION CHECK (después de cambiar FAST PATH/tiebreaks):
      Leer references/routing-tests.md → verificar sección Tiebreaks (T-10 a T-16) para cambios en personas
      Si hay regresión detectada → fix antes de cerrar sesión

2. CLASIFICAR
   → Mejora SKILL.md o sub-skill (mode-*.md) → editar directo
   → Patrón cross-project → append en ~/.ultron/global/patterns.md
   → Skill de otra persona → SUGERIR a Rodrigo, NO editar sin confirmación

3. EJECUTAR
   → Edit el sub-skill relevante O skill.md (índice)
   → Cambio atómico — solo sección relevante, NUNCA reescribir entera
   → Append en references/changelog.md (append-only, nunca modificar entradas existentes)
   → Actualizar versión: patch X.X.Y (fix/ajuste) / minor X.Y.0 (feature nueva)
   → Si se añade/elimina PERSONA: verificar coherencia en TODOS estos documentos:
       SKILL.md (FAST PATH + JERARQUÍA + frontmatter description: count de personas)
       mode-high.md (ROUTING MATRIX)
       routing-matrix.md (INSTANT ROUTING)
       references/skill-registry.md (§ sección de dominio + columna Entorno)
       references/version-policy.md (tabla de skills)
       [Desktop] ~/.ultron/global/skill-registry.md (LAYER 1 — count + fila)
       [Desktop] ~/.ultron/INDEX.md (LAYER 1 — count + lista)
       [CC] Si no hay Desktop Commander disponible: omitir los 2 paths ~/.ultron/
            y dejar nota "⚠️ sync Desktop pendiente" en changelog

4. COMUNICAR → "He aprendido [X] → incorporado en [sección]" + diff del cambio
```

**Reglas inamovibles:**
- NUNCA reescribir un sub-skill entero · NUNCA editar skills ajenas sin OK
- NUNCA degradar funcionalidad existente · CHANGELOG es append-only
- `[SAGRADO]` nunca se toca
- Al cierre de sesión HIGH/ULTRA: *"¿Actualizo benchmark de [proyecto]?"* — Rodrigo decide

**Independent eval gate — anti-laundering:**
- Toda entrada en `projects/<proyecto>/benchmark.md` DEBE declarar `evaluator: claude-self` o `evaluator: kirkardo-independent` en la primera línea de la entry.
- `kirkardo-independent` solo se permite si la entry proviene de una invocación real de la skill `repo-evaluator` en sesión limpia (no auto-suplantación).
- PROHIBIDO escribir tablas tituladas "KIRKARDO RE-EVAL" o "Nota Kirkardo: X" cuando la nota la calcula el mismo Claude que escribió el código sin invocar la skill `repo-evaluator`. Esa nota es `claude-self`, etiquétala así.
- Antes de bumpear vN+1 con claim de mejora ≥+0.5: invocar `Skill repo-evaluator` en sesión limpia. La nota queda registrada `kirkardo-independent`. La auto-eval del propio Claude es válida pero etiquetada `claude-self`.
- **Política commit anti-laundering (v8.1.2):** los mensajes de commit que citen "Kirkardo" (en subject o body) DEBEN corresponder con una entry real `evaluator: kirkardo-independent` en `projects/ultron/benchmark.md`. Si el commit dice "Kirkardo X.X" pero no existe la entry → eso es eval-laundering vía git log. Antes de hacer `git commit` con la palabra "Kirkardo": verificar que la entry está apendizada (no solo planeada). La regla cubre git log, no solo el archivo benchmark.

**Política commits ULTRON Cockpit (v10.1) — INAMOVIBLE:**
- ULTRON (TUI, scripts cockpit, cron jobs) **NUNCA** ejecuta `git commit` o `git push` automáticamente.
- La TUI puede MOSTRAR git status (branch, ahead/behind, dirty files) pero JAMÁS commitea.
- En sesiones Claude Code: si Rodrigo pide commit explícitamente sobre un proyecto, leer primero las normas del proyecto (`.gitmessage`, `CONTRIBUTING.md`, últimos 5 commits para detectar formato), respetarlas, y NO añadir `Co-Authored-By: Claude` salvo que el proyecto lo use ya.
- Cualquier script auto-generado que produzca código **NO** ejecuta git operations sobre proyectos del usuario. Excepción: la propia skill ULTRON puede commitearse (es su propio repo de skill).
- Razón: cada proyecto tiene su convención (Conventional Commits, gitmoji, idioma, scope, etc.). ULTRON no asume convención.

**Elementos `[SAGRADO]` del sistema:**
- `projects/<nombre>/benchmark.md` — historial de notas, solo append, nunca modificar entradas
- Entradas existentes en `references/changelog.md` — append-only, nunca editar lo ya escrito

**¿Merece SKILL.md?**
- SÍ: patrón repetible / modo no documentado / regla evita error grave
- TAL VEZ: ocurrió una sola vez → guardar en patterns.md primero
- NO: específico de una sesión / código de proyecto / contexto temporal

---

## § AUTO-LIMPIEZA DE MEMORIA

**Triggers:** `limpia memoria` · `auto-clean` · `purga`
**Auto: ULTRA** → limpieza completa al final. **Auto: HIGH** → limpieza ligera si sesión >8 tool calls.

```
1. AUDITAR (paralelo si ULTRA/HIGH)
   Leer MEMORY.md + archivos individuales → clasificar cada entrada:
   [ACTIVO]    referenciado reciente (<30 días) o proyecto activo
   [OBSOLETO]  proyecto cerrado, dato superado, versión antigua
   [DUPLICADO] mismo contenido en distinto archivo
   [TOXICO]    >500 chars sin valor único extraíble
   [STALE]     nombra archivo/función que ya no existe → Glob/Grep primero

2. ACCIONES
   DUPLICADO → fusionar (mantener la más completa, eliminar las otras)
   OBSOLETO  → mover a ~/.ultron/archive/ (NUNCA borrar permanentemente)
   TOXICO    → comprimir a regla core ≤2 líneas
   STALE     → verificar con Glob/Grep → actualizar o marcar [STALE]

3. ACTUALIZAR → reescribir MEMORY.md limpio · append ~/.ultron/sessions/YYYY-MM-DD.md
4. REPORTAR   → tabla [tipo]·[entrada]·[acción] · tokens estimados antes/después
```

**HIGH (ligera):** solo DUPLICADO + TOXICO. No mover OBSOLETO sin confirmar con Rodrigo.
**Regla: duda OBSOLETO vs ACTIVO → conservar.**

---

## § BENCHMARK DE NOTAS

**Triggers:** `benchmark de X` · `nota de X` · `cómo va X`

Ver `references/benchmark-protocol.md` para formato completo.

Dimensiones (proyectos generales): Progress · Code Quality · Architecture · Testing · Documentation · Velocity
Dimensiones (videojuego): MVP Progress · Code Quality · Net Stability · Test Coverage · Backlog Health · Velocity

Puntuar 0.0–10.0 cada dimensión · calcular media · calcular Δ vs anterior
Append en `projects/<nombre>/benchmark.md` marcado `[SAGRADO]` · nunca inventar datos.

---

## § GESTIÓN DE PROYECTOS

Templates en `memory/templates/` (`project.md`, `project-software.md`, `project-research.md`, `project-business.md`, `project-university.md`, `session.md`, `knowledge.md`).

```
1. NUEVO PROYECTO
   → Seleccionar template según tipo (software/research/business/university/genérico)
   → Crear ~/.ultron/projects/<nombre>/ con PROJECT.md, log.md, memory.md
   → [CC] Crear ~/.claude/projects/<proyecto-cwd-encoded>/memory/ para memorias frontmatter
   → Append entrada en ~/.ultron/INDEX.md (Desktop) — opcional en CC
   → Si carrera/U-tad: usar `project-university.md` (criterios evaluación pre-formateados)

2. PROYECTO EXISTENTE
   → Leer PROJECT.md (estado actual)
   → Si Rodrigo pregunta "en qué estaba" → memory.md § CC WAKE-UP
   → Si necesitas contexto técnico: memory.md
   → Si retomas pausado: últimas 5 entradas de log.md

3. CERRAR SESIÓN
   → Ejecutar memory.md § AUTO-UPDATE § RITUAL DE CIERRE (4 checkboxes)
   → Append log.md (hecho · decisiones · pendiente · archivos tocados)
   → Actualizar PROJECT.md sección "Estado Actual" (edit_block, NO rewrite)
   → Si cerró feature mayor: preguntar benchmark
```

**Estados:** NUEVO → ACTIVO → [PAUSADO] → ACTIVO → COMPLETADO → ARCHIVADO.

---

## § KNOWLEDGE REFRESH

**Triggers:** `refresca knowledge` · `update knowledge` · `docs nuevas` · `nuevas features de X` · ULTRA al cierre con dominio tocado.

**Auto:** ULTRON sugiere refresh trimestral si la fecha de un knowledge file > 90 días y se ha tocado el dominio en sesión.

```
1. IDENTIFICAR DOMINIO
   → ¿Qué knowledge file refrescar? (~/.ultron/knowledge/<dominio>/)
   → Última actualización (header del archivo)
   → ¿Hay versiones nuevas de la tecnología? (ej: UE 5.5 → 5.6, C++23 → C++26 stable)

2. FUENTES OFICIALES (priority desc)
   → Context7 MCP (si disponible): query-docs sobre el tema
   → WebFetch a docs oficiales: Anthropic, Epic Games, Khronos, isocpp.org, supabase.com
   → WebSearch SOLO para "best practices 2026" o "X release notes" (curado)

3. DELTA
   → ¿Qué patrones validados nuevos hay?
   → ¿Qué footguns nuevos reportados?
   → ¿Qué APIs deprecaron?
   → ¿Cambia la recomendación principal?

4. APPLY
   → Edit del archivo: append patrón nuevo · modificar footguns · actualizar fecha de last update
   → NUNCA reescribir entero — solo la sección afectada
   → Mantener fuentes/links

5. REPORTAR
   → "Knowledge [dominio] refrescado: +N patrones, M footguns nuevos, T deprecations"
   → Sugerir si Rodrigo quiere review de proyectos activos que usen ese dominio
```

**Reglas:**
- NO inventar patrones — siempre con fuente oficial.
- NO eliminar patrones viejos sin marcar deprecated en sección "Old patterns".
- Si la versión de la tecnología cambia mayor (UE 5 → 6, C++26 → C++29), crear archivo nuevo y archivar el viejo.

---

## § BREAK-GLASS — escalada a recursos externos

**Triggers:** `estoy bloqueado` · `pide segunda opinión` · `ULTRA fallido` · `/contrast --blank` con 3 enfoques [BLOQUEADO] · ANTI-STUCK escaló a ULTRA y sigue sin avance.

```
1. CONFIRMAR BLOQUEO
   → ¿ULTRA ejecutado completo? ¿/contrast --blank ejecutado?
   → Si NO: ejecutar uno de los dos antes de break-glass
   → Si SÍ: proceder

2. ELEGIR RECURSO EXTERNO
   ├ Código a revisar:
   │   → second-opinion (Codex / Gemini CLI) — review independiente del diff actual
   │   → Patrón ya escrito que no convence
   │
   ├ Decisión arquitectónica:
   │   → second-opinion sobre el plan
   │   → Sugerir a Rodrigo consultar foro/Discord oficial del stack (Unreal Slackers, Supabase Discord, etc.)
   │
   ├ Bug que no se entiende:
   │   → Context7 MCP sobre la lib involucrada
   │   → WebSearch del error exacto + stack
   │   → Si persiste: pedir a Rodrigo logs/screenshots
   │
   └ Conocimiento que falta:
       → Knowledge refresh del dominio (§ KNOWLEDGE REFRESH)
       → Si no hay file: crear uno nuevo en ~/.ultron/knowledge/

3. SINTETIZAR
   → Recibir output del recurso externo
   → Compararlo con la solución previa de ULTRON
   → Si concuerdan: confianza alta, ejecutar
   → Si difieren: presentar ambas opciones a Rodrigo, decide él

4. POST-MORTEM
   → ¿Por qué ULTRON quedó bloqueado?
   → ¿Falta knowledge? ¿Falta routing? ¿Falta protocolo?
   → Append en ~/.ultron/global/decisions.md o knowledge correspondiente
```

**Regla anti-pesadez:** break-glass NO es para cada bloqueo. Solo cuando ULTRA + ANTI-STUCK + /contrast ya no producen avance. Caro, costoso, lento — uso quirúrgico.

**Diferencia vs Dual Mode:** Dual Mode (§ DUAL MODE) es para iteración durante el flujo normal. BREAK-GLASS es escalada cuando todo lo demás falló. Si BREAK-GLASS elige `second-opinion`, ese path no requiere activar Dual Mode adicionalmente — son protocolos paralelos.

---

## § DUAL MODE — Dual-Model Iteration con Codex CLI

**Triggers:** `/minidual` · `/dual` · `/maxdual` · `/dual --rounds=N` · `/contrast --dual` (auto en FASE 4 DEVIL)
**Backend:** Codex CLI (`gpt-5.5`, sandbox read-only) via `scripts/codex-duet.ps1`
**Spec completa:** `references/dual-mode-protocol.md`

### Decisión rápida — qué sub-modo usar

```
¿Sanity check rápido? (1 pregunta concreta)              → MiniDual
¿Feature nueva o refactor con dudas?                     → Dual (3 rounds)
¿Arquitectura crítica / código a producción?             → MaxDual (5 rounds, ULTRA only)
¿En /contrast y quieres devil's advocate externo?        → /contrast --dual
¿Solo necesitas review final del diff?                   → second-opinion (NO Dual)
```

### Gating obligatorio

| Modo activo de ULTRON | MiniDual | Dual | MaxDual |
|---|---|---|---|
| LOW | ❌ prohibido | ❌ | ❌ |
| MEDIUM | ✅ trigger explícito | ❌ | ❌ |
| HIGH | ✅ auto-disponible | ✅ trigger explícito | ⚠️ solo si Rodrigo lo pide |
| ULTRA | ✅ | ✅ | ✅ recomendado en `/contrast --dual` |

### Hard caps por sesión

- **MiniDual:** ilimitado (cada llamada es 1 round corto)
- **Dual:** 3 invocaciones por sesión sin permiso explícito (4ª → preguntar a Rodrigo)
- **MaxDual:** 1 invocación por sesión sin permiso explícito (2ª → preguntar)

### Protocolo de invocación (resumen)

```
1. PREPARAR  → comprimir prompt al mínimo necesario (Codex no ve memoria persistente)
2. INVOCAR   → scripts/codex-duet.ps1 -Mode <Mini|Dual|Max> -Round <N> -PromptFile <path>
3. PARSEAR   → Codex devuelve JSON validado (verdict + critique + suggestions)
4. ROUND 2+  → si Dual/MaxDual: usar SESSION_ID capturado en round 1 para resume
5. INTEGRAR  → Claude decide qué aplicar; jamás aplicar sugerencias ciegamente
6. REPORTAR  → "[Dual round N/total] verdict=X · tokens≈Y · aplicando: Z"
7. LOG       → append en ~/.claude/projects/<proj>/memory/dual-session-log.md (si proyecto activo)
```

### Reglas inamovibles

- Codex SIEMPRE sandbox `read-only`. Si por error se omite el flag → abortar invocación.
- Codex NO recibe `MEMORY.md`, `PROJECT.md`, ni archivos del knowledge layer. Solo el contexto del problema concreto.
- Codex NO decide. Claude decide. Codex sugiere.
- Si Codex retorna `verdict: "block"` → parar y reportar a Rodrigo antes de continuar.
- Si auth error → reintentar con `gpt-5.4-codex`. Segundo fallo → abortar y notificar `codex login` posiblemente expirado.
- Dual Mode NO sustituye a las personas. Para dominios no-técnicos (negocio, física, finanzas, narrativa) las personas son autoritativas; Codex se limita a código y arquitectura técnica.

### Peer auto-routing (NUEVO v9.0)

`/dual` sin flag → Claude auto-elige Codex vs Gemini según señales en la task. Override con `--codex` o `--gemini`.

| Señal | Peer recomendado | Razón |
|---|---|---|
| "todo el repo" · ">N files" · "cross-cutting" · "long context" · imagen | **Gemini** (3.1 pro/flash) | 2M context window vs Codex limitado |
| "surgical" · "este archivo" · "este método" · "token efficiency" · "terminal/CLI" | **Codex** (gpt-5.5) | 72% menos output tokens, Terminal-Bench SOTA 82.7% |
| Strict JSON schema enforced server-side requerido | **Codex** | Gemini valida client-side post-hoc |
| Worktree isolation (analizar diff de toda rama) | **Gemini** (`-w` flag nativo) | Codex no tiene equivalente |
| Default sin señales claras | **Codex** | Más eficiente en tokens, output más conciso |

Reportar la decisión: `[Dual auto-routing] peer elegido: Codex — señal: surgical fix en 1 archivo`.

---

## § TRIPLE MODE — Dual-peer Iteration con Codex + Gemini (NUEVO v9.0)

**Triggers:** `/minitriple` · `/triple` · `/maxtriple` · `/triple --rounds=N`
**Backend:** ambos peers en paralelo:
- Codex: `scripts/codex-duet.ps1` (gpt-5.5 read-only)
- Gemini: `scripts/gemini-duet.ps1` (Gemini 3.1 pro `--approval-mode plan`)
**Spec completa:** `references/triple-mode-protocol.md` (TODO crear) y `triple-debate-schema.json`

### Decisión rápida — Triple vs Dual

```
¿Una pregunta concreta sin necesidad de 2 ángulos?       → Dual (1 peer)
¿Quieres que 2 peers debatan desde ángulos distintos?    → Triple
¿Decisión arquitectónica con divergencia probable?       → Triple (3 rounds)
¿Mega-decisión / código producción / diseño del sistema? → MaxTriple (5 rounds, ULTRA only)
```

### Gating obligatorio

| Modo activo de ULTRON | MiniTriple | Triple | MaxTriple |
|---|---|---|---|
| LOW | ❌ prohibido | ❌ | ❌ |
| MEDIUM | ❌ (Triple es waste para tareas medium) | ❌ | ❌ |
| HIGH | ✅ trigger explícito | ⚠️ solo bajo trigger explícito | ❌ |
| ULTRA | ✅ | ✅ recomendado | ✅ recomendado para arq crítica |

### Hard caps por sesión (separados de Dual)

- **MiniTriple:** ilimitado (cada llamada es 1 round x 2 peers)
- **Triple:** 3 invocaciones por día sin permiso explícito (counter en `~/.ultron/sessions/<date>/triple-caps.json`)
- **MaxTriple:** 1 invocación por día sin permiso explícito

### Protocolo de invocación

```
1. PREPARAR    → prompt compactado al mínimo (≤2K tk) — ambos peers lo reciben igual
2. INVOCAR     → en paralelo (no secuencial):
                 a) scripts/codex-duet.ps1 -Mode <Mini|Dual|Max> -Round <N> ...
                 b) scripts/gemini-duet.ps1 -Mode <Mini|Triple|Max> -Round <N> ...
3. ESPERAR     → ambos peers responden (timeout coordinado, default 240s)
4. PARSEAR     → JSON estructurado de cada peer:
                 - Codex: codex-duet-schema.json
                 - Gemini: gemini-duet-schema.json (incluye long_context_signal + scope_breadth)
5. SINTETIZAR  → Claude compara verdicts y critique:
                 - full_agree → proceder
                 - partial_agree → integrar mayoría
                 - diverge_minor → Claude decide con justificación
                 - diverge_major → escalar a Rodrigo (verdicts contradictorios)
6. REGISTRAR   → escribir triple-debate-schema.json a
                 ~/.ultron/sessions/<date>/triple-<timestamp>.json
                 (input para benchmark empírico futuro)
7. ROUND 2+    → si Triple/MaxTriple: resume con session_id de cada peer
8. REPORTAR    → "[Triple round N/total] Codex=X · Gemini=Y · agreement=Z · aplicando: W"
```

### Reglas inamovibles

- AMBOS peers SIEMPRE read-only (Codex `--sandbox read-only` · Gemini `--approval-mode plan`)
- Si AMBOS peers retornan `verdict: "block"` → parar inmediatamente, reportar a Rodrigo
- Si UNO retorna `block` y el otro `agree` → escalar a Rodrigo (divergencia mayor)
- Triple NO sustituye a las personas. Mismo principio que Dual: dominios técnicos solamente
- NO usar Triple para sanity checks simples — esto es para debate sustantivo
- Triple consume ~2x tokens de Dual (ambos peers en paralelo). Reservar para decisiones que lo justifiquen
- Si Gemini falla (Gotcha #5: sin sesiones previas) → Triple degrada a Dual con Codex y reporta
- Si Codex falla (auth error) → Triple degrada a Dual con Gemini y reporta

### Token economy

| Round | Tokens estimados (Codex + Gemini) | Cuándo |
|---|---|---|
| 1 (CRITIQUE × 2) | ~3-5K input · ~1-2K output cada peer | Cualquier Triple sub-modo |
| 2 (REFINE × 2) | ~1K input (resume) · ~500 output cada peer | Triple, MaxTriple |
| 3 (VERIFY × 2) | ~2K input · ~1K output cada peer | MaxTriple |

**Total típico Triple 3 rounds:** ~10-15K tokens entre ambos peers vs ~5-8K Dual 3 rounds.
