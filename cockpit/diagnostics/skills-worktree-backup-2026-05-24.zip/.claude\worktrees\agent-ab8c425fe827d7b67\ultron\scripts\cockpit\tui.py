#!/usr/bin/env python3
"""
ULTRON v10.1 TUI - Interactive cockpit interface (textual library).

Theme: tokyo-night dark. 7 views accessible via sidebar:
    Projects · Personas · Activity · News · Auth · Scheduler · Health

Run:
    ultron tui     OR     ultron     (no args opens TUI)

Keyboard:
    1-7        switch view directly
    Tab/S-Tab  cycle focus
    Enter      activate selected
    /          search/filter current view
    q          quit
    ?          help modal

ULTRON does NOT auto-commit. Git status is read-only.
AI calls go through CLIs (claude/codex/gemini), never the API directly.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from rich.markup import escape as _markup_escape

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

sys.path.insert(0, str(Path(__file__).parent))
from cockpit_base import (  # noqa: E402
    Cockpit, COCKPIT_DIR, PROJECTS_JSON, ACTIVITY_JSONL,
    DEADLINES_JSON, AUTH_VAULT, NEWS_DIR, NEWS_ALERTS,
)

# Root of the ULTRON skill directory (where references/ lives)
ULTRON_ROOT = Path(__file__).parent.parent.parent

try:
    from textual import work
    from textual.app import App, ComposeResult
    from textual.binding import Binding
    from textual.containers import Horizontal, Vertical, ScrollableContainer
    from textual.screen import ModalScreen
    from textual.widgets import (
        Header, Footer, Static, ListView, ListItem, Label,
        DataTable, Input, Button,
    )
    from textual.reactive import reactive
except ImportError:
    print("ERROR: textual not installed. Run: pip install textual rich")
    sys.exit(1)


# ── Theme & CSS ──────────────────────────────────────────────────────────────

TUI_CSS = """
/* v10.5.1 Onyx palette — deep blacks, restrained accents.
   Replaces tokyo-night (#1a1b26 + vibrant blues) with #0a0a0a + monochrome
   greys + single amber/cyan accent for state changes. Inspired by Onyx
   Boox / Warp default. */
Screen {
    background: #0a0a0a;
    color: #d4d4d4;
}

#sidebar {
    width: 24;
    border-right: thick #2a2a2a;
    background: #060606;
    padding: 1;
}

#main {
    padding: 1 2;
    background: #0a0a0a;
}

.nav-item {
    padding: 0 1;
    color: #a0a0a0;
}

.nav-item.active {
    background: #1f1f1f;
    color: #ffd089;
    text-style: bold;
}

#header-info {
    background: #060606;
    color: #8aa8a0;
    padding: 0 1;
    height: 1;
}

#status-bar {
    background: #060606;
    color: #d4d4d4;
    padding: 0 2;
    height: 1;
    border-bottom: solid #1a1a1a;
}

DataTable {
    background: #0a0a0a;
}

DataTable > .datatable--header {
    background: #1a1a1a;
    color: #ffd089;
    text-style: bold;
}

DataTable > .datatable--cursor {
    background: #2a2a2a;
}

Button {
    background: #1a1a1a;
    color: #d4d4d4;
    border: none;
    margin: 0 1;
}

Button:hover {
    background: #2a2a2a;
    color: #ffd089;
}

Button.primary {
    background: #2a2a2a;
    color: #ffd089;
    text-style: bold;
}

Button.success {
    background: #1f2a1f;
    color: #9eca7e;
}

Button.warning {
    background: #2a2418;
    color: #e0a868;
}

Static.title {
    color: #ffd089;
    text-style: bold;
    margin: 1 0;
}

Static.subtitle {
    color: #8aa8a0;
    margin: 0 0 1 0;
}

.muted {
    color: #555555;
}

.warning {
    color: #e0a868;
}

.error {
    color: #d77878;
}

.success {
    color: #9eca7e;
}

ModalScreen {
    align: center middle;
}

#modal-box {
    width: 60%;
    height: auto;
    max-height: 80%;
    background: #0a0a0a;
    border: thick #2a2a2a;
    padding: 2;
}
"""


# ── Data loaders ─────────────────────────────────────────────────────────────

def load_projects() -> list[dict]:
    return Cockpit.read_json(PROJECTS_JSON, default={"projects": []}).get("projects", [])


def load_activity(days: int = 7) -> list[dict]:
    if not ACTIVITY_JSONL.exists():
        return []
    cutoff = datetime.now() - timedelta(days=days)
    out = []
    for line in ACTIVITY_JSONL.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            entry = json.loads(line)
            ts = datetime.fromisoformat(entry.get("ts", ""))
            if ts >= cutoff:
                out.append(entry)
        except (ValueError, json.JSONDecodeError):
            continue
    return out


def load_vault_summary() -> dict:
    if not AUTH_VAULT.exists():
        return {}
    try:
        data = json.loads(AUTH_VAULT.read_text(encoding="utf-8-sig"))
        out = {}
        for svc, svc_data in (data.get("services") or {}).items():
            out[svc] = {
                "active": svc_data.get("active") or "(none)",
                "profiles": list((svc_data.get("profiles") or {}).keys()),
            }
        return out
    except Exception:
        return {}


# ── Personas registry ─────────────────────────────────────────────────────────

PERSONAS = [
    ("terry-davis",     "Ingeniero de élite — código, debug, refactor"),
    ("don-claudio",     "Padrino del Game Dev — UE5, Unity, netcode"),
    ("mike-tyson",      "UI/UX brutal honest — diseño visual"),
    ("jordan-belfort",  "Estrategia negocio — pricing, GTM, B2B"),
    ("einstein",        "Investigación universal — ciencia, papers"),
    ("novalbos",        "Profesor técnico — C++, GPU, ML, low-level"),
    ("pana",            "Sistema operativo personal — agenda, briefing"),
    ("alfred",          "Mayordomo digital — sistema, archivos, drivers"),
    ("profesor-fisica", "Física personal — cinemática, dinámica"),
    ("tio-gilito",      "Asesor financiero personal — gastos, presupuesto"),
    ("warren",          "Inversiones — bolsa, ETF, mercado"),
    ("repo-evaluator",  "Kirkardo — evaluador estricto académico"),
    ("manolo-lama",     "Comentarista deportivo — fútbol épico"),
    ("tolkien",         "Escritor del libro — narrativa medieval"),
]


# ── Helper: subprocess wrappers (CLI only, never API) ────────────────────────

def open_in_terminal(cmd: str, cwd: str | None = None) -> None:
    """Open a new Windows Terminal / cmd window running cmd at cwd."""
    if cmd == "claude":
        cmd = "claude --dangerously-skip-permissions"
    if os.name != "nt":
        return
    work_dir = cwd or str(Path.home())
    try:
        # Windows Terminal: open new tab in work_dir running cmd
        subprocess.Popen(["wt.exe", "-d", work_dir, "cmd", "/k", cmd])
    except FileNotFoundError:
        # wt.exe not available — open a plain cmd window via shell 'start'
        # shell=True lets 'start' builtin work; escape inner double-quotes
        safe_cmd = cmd.replace('"', '\\"')
        subprocess.Popen(
            f'start "ULTRON" cmd /k "{safe_cmd}"',
            shell=True, cwd=work_dir,
        )


def _newsletter_md_to_html(md: str, date: str) -> str:
    """Convert Gemini markdown newsletter to ULTRON-themed HTML."""
    import html as _html
    import re as _re

    def md_line_to_html(line: str) -> str:
        """Convert a single markdown line to HTML."""
        if line.startswith("### "):
            return f"<h3>{_html.escape(line[4:])}</h3>"
        if line.startswith("## "):
            return f"<h2>{_html.escape(line[3:])}</h2>"
        if line.startswith("# "):
            return f"<h1>{_html.escape(line[2:])}</h1>"
        if line.startswith("- "):
            text = _re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>",
                           _html.escape(line[2:]))
            return f"<li>{text}</li>"
        if line.strip() == "":
            return ""
        text = _re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", _html.escape(line))
        return f"<p>{text}</p>"

    body_parts = []
    in_ul = False
    for line in md.splitlines():
        is_li = line.startswith("- ")
        if is_li and not in_ul:
            body_parts.append("<ul>")
            in_ul = True
        elif not is_li and in_ul:
            body_parts.append("</ul>")
            in_ul = False
        h = md_line_to_html(line)
        if h:
            body_parts.append(h)
    if in_ul:
        body_parts.append("</ul>")
    body = "\n".join(body_parts)

    return f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>ULTRON Newsletter — {date}</title>
<style>
body{{background:#0d1117;color:#c9d1d9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;max-width:800px;margin:40px auto;padding:0 24px;line-height:1.7}}
h1{{color:#ffd089;border-bottom:2px solid #ffd089;padding-bottom:.4em;margin-bottom:1em}}
h2{{color:#8aa8a0;font-size:1.05em;margin-top:1.8em;border-bottom:1px solid #30363d;padding-bottom:.2em}}
h3{{color:#e0a868;font-size:.95em;margin-top:1.2em}}
li{{margin:.35em 0}}
ul{{padding-left:1.5em;margin:.5em 0}}
strong{{color:#e0a868}}
a{{color:#58a6ff}}
p{{margin:.6em 0}}
.header{{margin-bottom:2em}}
.date{{color:#8aa8a0;font-size:.82em;margin-top:.3em}}
</style>
</head>
<body>
<div class="header">
  <h1>⌬ ULTRON Newsletter</h1>
  <div class="date">{date} · Gemini 3.1 Pro Preview · ULTRON v11</div>
</div>
{body}
</body>
</html>"""


def trigger_scheduled_task(task_name: str) -> bool:
    """Run a Task Scheduler task NOW."""
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", f"Start-ScheduledTask -TaskName {task_name}"],
            capture_output=True, timeout=10,
        )
        return result.returncode == 0
    except Exception:
        return False


def disable_task(task_name: str) -> bool:
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", f"Disable-ScheduledTask -TaskName {task_name}"],
            capture_output=True, timeout=10,
        )
        return result.returncode == 0
    except Exception:
        return False


def enable_task(task_name: str) -> bool:
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", f"Enable-ScheduledTask -TaskName {task_name}"],
            capture_output=True, timeout=10,
        )
        return result.returncode == 0
    except Exception:
        return False


def get_scheduled_tasks() -> list[dict]:
    """Return [{name, state, last_run, next_run, last_result}, ...] for Ultron* tasks.

    Defensively handles null LastRunTime / NextRunTime (when task has never run).
    """
    if os.name != "nt":
        return []
    try:
        ps = """
$tasks = Get-ScheduledTask -TaskName 'Ultron*' -ErrorAction SilentlyContinue
if (-not $tasks) { Write-Output '[]'; exit }
$out = foreach ($t in $tasks) {
    $info = $t | Get-ScheduledTaskInfo -ErrorAction SilentlyContinue
    $lastRun = if ($info -and $info.LastRunTime) { $info.LastRunTime.ToString('o') } else { '' }
    $nextRun = if ($info -and $info.NextRunTime) { $info.NextRunTime.ToString('o') } else { '' }
    $lastResult = if ($info) { $info.LastTaskResult } else { $null }
    [pscustomobject]@{
        name = $t.TaskName
        state = $t.State.ToString()
        last_run = $lastRun
        next_run = $nextRun
        last_result = $lastResult
    }
}
$out | ConvertTo-Json -Depth 3 -Compress
"""
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps],
            capture_output=True, text=True, timeout=15, encoding="utf-8",
        )
        if result.returncode != 0:
            return []
        stdout = (result.stdout or "").strip()
        if not stdout:
            return []
        # Strip BOM if present
        if stdout.startswith("﻿"):
            stdout = stdout[1:]
        data = json.loads(stdout)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return [data]
        return []
    except Exception:
        return []


def get_git_status_short(project_path: str) -> dict:
    """Returns {branch, ahead, behind, dirty} or empty dict if not a git repo."""
    out = {"branch": None, "ahead": 0, "behind": 0, "dirty": False}
    try:
        # Branch name
        r = subprocess.run(
            ["git", "-C", project_path, "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=5,
        )
        if r.returncode != 0:
            return {}
        out["branch"] = r.stdout.strip()
        # Dirty?
        r = subprocess.run(
            ["git", "-C", project_path, "status", "--porcelain"],
            capture_output=True, text=True, timeout=5,
        )
        out["dirty"] = bool(r.stdout.strip())
        # Ahead/behind vs upstream
        r = subprocess.run(
            ["git", "-C", project_path, "rev-list", "--left-right", "--count", "HEAD...@{u}"],
            capture_output=True, text=True, timeout=5,
        )
        if r.returncode == 0 and r.stdout.strip():
            parts = r.stdout.strip().split()
            if len(parts) == 2:
                out["ahead"], out["behind"] = int(parts[0]), int(parts[1])
    except Exception:
        return out
    return out


# ── Modal: Persona invoker ───────────────────────────────────────────────────

class PersonaInvokerModal(ModalScreen):
    """Pick a persona, optionally a project, type a question, then open Claude with it."""

    BINDINGS = [Binding("escape", "dismiss", "Cancel")]

    def __init__(self, project: dict | None = None) -> None:
        super().__init__()
        self.project = project
        self.selected_persona: str | None = None

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-box"):
            yield Static("[b]Ask a Persona[/b]", classes="title")
            yield Static(
                f"Project: [cyan]{self.project.get('name')}[/cyan]"
                if self.project else "Project: [dim](none, general question)[/dim]",
                classes="subtitle",
            )
            yield Static("Pick a persona:")
            # Build ListItems BEFORE constructing ListView (textual requires this)
            persona_items = [
                ListItem(Label(f"[b]{slug}[/b] - {desc}"), id=f"p-{slug}")
                for slug, desc in PERSONAS
            ]
            yield ListView(*persona_items, id="persona-list")
            yield Static("Question:", classes="title")
            yield Input(placeholder="en que estaba con esto", id="question-input")
            with Horizontal():
                yield Button("Open Claude", id="invoke", variant="primary")
                yield Button("Cancel", id="cancel")

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        if event.item and event.item.id and event.item.id.startswith("p-"):
            self.selected_persona = event.item.id[2:]

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel":
            self.dismiss()
            return
        if event.button.id == "invoke":
            if not self.selected_persona:
                return
            question = self.query_one("#question-input", Input).value or "en qué estaba"
            project_hint = (
                f" sobre el proyecto {self.project.get('name')}"
                if self.project else ""
            )
            full_prompt = f'Ultron, {self.selected_persona}, {question}{project_hint}'
            cwd = self.project.get("path") if self.project else None
            open_in_terminal(f'claude "{full_prompt}"', cwd=cwd)
            self.dismiss()


class HelpModal(ModalScreen):
    BINDINGS = [Binding("escape,q,h", "dismiss", "Close")]

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-box"):
            yield Static("[b]ULTRON CORE v11.0 - Help[/b]", classes="title")
            yield Static("""
[b cyan]VIEWS (1-7 + 8-0 + u + `):[/b cyan]
  1 Projects    2 Personas    3 Activity     4 News        5 Auth
  6 Scheduler   7 Health      8 MCPs         9 Usage       0 Apps
  u AutoUpdater  v Changelog  s Notes

[b cyan]PROJECT ACTIONS:[/b cyan]
  o   Open project in its IDE
  e   Edit project (Preview→Confirm modal, Sonnet)
  d   Delete project (confirmación)
  a   Ask persona about project

[b cyan]AI SESSIONS (cwd = selected project or current):[/b cyan]
  c   Claude Code session
  g   Gemini CLI session
  x   Codex CLI session
  t   Triple debate (Codex + Gemini via /triple)

[b cyan]META operations:[/b cyan]
  k   Kirkardo audit (QUICK · FULL · TRIPLE 3-model)
  p   L3 Apply latest proposals
  n   New skill (Q&A interactive in terminal)
  l   Limits status

[b cyan]Global:[/b cyan]
  ?   Quick-ask Haiku con mini-memoria
  h   This help   r Refresh   q Quit

[b yellow]NEWS VIEW BUTTONS (v11.0 new):[/b yellow]
  ⟳ Refresh (RSS+Gemini)  🔍 Search/Filter  📡 Sources
  📰 Newsletter (styled HTML)  Digest · ALERTS

[b yellow]AUTOUPDATER (v11.0):[/b yellow]
  Full skills status table · audit notes · new-skill alignment
  Kirkardo: QUICK · FULL · TRIPLE (Claude+Codex+Gemini)

[b yellow]TERMINAL VIEW (` key - v11.0 new):[/b yellow]
  Run ultron commands inline · quick-access buttons · output shown in TUI

[b green]MODELOS Y CUÁNDO:[/b green]
  Haiku   light   → quick-ask, project tags, name lookups
  Sonnet  mid     → project edit, schedule edit, audit QUICK,
                     newsletter magazine, MCP scaffold, skill create
  Opus    heavy   → audit FULL (Kirkardo independent, on demand)

[b red]ANTI-LAUNDERING RULES (no negociables):[/b red]
  - ULTRON nunca auto-commits (regla de Rodrigo)
  - Audits always labeled `evaluator: kirkardo-independent`
  - L3 apply siempre human-gated (spawn Claude review session)
  - Internal paths preservados en rebrands (cron compat)
  - Game launchers (Steam etc) NO cuentan como gaming
  - Falsos positivos auto-flagged en L2 propose (knowledge cutoff)
""")
            yield Button("Close", id="close-help", variant="primary")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-help":
            self.dismiss()


# ── v10.4 New modals: QuickAsk + ProjectEdit + KirkardoAudit ─────────────────

class QuickAskModal(ModalScreen):
    """Tecla `?` global — ultron ask via Haiku, sin salir del TUI."""
    BINDINGS = [Binding("escape", "dismiss", "Cancel")]

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-box"):
            yield Static("[b]Quick Ask (Haiku + mini-memoria)[/b]", classes="title")
            yield Static(
                "[dim]Haiku 4.5 con cwd + INDEX.md head + activity tail. "
                "Respuesta 1-3 líneas. Enter para enviar.[/dim]",
                classes="subtitle")
            yield Input(
                placeholder="¿qué es Mythos? · ¿hace cuánto no toco tortunabo? · explica X",
                id="ask-input")
            yield Static("", id="ask-result", classes="muted")
            with Horizontal():
                yield Button("Ask", id="ask-go", variant="primary")
                yield Button("Cancel", id="ask-cancel")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "ask-input":
            self._do_ask()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "ask-cancel":
            self.dismiss()
        elif event.button.id == "ask-go":
            self._do_ask()

    def _do_ask(self) -> None:
        q = self.query_one("#ask-input", Input).value.strip()
        if not q:
            return
        result_widget = self.query_one("#ask-result", Static)
        result_widget.update("[yellow]Asking Haiku... (non-blocking)[/yellow]")
        self._run_ask(q)

    @work(thread=True, exclusive=True)
    def _run_ask(self, query: str) -> None:
        script = Path(__file__).parent / "quick_ask.py"
        try:
            r = subprocess.run([sys.executable, str(script), query],
                                capture_output=True, text=True,
                                timeout=60, encoding="utf-8")
            answer = (r.stdout or "").strip()[:600]
            if not answer:
                answer = (r.stderr or "(no output)")[:300]
            self.app.call_from_thread(self._update_result,
                                       f"[green]{answer}[/green]")
        except subprocess.TimeoutExpired:
            self.app.call_from_thread(self._update_result,
                                       "[red]Timeout 60s[/red]")
        except Exception as e:
            self.app.call_from_thread(self._update_result,
                                       f"[red]Error: {e}[/red]")

    def _update_result(self, text: str) -> None:
        try:
            self.query_one("#ask-result", Static).update(text)
        except Exception:
            pass


class ProjectEditModal(ModalScreen):
    """Tecla `e` con project seleccionado — flow simple: Preview → Confirm.

    1. User escribe instrucción + click Preview
    2. Sonnet genera diff (sin tocar nada)
    3. Si OK, user click Confirm → aplica el cambio
    4. Si no, Cancel cierra sin tocar
    """
    BINDINGS = [Binding("escape", "dismiss", "Cancel")]

    def __init__(self, project_id: str) -> None:
        super().__init__()
        self.project_id = project_id
        self.last_query: str = ""
        self.preview_ok: bool = False

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-box"):
            yield Static(f"[b]Edit Project[/b] [cyan]{self.project_id}[/cyan]", classes="title")
            yield Static("[dim]1) Escribe tu instrucción · 2) Preview · 3) Confirm[/dim]",
                          classes="subtitle")
            yield Input(placeholder="añade tag urgent · cambia lenguaje a Java",
                         id="edit-input")
            yield Static("", id="edit-result", classes="muted")
            with Horizontal():
                yield Button("Preview (Sonnet)", id="edit-preview", variant="primary")
                yield Button("Confirm Apply", id="edit-confirm", variant="warning",
                             disabled=True)
                yield Button("Cancel", id="edit-cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "edit-cancel":
            self.dismiss()
            return
        q = self.query_one("#edit-input", Input).value.strip()
        if not q:
            return
        result_widget = self.query_one("#edit-result", Static)
        if event.button.id == "edit-preview":
            self.last_query = q
            self.preview_ok = False
            try:
                self.query_one("#edit-confirm", Button).disabled = True
            except Exception:
                pass
            result_widget.update(
                "[yellow]Sonnet preview... (~15-30s, UI no se bloquea)[/yellow]")
            self._run_edit(q, apply_flag=False)
        elif event.button.id == "edit-confirm":
            if not self.preview_ok or not self.last_query:
                result_widget.update(
                    "[red]Primero haz Preview y revisa el diff[/red]")
                return
            result_widget.update(
                "[yellow]Sonnet applying...[/yellow]")
            self._run_edit(self.last_query, apply_flag=True)

    _DELETE_WORDS = {"elimina", "eliminar", "borra", "borrar", "delete", "remove",
                     "quita", "quitar", "suprimir", "suprime", "drop", "erase"}

    @work(thread=True, exclusive=True)
    def _run_edit(self, query: str, apply_flag: bool) -> None:
        if any(w in query.lower().split() for w in self._DELETE_WORDS):
            self.app.call_from_thread(
                self._update_result,
                "[yellow]Para eliminar un proyecto usa la tecla [b]d[/b] "
                "en la lista de proyectos — incluye confirmación.[/yellow]"
            )
            return
        script = Path(__file__).parent / "project_editor.py"
        cmd = [sys.executable, str(script), "edit", self.project_id] + query.split()
        if apply_flag:
            cmd.append("--apply")
        try:
            r = subprocess.run(cmd, capture_output=True, text=True,
                                timeout=120, encoding="utf-8")
            stdout = (r.stdout or "").strip()
            stderr = (r.stderr or "").strip()
            if r.returncode == 0:
                payload = stdout[:1500] or "(no output)"
                color = "green"
                # Enable Confirm button if this was a successful preview
                if not apply_flag:
                    self.app.call_from_thread(self._enable_confirm)
                else:
                    # Apply succeeded — close after showing result
                    self.app.call_from_thread(self._apply_done, payload)
                    return
            else:
                # FAIL — show stdout + stderr both, so the real error is visible
                color = "red"
                parts = []
                if stdout:
                    parts.append(f"stdout: {stdout[:800]}")
                if stderr:
                    parts.append(f"stderr: {stderr[:800]}")
                if not parts:
                    parts.append("(no output captured)")
                payload = f"Exit {r.returncode}\n" + "\n\n".join(parts)
            self.app.call_from_thread(self._update_result,
                                       f"[{color}]{payload}[/{color}]")
        except subprocess.TimeoutExpired:
            self.app.call_from_thread(self._update_result, "[red]Timeout 120s[/red]")
        except Exception as e:
            self.app.call_from_thread(self._update_result, f"[red]Error: {e}[/red]")

    def _enable_confirm(self) -> None:
        self.preview_ok = True
        try:
            self.query_one("#edit-confirm", Button).disabled = False
        except Exception:
            pass

    def _apply_done(self, payload: str) -> None:
        try:
            self.query_one("#edit-result", Static).update(
                f"[green]✓ Applied:\n{payload}[/green]")
            self.query_one("#edit-confirm", Button).disabled = True
        except Exception:
            pass

    def _update_result(self, text: str) -> None:
        try:
            self.query_one("#edit-result", Static).update(text)
        except Exception:
            pass


class DeleteProjectModal(ModalScreen):
    """Tecla `d` con project seleccionado — confirmación antes de borrar del registry."""
    BINDINGS = [Binding("escape", "dismiss", "Cancel")]

    def __init__(self, project_id: str) -> None:
        super().__init__()
        self.project_id = project_id

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-box"):
            yield Static("[b red]Delete Project[/b red]", classes="title")
            yield Static(
                f"[yellow]¿Eliminar [b]{_markup_escape(self.project_id)}[/b] del registry?[/yellow]\n"
                "[dim]Solo se elimina del registry — no borra archivos del disco.[/dim]",
                classes="subtitle")
            with Horizontal(classes="button-row"):
                yield Button("Confirmar", id="del-confirm", variant="error")
                yield Button("Cancelar", id="del-cancel", variant="default")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "del-confirm":
            self._do_delete()
        else:
            self.dismiss()

    @work(thread=True, exclusive=True)
    def _do_delete(self) -> None:
        script = Path(__file__).parent / "project_editor.py"
        cmd = [sys.executable, str(script), "delete", self.project_id, "--yes"]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True,
                               timeout=15, encoding="utf-8")
            ok = r.returncode == 0
            msg = ((r.stdout or "") + (r.stderr or "")).strip()
            self.app.call_from_thread(self._finish, ok, msg)
        except Exception as e:
            self.app.call_from_thread(self._finish, False, str(e))

    def _finish(self, ok: bool, msg: str) -> None:
        if ok:
            self.app.notify(f"Deleted: {self.project_id}", severity="information")
            self.dismiss()
        else:
            self.app.notify(f"Delete failed: {msg[:120]}", severity="error")
            self.dismiss()


class LimitsModal(ModalScreen):
    """Tecla `l` — muestra usage limits actuales (read-only).
    Para editar: `ultron limits set <model> daily_billable <n>` desde terminal."""
    BINDINGS = [Binding("escape,l", "dismiss", "Close")]

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-box"):
            yield Static("[b]Usage Limits (last 24h)[/b]", classes="title")
            yield Static("[dim]Edit: `ultron limits set <model> daily_billable <n>` (terminal)[/dim]",
                          classes="subtitle")
            yield Static("[yellow]Loading...[/yellow]", id="limits-content")
            yield Button("Close", id="limits-close", variant="primary")
        # Trigger fetch async
        self._fetch()

    @work(thread=True, exclusive=True)
    def _fetch(self) -> None:
        script = Path(__file__).parent / "usage_limits.py"
        try:
            r = subprocess.run([sys.executable, str(script), "status"],
                                capture_output=True, text=True,
                                timeout=30, encoding="utf-8")
            out = (r.stdout or "(no output)")[:1500]
            self.app.call_from_thread(self._update, out)
        except Exception as e:
            self.app.call_from_thread(self._update, f"[red]Error: {e}[/red]")

    def _update(self, text: str) -> None:
        try:
            self.query_one("#limits-content", Static).update(text)
        except Exception:
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "limits-close":
            self.dismiss()


class MCPActionModal(ModalScreen):
    """Modal genérico para MCP actions con input. Spawn terminal con el comando."""
    BINDINGS = [Binding("escape", "dismiss", "Cancel")]

    def __init__(self, action: str) -> None:
        super().__init__()
        self.action = action  # install | uninstall | validate | scaffold

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-box"):
            yield Static(f"[b]MCP {self.action}[/b]", classes="title")
            placeholder_map = {
                "install":   "ID del catálogo (e.g. supabase, github, notion)",
                "uninstall": "ID instalado (e.g. supabase)",
                "validate":  "ID instalado (e.g. supabase)",
                "scaffold":  "Idea libre (Sonnet genera scaffold)",
            }
            yield Static(f"[dim]{placeholder_map.get(self.action, '')}[/dim]",
                          classes="subtitle")
            yield Input(placeholder=placeholder_map.get(self.action, ""),
                         id="mcp-input")
            with Horizontal():
                yield Button("Run in terminal", id="mcp-run", variant="primary")
                yield Button("Cancel", id="mcp-cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "mcp-cancel":
            self.dismiss()
            return
        val = self.query_one("#mcp-input", Input).value.strip()
        if not val:
            return
        ult = Path(__file__).parent / "ultron.ps1"
        ps_prefix = f'powershell -NoProfile -ExecutionPolicy Bypass -File "{ult}"'
        cmd = f'{ps_prefix} mcp {self.action} {val}'
        open_in_terminal(cmd)
        self.dismiss()


class ScheduleEditModal(ModalScreen):
    """Tecla para Scheduler edit AI — schedule_editor.py chat NL → modify."""
    BINDINGS = [Binding("escape", "dismiss", "Cancel")]

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-box"):
            yield Static("[b]Schedule Edit (AI)[/b]", classes="title")
            yield Static("[dim]NL → schedule-config.json (Sonnet, dry-run by default)[/dim]",
                          classes="subtitle")
            yield Input(placeholder="disable standup en weekends · cambia news a las 9am",
                         id="sched-input")
            yield Static("", id="sched-result", classes="muted")
            with Horizontal():
                yield Button("Dry-run", id="sched-dry", variant="primary")
                yield Button("Apply", id="sched-apply", variant="warning")
                yield Button("Cancel", id="sched-cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "sched-cancel":
            self.dismiss()
            return
        q = self.query_one("#sched-input", Input).value.strip()
        if not q:
            return
        result_widget = self.query_one("#sched-result", Static)
        result_widget.update(
            "[yellow]Sonnet editing... (UI no se bloquea)[/yellow]")
        apply_flag = (event.button.id == "sched-apply")
        self._run_chat(q, apply_flag)

    @work(thread=True, exclusive=True)
    def _run_chat(self, query: str, apply_flag: bool) -> None:
        script = Path(__file__).parent / "schedule_editor.py"
        cmd = [sys.executable, str(script), "chat"] + query.split()
        if apply_flag:
            cmd.append("--apply")
        try:
            r = subprocess.run(cmd, capture_output=True, text=True,
                                timeout=120, encoding="utf-8")
            out = (r.stdout or "")[:1200]
            err = (r.stderr or "")[:400]
            color = "green" if r.returncode == 0 else "red"
            payload = out + (f"\nstderr: {err}" if err and r.returncode != 0 else "")
            self.app.call_from_thread(self._update,
                                       f"[{color}]{payload}[/{color}]")
        except subprocess.TimeoutExpired:
            self.app.call_from_thread(self._update, "[red]Timeout 120s[/red]")
        except Exception as e:
            self.app.call_from_thread(self._update, f"[red]Error: {e}[/red]")

    def _update(self, text: str) -> None:
        try:
            self.query_one("#sched-result", Static).update(text)
        except Exception:
            pass


class KirkardoAuditModal(ModalScreen):
    """Tecla `k` — Kirkardo audit con opciones: QUICK · FULL · TRIPLE (3 modelos)."""
    BINDINGS = [Binding("escape", "dismiss", "Cancel")]

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-box"):
            yield Static("[b]Kirkardo Audit[/b]", classes="title")
            yield Static(
                "[dim]QUICK Sonnet ~30s · FULL Opus ~90s · "
                "TRIPLE (Claude+Codex+Gemini) ~3-5min[/dim]",
                classes="subtitle")
            yield Input(placeholder="ultron · terry-davis · don-claudio · ...",
                         id="audit-input")
            yield Static("", id="audit-result", classes="muted")
            with Horizontal():
                yield Button("Run QUICK", id="audit-quick", variant="primary")
                yield Button("Run FULL (Opus)", id="audit-full", variant="warning")
                yield Button("⚡ TRIPLE (3-model)", id="audit-triple", variant="error")
                yield Button("Cancel", id="audit-cancel")

    def on_button_pressed(self, event: "Button.Pressed") -> None:
        if event.button.id == "audit-cancel":
            self.dismiss()
            return
        target = self.query_one("#audit-input", Input).value.strip()
        if not target:
            return
        result_widget = self.query_one("#audit-result", Static)
        bid = event.button.id
        if bid == "audit-triple":
            result_widget.update(
                f"[yellow]TRIPLE audit {target}... "
                "(Claude+Codex+Gemini, ~3-5min, UI libre)[/yellow]")
            self._run_audit(target, mode="triple")
        else:
            quick = (bid == "audit-quick")
            kind = "QUICK Sonnet ~30-60s" if quick else "FULL Opus ~60-120s"
            result_widget.update(
                f"[yellow]Auditing {target}... ({kind}, UI no se bloquea)[/yellow]")
            self._run_audit(target, mode="quick" if quick else "full")

    @work(thread=True, exclusive=True)
    def _run_audit(self, target: str, mode: str) -> None:
        script = Path(__file__).parent / "persona_audit.py"
        cmd = [sys.executable, str(script), "run", target]
        if mode == "quick":
            cmd.append("--quick")
        elif mode == "triple":
            cmd.append("--triple")
        try:
            timeout = 600 if mode == "triple" else 300
            r = subprocess.run(cmd, capture_output=True, text=True,
                                timeout=timeout, encoding="utf-8")
            out = (r.stdout or "")[:2000]
            if r.returncode != 0 and r.stderr:
                out += f"\n[red]stderr: {r.stderr[:300]}[/red]"
            color = "green" if r.returncode == 0 else "yellow"
            self.app.call_from_thread(self._update_result, f"[{color}]{out}[/{color}]")
        except subprocess.TimeoutExpired:
            self.app.call_from_thread(self._update_result,
                                       f"[red]Timeout {'600' if mode == 'triple' else '300'}s[/red]")
        except Exception as e:
            self.app.call_from_thread(self._update_result, f"[red]Error: {e}[/red]")

    def _update_result(self, text: str) -> None:
        try:
            self.query_one("#audit-result", Static).update(text)
        except Exception:
            pass


# ── Main App ─────────────────────────────────────────────────────────────────

class UltronTUI(App):
    """ULTRON v10.4 CORE — terminal interface to all CORE subsystems."""

    CSS = TUI_CSS
    TITLE = "ULTRON CORE v11.0"
    SUB_TITLE = "tri-model orchestrator + AI ops"

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("question_mark", "quick_ask", "QuickAsk"),
        Binding("h", "help", "Help"),
        # Views 1-7 (existing)
        Binding("1", "view_projects", "Projects"),
        Binding("2", "view_personas", "Personas"),
        Binding("3", "view_activity", "Activity"),
        Binding("4", "view_news", "News"),
        Binding("5", "view_auth", "Auth"),
        Binding("6", "view_scheduler", "Scheduler"),
        Binding("7", "view_health", "Health"),
        # v10.4 new views 8-0 + u
        Binding("8", "view_mcps", "MCPs"),
        Binding("9", "view_usage", "Usage"),
        Binding("0", "view_apps", "Apps"),
        Binding("u", "view_autoupdater", "AutoUpd"),
        Binding("j", "view_jobs",        "Jobs"),
        Binding("v", "view_changelog",   "Changelog"),
        Binding("s", "view_notes",       "Notes"),
        # Actions
        Binding("r", "refresh", "Refresh"),
        Binding("o", "open_selected", "Open"),
        Binding("a", "ask_persona", "Ask"),
        Binding("t", "triple_debate", "Triple"),
        Binding("c", "claude_here", "Claude"),
        Binding("e", "edit_project", "EditAI"),
        Binding("k", "kirkardo_audit", "Kirkardo"),
        Binding("g", "session_gemini", "Gemini"),
        Binding("x", "session_codex", "Codex"),
        Binding("n", "new_skill", "NewSkill"),
        Binding("l", "limits_status", "Limits"),
        Binding("p", "autoupdater_apply", "L3Apply"),
        Binding("d", "delete_project", "Delete"),
        Binding("f", "view_skills_market", "Skills"),
    ]

    current_view: reactive[str] = reactive("projects")

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield Static("", id="status-bar")
        with Horizontal():
            with Vertical(id="sidebar"):
                yield Static("[b]◆ ULTRON[/b]", id="logo")
                yield Static("[dim]CORE v11.0[/dim]")
                yield Static("")
                yield Static("[b]VIEWS[/b]", classes="muted")
                yield Static(" 1 ▸ Projects",     id="nav-projects",    classes="nav-item active")
                yield Static(" 2 ◉ Personas",     id="nav-personas",    classes="nav-item")
                yield Static(" 3 ▤ Activity",     id="nav-activity",    classes="nav-item")
                yield Static(" 4 ⌬ News",         id="nav-news",        classes="nav-item")
                yield Static(" 5 ⚿ Auth",         id="nav-auth",        classes="nav-item")
                yield Static(" 6 ◷ Scheduler",    id="nav-scheduler",   classes="nav-item")
                yield Static(" 7 ✚ Health",       id="nav-health",      classes="nav-item")
                yield Static(" 8 ⊕ MCPs",         id="nav-mcps",        classes="nav-item")
                yield Static(" 9 ⏆ Usage",        id="nav-usage",       classes="nav-item")
                yield Static(" 0 ▦ Apps",         id="nav-apps",        classes="nav-item")
                yield Static(" u ⟳ AutoUpdater",  id="nav-autoupdater", classes="nav-item")
                yield Static(" j ▶ Jobs",          id="nav-jobs",        classes="nav-item")
                yield Static(" v ≡ Changelog",     id="nav-changelog",   classes="nav-item")
                yield Static(" s ✎ Notes",          id="nav-notes",       classes="nav-item")
                yield Static(" f ⬡ Skills",         id="nav-skills-market", classes="nav-item")
                yield Static("")
                yield Static("[b]PROJECT[/b]", classes="muted")
                yield Static("[dim]o[/dim]  Open in IDE")
                yield Static("[dim]e[/dim]  Edit (AI)")
                yield Static("[dim]a[/dim]  Ask persona")
                yield Static("")
                yield Static("[b]SESSIONS[/b]", classes="muted")
                yield Static("[dim]c[/dim]  Claude")
                yield Static("[dim]g[/dim]  Gemini")
                yield Static("[dim]x[/dim]  Codex")
                yield Static("[dim]t[/dim]  Triple debate")
                yield Static("")
                yield Static("[b]META[/b]", classes="muted")
                yield Static("[dim]k[/dim]  Kirkardo audit")
                yield Static("[dim]p[/dim]  L3 Apply")
                yield Static("[dim]n[/dim]  New skill")
                yield Static("[dim]l[/dim]  Limits")
                yield Static("")
                yield Static("[dim]r[/dim] Refresh   [dim]?[/dim] Ask")
                yield Static("[dim]h[/dim] Help      [dim]q[/dim] Quit")
                yield Static("[dim]j[/dim] Jobs  [dim]v[/dim] Log  [dim]s[/dim] Notes")
            with Vertical(id="main"):
                yield ScrollableContainer(id="content")
        yield Footer()

    def on_mount(self) -> None:
        self._refresh_status_bar()
        self.action_view_projects()
        # v10.5.1: refresh status bar every 30s so cron updates / pending
        # proposals / gaming detection bubble up without manual reload.
        self.set_interval(30.0, self._refresh_status_bar)

    def _refresh_status_bar(self) -> None:
        """Composite live status: cron count, pending proposals, activity 24h,
        gaming/pause state. Rendered in one line below the header."""
        try:
            bar = self.query_one("#status-bar", Static)
        except Exception:
            return
        parts: list[str] = []

        # Cron jobs (cached check — schtasks call is ~50ms)
        try:
            r = subprocess.run(["schtasks", "/Query", "/FO", "CSV", "/NH"],
                               capture_output=True, text=True, timeout=5,
                               encoding="utf-8", errors="replace")
            if r.returncode == 0:
                n = sum(1 for ln in r.stdout.splitlines()
                        if "Ultron" in ln or "ULTRON" in ln)
                parts.append(f"[#9eca7e]●[/#9eca7e] {n} cron")
        except Exception:
            parts.append("[#d77878]●[/#d77878] cron?")

        # Pending L2 proposals
        try:
            pending = 0
            actionable = 0
            proposals_dir = COCKPIT_DIR / "proposals"
            if proposals_dir.exists():
                for f in proposals_dir.glob("*.json"):
                    if f.stem.endswith(".applied"):
                        continue
                    try:
                        d = json.loads(f.read_text(encoding="utf-8"))
                        if d.get("status") == "consumed":
                            continue
                        n = sum(1 for p in d.get("proposals", [])
                                if p.get("old_string")
                                and p.get("false_positive_risk") in (None, "none", "low"))
                        if n:
                            pending += 1
                            actionable += n
                    except (OSError, json.JSONDecodeError):
                        continue
            if actionable:
                parts.append(f"[#e0a868]⚠[/#e0a868] {actionable} patches pending")
            else:
                parts.append("[#555]—[/#555] no pending")
        except Exception:
            pass

        # Activity 24h
        try:
            count = 0
            if ACTIVITY_JSONL.exists():
                cutoff = datetime.now() - timedelta(days=1)
                for line in ACTIVITY_JSONL.read_text(encoding="utf-8").splitlines():
                    if not line.strip():
                        continue
                    try:
                        ts = datetime.fromisoformat(json.loads(line).get("ts", ""))
                        if ts >= cutoff:
                            count += 1
                    except (ValueError, json.JSONDecodeError):
                        continue
            parts.append(f"[#8aa8a0]▤[/#8aa8a0] {count} samples/24h")
        except Exception:
            pass

        # Gaming / pause state
        try:
            sys.path.insert(0, str(Path(__file__).parent))
            from should_run import gaming_or_paused
            skip, why = gaming_or_paused()
            if skip:
                parts.append(f"[#e0a868]⏸[/#e0a868] {why[:40]}")
        except Exception:
            pass

        # News freshness
        try:
            today_md = NEWS_DIR / f"{datetime.now():%Y-%m-%d}.md"
            if today_md.exists():
                parts.append("[#9eca7e]⌬[/#9eca7e] news today")
            else:
                parts.append("[#555]⌬[/#555] news stale")
        except Exception:
            pass

        bar.update("  ".join(parts))

    # ── View navigation ──────────────────────────────────────────────────────

    def _set_active_nav(self, view_name: str) -> None:
        for w in self.query(".nav-item"):
            w.remove_class("active")
        try:
            self.query_one(f"#nav-{view_name}", Static).add_class("active")
        except Exception:
            pass
        self.current_view = view_name

    def action_view_projects(self) -> None:
        self._set_active_nav("projects")
        self._render_projects()

    def action_view_personas(self) -> None:
        self._set_active_nav("personas")
        self._render_personas()

    def action_view_activity(self) -> None:
        self._set_active_nav("activity")
        self._render_activity()

    def action_view_news(self) -> None:
        self._set_active_nav("news")
        self._render_news()

    def action_view_auth(self) -> None:
        self._set_active_nav("auth")
        self._render_auth()

    def action_view_scheduler(self) -> None:
        self._set_active_nav("scheduler")
        self._render_scheduler()

    def action_view_health(self) -> None:
        self._set_active_nav("health")
        self._render_health()

    def action_view_mcps(self) -> None:
        self._set_active_nav("mcps")
        self._render_mcps()

    def action_view_usage(self) -> None:
        self._set_active_nav("usage")
        self._render_usage()

    def action_view_apps(self) -> None:
        self._set_active_nav("apps")
        self._render_apps()

    def action_view_autoupdater(self) -> None:
        self._set_active_nav("autoupdater")
        self._render_autoupdater()

    def action_view_jobs(self) -> None:
        self._set_active_nav("jobs")
        self._render_jobs()

    def action_view_changelog(self) -> None:
        self._set_active_nav("changelog")
        self._render_changelog()

    def action_view_notes(self) -> None:
        self._set_active_nav("notes")
        self._render_notes()

    def action_view_skills_market(self) -> None:
        self._set_active_nav("skills-market")
        self._render_skills_market()

    def action_quick_ask(self) -> None:
        self.push_screen(QuickAskModal())

    def action_edit_project(self) -> None:
        proj = self._get_selected_project()
        if not proj:
            self.notify("Select a project first (1 view + arrows)", severity="warning")
            return
        self.push_screen(ProjectEditModal(proj.get("id", "")))

    def action_delete_project(self) -> None:
        proj = self._get_selected_project()
        if not proj:
            self.notify("Select a project first (1 view + arrows)", severity="warning")
            return
        self.push_screen(DeleteProjectModal(proj.get("id", "")))

    def action_kirkardo_audit(self) -> None:
        # If on personas view, audit selected. Otherwise quick prompt.
        self.push_screen(KirkardoAuditModal())

    def action_session_gemini(self) -> None:
        """Spawn interactive Gemini session in current cwd."""
        proj = self._get_selected_project()
        cwd = proj.get("path") if proj else None
        open_in_terminal("gemini", cwd=cwd)
        self.notify("Spawned Gemini session", severity="information")

    def action_session_codex(self) -> None:
        """Spawn interactive Codex session in current cwd."""
        proj = self._get_selected_project()
        cwd = proj.get("path") if proj else None
        open_in_terminal("codex", cwd=cwd)
        self.notify("Spawned Codex session", severity="information")

    def action_new_skill(self) -> None:
        """Spawn `ultron skill create` Q&A flow in new terminal."""
        ultron_ps1 = Path(__file__).parent / "ultron.ps1"
        cmd = (f'powershell -NoProfile -ExecutionPolicy Bypass '
               f'-File "{ultron_ps1}" skill create')
        open_in_terminal(cmd, cwd=str(Path.home()))
        self.notify("New skill Q&A — see new terminal", severity="information")

    def action_limits_status(self) -> None:
        """Show current usage limits status (modal)."""
        self.push_screen(LimitsModal())

    def action_autoupdater_apply(self) -> None:
        """L3: spawn Claude session to review/apply latest proposals."""
        proposals_dir = COCKPIT_DIR / "proposals"
        if not proposals_dir.exists():
            self.notify("No proposals yet — generate via 'k' Kirkardo + L2 propose",
                         severity="warning")
            return
        proposals = sorted(proposals_dir.glob("*.json"),
                            key=lambda p: p.stat().st_mtime, reverse=True)
        if not proposals:
            self.notify("No proposals yet", severity="warning")
            return
        latest = proposals[0]
        # Spawn ultron self-improve apply <latest>
        ultron_ps1 = Path(__file__).parent / "ultron.ps1"
        cmd = (f'powershell -NoProfile -ExecutionPolicy Bypass '
               f'-File "{ultron_ps1}" self-improve apply "{latest}"')
        open_in_terminal(cmd, cwd=str(Path.home()))
        self.notify(f"L3 Apply session spawned for {latest.stem}",
                     severity="information")

    # ── Renderers ────────────────────────────────────────────────────────────

    def _clear_content(self):
        """Remove all children synchronously to avoid DuplicateIds when re-rendering."""
        content = self.query_one("#content", ScrollableContainer)
        # remove_children() is synchronous and clears the ID registry properly
        try:
            content.remove_children()
        except Exception:
            for child in list(content.children):
                try:
                    child.remove()
                except Exception:
                    pass
        return content

    def _render_projects(self):
        content = self._clear_content()
        projects = load_projects()
        active = [p for p in projects if p.get("status") in ("active", "auto-detected", "manual")]

        # v10.6.2: sort by usage (samples last 7d) DESC, fall back to
        # last_active for projects with no activity yet. Matches the dashboard
        # rule and surfaces the projects Rodrigo actually touches.
        from collections import Counter as _Counter
        activity = load_activity(days=7)
        usage = _Counter(e.get("project_id") for e in activity
                         if e.get("project_id"))
        active.sort(
            key=lambda p: (
                usage.get(p.get("id", ""), 0),
                p.get("last_active") or "0000",
            ),
            reverse=True,
        )

        content.mount(Static(f"[b]Projects[/b] [dim]({len(active)} active of {len(projects)} total · sorted by usage 7d)[/dim]", classes="title"))
        content.mount(Static("[dim]Select with ↑↓, then 'o' open · 'a' ask · 't' triple · 'c' claude[/dim]", classes="subtitle"))

        table = DataTable(cursor_type="row", zebra_stripes=True)
        table.add_columns("ID", "Name", "IDE", "Use 7d", "Last Active", "Tags")
        for p in active[:40]:
            n = usage.get(p.get("id", ""), 0)
            table.add_row(
                p.get("id", "?"),
                p.get("name", "?")[:30],
                p.get("ide", "?"),
                str(n) if n else "·",
                p.get("last_active", "—"),
                ", ".join(dict.fromkeys(p.get("tags", []) + p.get("auto_tags", [])))[:30],
            )
        content.mount(table)

    def _render_personas(self):
        content = self._clear_content()
        content.mount(Static("[b]Personas[/b] [dim](14)[/dim]", classes="title"))
        content.mount(Static("[dim]Select then Enter to open Claude with persona prompt[/dim]", classes="subtitle"))
        table = DataTable(cursor_type="row", zebra_stripes=True)
        table.add_columns("Slug", "Description")
        for slug, desc in PERSONAS:
            table.add_row(slug, desc)
        content.mount(table)

    def _render_activity(self):
        content = self._clear_content()
        activity = load_activity(days=7)

        content.mount(Static(f"[b]Activity[/b] [dim](last 7 days, {len(activity)} samples)[/dim]", classes="title"))

        if not activity:
            content.mount(Static("[yellow]No activity samples yet.[/yellow] Cron 'UltronTrackActivity' runs every 10 min.", classes="warning"))
            return

        # Counts by project (v10.5: idle entries → '(idle)' label, not None)
        from collections import Counter
        by_project: Counter = Counter()
        for e in activity:
            pid = e.get("project_id")
            by_project[pid if pid else "(idle)"] += 1
        content.mount(Static("[b]By project:[/b] [dim]((idle) = no project detected)[/dim]"))
        max_c = max(by_project.values()) if by_project else 1
        for pid, count in by_project.most_common(8):
            bar = "█" * int((count / max_c) * 30)
            content.mount(Static(f"  {pid:<28} [#8aa8a0]{bar}[/#8aa8a0] {count}"))

        # Heatmap by hour
        content.mount(Static(""))
        content.mount(Static("[b]Hour-of-day heatmap (last 7d):[/b]"))
        by_hour = Counter()
        for e in activity:
            try:
                ts = datetime.fromisoformat(e.get("ts", ""))
                by_hour[ts.hour] += 1
            except Exception:
                continue
        max_h = max(by_hour.values()) if by_hour else 1
        for h in range(24):
            c = by_hour.get(h, 0)
            bar = "█" * int((c / max_h) * 24)
            color = "#9eca7e" if c >= max_h * 0.6 else ("#e0a868" if c >= max_h * 0.3 else "#2a2a2a")
            content.mount(Static(f"  {h:02d}h │[{color}]{bar:<24}[/{color}] {c}"))

        # Today's timeline
        content.mount(Static(""))
        content.mount(Static("[b]Today's project timeline:[/b]"))
        today = datetime.now().date()
        today_entries = [e for e in activity if datetime.fromisoformat(e.get("ts", "")).date() == today]
        if today_entries:
            today_entries.sort(key=lambda e: e.get("ts", ""))
            for e in today_entries[-10:]:
                ts = datetime.fromisoformat(e.get("ts", "")).strftime("%H:%M")
                pid = e.get("project_id") or "(idle)"
                content.mount(Static(f"  [dim]{ts}[/dim]  {_markup_escape(pid):<24}  ({_markup_escape(e.get('source', '?'))!s})"))
        else:
            content.mount(Static("  [dim]No activity yet today[/dim]", classes="muted"))

    def _render_news(self):
        """v11.1 News: compact digest view + 2-button newsletter."""
        import re as _re
        content = self._clear_content()
        today = datetime.now().strftime("%Y-%m-%d")
        digest = NEWS_DIR / f"{today}.md"
        research = NEWS_DIR / f"research-{today}.md"

        content.mount(Static("[b]⌬ News[/b]", classes="title"))

        digest_text = ""
        try:
            if digest.exists():
                digest_text = digest.read_text(encoding="utf-8")
        except OSError:
            pass

        item_count = breaking_count = 0
        generated_str = ""
        tldr_block = ""
        breaking_lines: list[str] = []
        items_by_source: dict[str, list[str]] = {}
        if digest_text:
            m = _re.search(r"Generated\s+(\S+)\s*\|\s*(\d+)\s*items?\s*\|\s*(\d+)\s*new", digest_text)
            if m:
                generated_str = m.group(1)
                item_count = int(m.group(2))
            tldr_match = _re.search(r"##\s*TL;DR\s*\n\n((?:- .+\n?)+)", digest_text)
            if tldr_match:
                tldr_block = tldr_match.group(1).strip()
            br_section = _re.search(r"##\s*Breaking changes\s*\n\n((?:- .+\n?)+)", digest_text)
            if br_section:
                breaking_lines = [ln for ln in br_section.group(1).splitlines()
                                   if ln.startswith("- ")]
                breaking_count = len(breaking_lines)
            for src_match in _re.finditer(r"###\s*([^\n]+)\n((?:- .+\n?)+)", digest_text):
                src = src_match.group(1).strip()
                lines = [ln for ln in src_match.group(2).splitlines() if ln.startswith("- ")]
                if lines:
                    items_by_source[src] = lines[:2]

        alerts_count = 0
        try:
            if NEWS_ALERTS.exists():
                alerts_count = sum(
                    1 for ln in NEWS_ALERTS.read_text(encoding="utf-8").splitlines()
                    if ln.startswith("- "))
        except OSError:
            pass

        status_parts = []
        if generated_str:
            status_parts.append(f"[#9eca7e]●[/#9eca7e] {_markup_escape(generated_str[:16])}")
        else:
            status_parts.append("[#d77878]●[/#d77878] no digest today")
        status_parts.append(f"{item_count} items")
        if breaking_count:
            status_parts.append(f"[#e0a868]⚠ {breaking_count} breaking[/#e0a868]")
        if alerts_count:
            status_parts.append(f"[#d77878]🚨 {alerts_count} alerts[/#d77878]")
        if research.exists():
            status_parts.append("[#8aa8a0]🔬 research[/#8aa8a0]")
        content.mount(Static("  ·  ".join(status_parts), classes="subtitle"))

        content.mount(Static(""))
        if tldr_block:
            content.mount(Static("[b #ffd089]TL;DR (Gemini)[/b #ffd089]"))
            for tl in tldr_block.splitlines():
                if tl.startswith("- "):
                    content.mount(Static(f"  · {_markup_escape(tl[2:])}"))
                elif tl.strip():
                    content.mount(Static(f"  {_markup_escape(tl)}"))
        else:
            content.mount(Static("[dim]TL;DR not available — run news scraper first.[/dim]",
                                  classes="muted"))

        if breaking_lines:
            content.mount(Static(""))
            content.mount(Static(f"[b red]⚠ Breaking ({len(breaking_lines)})[/b red]"))
            for ln in breaking_lines[:5]:
                content.mount(Static(f"  [red]·[/red] {_markup_escape(ln[2:])}"))
            if len(breaking_lines) > 5:
                content.mount(Static(f"  [dim]+{len(breaking_lines)-5} more[/dim]",
                                      classes="muted"))

        if items_by_source:
            content.mount(Static(""))
            content.mount(Static("[b]Top items[/b]"))
            for src, lines in list(items_by_source.items())[:8]:
                content.mount(Static(f"[#8aa8a0]  › {_markup_escape(src)}[/#8aa8a0]"))
                for ln in lines:
                    content.mount(Static(f"    {_markup_escape(ln[2:][:120])}"))

        # Newsletter status
        newsletter_html = NEWS_DIR / f"newsletter-{today}.html"
        content.mount(Static(""))
        if newsletter_html.exists():
            content.mount(Static(
                f"[#9eca7e]✓ Newsletter generado[/#9eca7e]  [dim]{newsletter_html.name}[/dim]"))
        else:
            content.mount(Static("[dim]No newsletter hoy — genera con el botón[/dim]",
                                  classes="muted"))

        content.mount(Static(""))
        content.mount(Button("📰 Crear Newsletter del Día (con Diseño)",
                              id="news-create-newsletter", variant="primary"))
        content.mount(Button("🔄 Reiniciar Newsletter",
                              id="news-reset-newsletter", variant="default"))

    @work(thread=True)
    def _do_create_newsletter(self) -> None:
        """Generate newsletter via Gemini 3.1 → .md + .html → open browser."""
        import shutil as _shutil
        import subprocess as _subprocess
        import webbrowser as _webbrowser
        today = datetime.now().strftime("%Y-%m-%d")
        digest = NEWS_DIR / f"{today}.md"

        digest_content = ""
        try:
            if digest.exists():
                digest_content = digest.read_text(encoding="utf-8")
        except OSError:
            pass

        if not digest_content:
            self.app.call_from_thread(
                lambda: self.notify("No hay digest hoy — ejecuta 'ultron news' primero",
                                    severity="warning"))
            return

        self.app.call_from_thread(
            lambda: self.notify("Generando newsletter con Gemini 3.1...",
                                severity="information"))

        gemini_bin = _shutil.which("gemini")
        if not gemini_bin:
            self.app.call_from_thread(
                lambda: self.notify("gemini CLI no encontrado en PATH", severity="error"))
            return

        instruction = (
            "Eres el redactor del newsletter diario de ULTRON — sistema AI de Rodrigo "
            "(desarrollador indie, Madrid). Basándote en el digest de noticias AI de hoy "
            "(recibido por stdin), genera un newsletter en español con estas secciones:\n"
            "## 1. Editorial\n"
            "3-4 líneas narrativas sobre el día en AI.\n"
            "## 2. Top 5 Noticias\n"
            "Las 5 más relevantes con análisis breve de impacto en Claude Code / LLMs.\n"
            "## 3. Impacto en ULTRON\n"
            "1-2 bullets: modelos, herramientas o workflows afectados.\n"
            "## 4. Acciones Recomendadas\n"
            "1-3 bullets concretos: actualizar, explorar, ignorar.\n\n"
            "Formato: markdown limpio. Sé conciso pero sustantivo."
        )

        try:
            r = _subprocess.run(
                [gemini_bin, "--approval-mode", "plan", "-m", "gemini-3.1-pro-preview",
                 "-p", instruction],
                input=digest_content,
                capture_output=True, text=True, timeout=180, encoding="utf-8",
            )
            md_output = (r.stdout or "").strip()
            if not md_output or len(md_output) < 100:
                err = (r.stderr or "")[:200]
                msg = f"Gemini sin output (exit {r.returncode}): {err}"
                self.app.call_from_thread(
                    lambda m=msg: self.notify(m, severity="error"))
                return
        except _subprocess.TimeoutExpired:
            self.app.call_from_thread(
                lambda: self.notify("Gemini timeout (180s)", severity="error"))
            return
        except Exception as e:
            msg = f"Error Gemini: {e}"
            self.app.call_from_thread(
                lambda m=msg: self.notify(m, severity="error"))
            return

        NEWS_DIR.mkdir(parents=True, exist_ok=True)
        md_path = NEWS_DIR / f"newsletter-{today}.md"
        md_path.write_text(md_output, encoding="utf-8")

        html_content = _newsletter_md_to_html(md_output, today)
        html_path = NEWS_DIR / f"newsletter-{today}.html"
        html_path.write_text(html_content, encoding="utf-8")

        _webbrowser.open(html_path.as_uri())

        chars = len(md_output)
        self.app.call_from_thread(
            lambda: self.notify(f"Newsletter listo ({chars} chars) — abierto en browser",
                                severity="information"))
        self.app.call_from_thread(self._render_news)

    def _render_skills_market(self):
        """f key — Find Skills & Agents: installed, cached, GitHub discovery."""
        content = self._clear_content()
        content.mount(Static("[b]⬡ Find Skills & Agents[/b]", classes="title"))
        content.mount(Static("[dim]Community skills — buscar, instalar, insertar en routing[/dim]",
                              classes="subtitle"))

        # ── Installed skills ───────────────────────────────────────────────
        skills_dir = Path.home() / ".claude" / "skills"
        installed: list[str] = []
        if skills_dir.exists():
            installed = sorted(
                d.name for d in skills_dir.iterdir()
                if d.is_dir() and (d / "SKILL.md").exists()
            )
        content.mount(Static(""))
        content.mount(Static(f"[b #9eca7e]Instaladas ({len(installed)})[/b #9eca7e]"))
        if installed:
            chunks = [installed[i:i+5] for i in range(0, len(installed), 5)]
            for chunk in chunks[:4]:
                content.mount(Static("  " + "  ·  ".join(
                    f"[cyan]{_markup_escape(s)}[/cyan]" for s in chunk)))
            if len(chunks) > 4:
                content.mount(Static(f"  [dim]+{len(installed) - 20} más...[/dim]",
                                      classes="muted"))
        else:
            content.mount(Static("  [dim]None[/dim]", classes="muted"))

        # ── Cached skills (skill_cache) ────────────────────────────────────
        cache_dir = Path.home() / ".ultron" / "skill_cache"
        cached: list[tuple[str, str]] = []  # (name, cached_at)
        if cache_dir.exists():
            for d in sorted(cache_dir.iterdir()):
                if not d.is_dir():
                    continue
                meta_file = d / "meta.json"
                meta: dict = {}
                try:
                    if meta_file.exists():
                        import json as _json
                        meta = _json.loads(meta_file.read_text(encoding="utf-8"))
                except Exception:
                    pass
                cached_at = meta.get("cached_at", "?")[:16]
                cached.append((d.name, cached_at))

        content.mount(Static(""))
        content.mount(Static(f"[b #ffd089]Cache local ({len(cached)})[/b #ffd089]"))
        if cached:
            for name, cat in cached[:8]:
                inst_mark = "[#9eca7e] ✓[/#9eca7e]" if (skills_dir / name).exists() else ""
                content.mount(Static(
                    f"  [cyan]{_markup_escape(name):<28}[/cyan]"
                    f"[dim]{cat}[/dim]{inst_mark}"))
            if len(cached) > 8:
                content.mount(Static(f"  [dim]+{len(cached)-8} more in cache[/dim]",
                                      classes="muted"))
        else:
            content.mount(Static("  [dim]Cache vacío[/dim]", classes="muted"))

        # ── Skills registry ────────────────────────────────────────────────
        registry_path = COCKPIT_DIR / "skills-registry.json"
        registry: list[dict] = []
        try:
            if registry_path.exists():
                import json as _json
                data = _json.loads(registry_path.read_text(encoding="utf-8"))
                registry = data.get("skills", [])
        except Exception:
            pass

        if registry:
            content.mount(Static(""))
            content.mount(Static(f"[b #8aa8a0]Registro ({len(registry)})[/b #8aa8a0]"))
            for entry in registry[:6]:
                name = entry.get("name", "?")
                src = entry.get("source", "")
                inst = "[#9eca7e]✓[/#9eca7e] " if (skills_dir / name).exists() else "  "
                content.mount(Static(
                    f"  {inst}[cyan]{_markup_escape(name):<28}[/cyan]"
                    f"[dim]{_markup_escape(src[:40])}[/dim]"))

        # ── Action buttons ─────────────────────────────────────────────────
        content.mount(Static(""))
        content.mount(Button("🔍 Buscar Skills en GitHub",
                              id="skills-search-github", variant="default"))
        content.mount(Button("🤖 Descubrir con Gemini (top community skills)",
                              id="skills-discover-gemini", variant="primary"))
        content.mount(Button("📥 Instalar todas del Cache",
                              id="skills-install-cache", variant="default"))
        content.mount(Button("⟳ Insertar en Routing (Claude session)",
                              id="skills-insert-routing", variant="warning"))
        content.mount(Button("🗑 Limpiar Cache (>7 días)",
                              id="skills-clean-cache", variant="default"))

    @work(thread=True)
    def _do_discover_skills_gemini(self) -> None:
        """Ask Gemini 3.1 to find top community Claude Code skills, save to registry."""
        import shutil as _shutil
        import subprocess as _subprocess
        import json as _json
        self.app.call_from_thread(
            lambda: self.notify("Preguntando a Gemini por las mejores community skills...",
                                severity="information"))

        gemini_bin = _shutil.which("gemini")
        if not gemini_bin:
            self.app.call_from_thread(
                lambda: self.notify("gemini CLI no encontrado en PATH", severity="error"))
            return

        instruction = (
            "Eres un experto en Claude Code y su ecosistema de skills.\n"
            "Busca en internet y dame las TOP 10 community skills de Claude Code disponibles en GitHub.\n"
            "Para cada skill incluye:\n"
            "- nombre (slug kebab-case)\n"
            "- descripción en 1 línea\n"
            "- URL raw de SKILL.md en GitHub (formato: https://raw.githubusercontent.com/...)\n\n"
            "Responde SOLO con JSON válido, sin texto adicional, con este schema:\n"
            '{\"skills\": [{\"name\": \"skill-name\", \"description\": \"...\", '
            '\"raw_url\": \"https://...\", \"repo\": \"user/repo\"}]}'
        )

        try:
            r = _subprocess.run(
                [gemini_bin, "--approval-mode", "plan", "-m", "gemini-3.1-pro-preview",
                 "-p", instruction],
                capture_output=True, text=True, timeout=120, encoding="utf-8",
            )
            output = (r.stdout or "").strip()
        except _subprocess.TimeoutExpired:
            self.app.call_from_thread(
                lambda: self.notify("Gemini timeout (120s)", severity="error"))
            return
        except Exception as e:
            msg = f"Error Gemini: {e}"
            self.app.call_from_thread(lambda m=msg: self.notify(m, severity="error"))
            return

        # Try to parse JSON from output
        skills: list[dict] = []
        try:
            import re as _re
            json_match = _re.search(r'\{[\s\S]*\}', output)
            if json_match:
                data = _json.loads(json_match.group())
                skills = data.get("skills", [])
        except Exception:
            pass

        if not skills:
            # Save raw output as text for user to review
            raw_path = COCKPIT_DIR / "skills-gemini-raw.txt"
            raw_path.write_text(output or "(no output)", encoding="utf-8")
            self.app.call_from_thread(
                lambda: self.notify(
                    f"Gemini respondió pero sin JSON parseable — guardado en skills-gemini-raw.txt",
                    severity="warning"))
            return

        # Save registry
        COCKPIT_DIR.mkdir(parents=True, exist_ok=True)
        registry_path = COCKPIT_DIR / "skills-registry.json"
        existing: dict = {"skills": []}
        try:
            if registry_path.exists():
                existing = _json.loads(registry_path.read_text(encoding="utf-8"))
        except Exception:
            pass
        existing_names = {s.get("name") for s in existing.get("skills", [])}
        for sk in skills:
            if sk.get("name") and sk["name"] not in existing_names:
                sk["source"] = sk.get("repo", "gemini-discovery")
                sk["discovered"] = datetime.now().strftime("%Y-%m-%d")
                existing["skills"].append(sk)
                existing_names.add(sk["name"])
        existing["last_updated"] = datetime.now().isoformat()
        registry_path.write_text(
            _json.dumps(existing, indent=2, ensure_ascii=False), encoding="utf-8")

        count = len(skills)
        self.app.call_from_thread(
            lambda: self.notify(f"Gemini encontró {count} skills — guardadas en registro",
                                severity="information"))
        self.app.call_from_thread(self._render_skills_market)

    @work(thread=True)
    def _do_install_all_cached_skills(self) -> None:
        """Install all skills from skill_cache that aren't installed yet."""
        import shutil as _shutil
        import subprocess as _subprocess
        cache_dir = Path.home() / ".ultron" / "skill_cache"
        skills_dir = Path.home() / ".claude" / "skills"
        if not cache_dir.exists():
            self.app.call_from_thread(
                lambda: self.notify("Cache vacío — busca skills primero", severity="warning"))
            return

        installed_count = 0
        skipped_count = 0
        for d in sorted(cache_dir.iterdir()):
            if not d.is_dir():
                continue
            dest = skills_dir / d.name
            if dest.exists():
                skipped_count += 1
                continue
            skill_md = d / "SKILL.md"
            if skill_md.exists():
                dest.mkdir(parents=True, exist_ok=True)
                _shutil.copy2(skill_md, dest / "SKILL.md")
                installed_count += 1

        msg = f"Instaladas {installed_count} skills ({skipped_count} ya existían)"
        self.app.call_from_thread(
            lambda m=msg: self.notify(m, severity="information"))
        self.app.call_from_thread(self._render_skills_market)

    def _render_auth(self):
        content = self._clear_content()
        content.mount(Static("[b]Auth Vault[/b] [dim](DPAPI)[/dim]", classes="title"))
        vault = load_vault_summary()
        if not vault:
            content.mount(Static("[yellow]Vault empty.[/yellow] Use Wizard New below to add."))
        else:
            table = DataTable(cursor_type="row", zebra_stripes=True)
            table.add_columns("Service", "Active profile", "All profiles")
            for svc, info in sorted(vault.items()):
                table.add_row(svc, info["active"], ", ".join(info["profiles"]))
            content.mount(table)

        # Action buttons (v10.4.7 fix: mount one by one to avoid Horizontal crash)
        content.mount(Static(""))
        content.mount(Static("[b]Actions:[/b]", classes="title"))
        for btn in [
            Button("Add new profile (wizard)", id="auth-new", variant="primary"),
            Button("Switch active profile", id="auth-switch", variant="default"),
            Button("Show vault status", id="auth-status", variant="default"),
        ]:
            content.mount(btn)
        content.mount(Static(""))
        content.mount(Static("[dim]Wizard launches `ultron auth wizard new <service>` interactive Q&A in new terminal[/dim]",
                              classes="muted"))

    def _render_scheduler(self):
        content = self._clear_content()
        content.mount(Static("[b]Scheduler[/b] [dim](Task Scheduler - Ultron* tasks)[/dim]", classes="title"))
        content.mount(Static("[dim]Enter = run now - r = refresh[/dim]", classes="subtitle"))

        tasks = get_scheduled_tasks()
        if not tasks:
            content.mount(Static(
                "[yellow]No Ultron tasks detected via PowerShell.[/yellow]\n"
                "If you ran 'ultron schedule install' and they ARE installed, this may be a "
                "PS subprocess issue. Workaround: open [cyan]taskschd.msc[/cyan] manually.\n\n"
                "To install fresh: [cyan]ultron schedule install[/cyan]",
                classes="warning",
            ))
            return

        table = DataTable(cursor_type="row", zebra_stripes=True)
        table.add_columns("Task", "State", "Last run", "Next run", "Result")
        for t in tasks:
            state = t.get("state", "?") or "?"
            last = t.get("last_run") or ""
            if last and "1999" in last:
                last = "never"
            elif last:
                last = last[:16].replace("T", " ")
            else:
                last = "never"
            next_run = (t.get("next_run") or "")[:16].replace("T", " ")
            if not next_run:
                next_run = "-"
            res = t.get("last_result")
            if res == 0:
                result = "OK"
            elif res in (None, 0x41303):
                result = "-"
            else:
                try:
                    result = f"0x{res:X}" if isinstance(res, int) else str(res)
                except Exception:
                    result = "?"
            table.add_row(
                str(t.get("name", "?")),
                state, last, next_run, result,
            )
        content.mount(table)

        content.mount(Static(""))
        content.mount(Static("[b]Configured schedules (from schedule-config.json):[/b]"))
        _freq_labels = {
            "on_login": "on login",
            "every_10_minutes": "every 10min",
            "once_per_day": "once/day",
            "every_hour": "every 1h",
            "once_per_weekday": "weekdays",
            "once_per_week_sunday": "weekly (Sun)",
        }
        sched_config_path = COCKPIT_DIR / "schedule-config.json"
        try:
            sched_cfg = json.loads(sched_config_path.read_text(encoding="utf-8-sig"))
            for task_name, cfg in sched_cfg.get("tasks", {}).items():
                enabled = cfg.get("enabled", True)
                delay = cfg.get("delay_minutes", 0)
                freq = _freq_labels.get(cfg.get("frequency", ""), cfg.get("frequency", "?"))
                status_icon = "[green]●[/green]" if enabled else "[dim]○[/dim]"
                content.mount(Static(
                    f"  {status_icon} {task_name:<32} login+{delay}min  {freq}"
                ))
        except (OSError, json.JSONDecodeError):
            content.mount(Static("[dim]schedule-config.json not found — run: ultron schedule install[/dim]"))
        content.mount(Static(""))
        content.mount(Static("[b]Edit config:[/b] [cyan]notepad ~\\.ultron\\cockpit\\schedule-config.json[/cyan]"))
        content.mount(Static("[b]Apply changes:[/b] [cyan]ultron schedule install[/cyan]"))

        # Action buttons (v10.4.8)
        content.mount(Static(""))
        content.mount(Static("[b]Actions:[/b]", classes="title"))
        for btn in [
            Button("Edit AI (chat)", id="sched-edit", variant="primary"),
            Button("Install", id="sched-install", variant="warning"),
            Button("Status", id="sched-status", variant="default"),
        ]:
            content.mount(btn)

    def _render_health(self):
        content = self._clear_content()
        content.mount(Static("[b]System Health[/b]", classes="title"))

        # Cockpit dir size
        try:
            total = 0
            for p in COCKPIT_DIR.rglob("*"):
                if p.is_file():
                    total += p.stat().st_size
            mb = total / (1024 * 1024)
            color = "green" if mb < 50 else "yellow" if mb < 200 else "red"
            content.mount(Static(f"[b]Cockpit disk usage:[/b] [{color}]{mb:.1f} MB[/{color}]"))
        except Exception:
            content.mount(Static("[dim]Disk usage unavailable[/dim]"))

        # Files present
        critical = [
            (PROJECTS_JSON, "projects.json"),
            (ACTIVITY_JSONL, "activity.jsonl"),
            (AUTH_VAULT, "auth-vault.dpapi"),
            (NEWS_DIR, "news/"),
            (COCKPIT_DIR / "DASHBOARD.md", "DASHBOARD.md"),
        ]
        content.mount(Static(""))
        content.mount(Static("[b]Critical files:[/b]"))
        for path, name in critical:
            if path.exists():
                content.mount(Static(f"  [green]✓[/green] {name}"))
            else:
                content.mount(Static(f"  [red]✗[/red] {name} [dim](missing)[/dim]"))

        # Cron jobs summary
        tasks = get_scheduled_tasks()
        ready = sum(1 for t in tasks if t.get("state") == "Ready")
        total_t = len(tasks)
        content.mount(Static(""))
        content.mount(Static(f"[b]Scheduled tasks:[/b] [green]{ready}[/green] / [cyan]{total_t}[/cyan] Ready"))

        # CLIs: async to avoid UI freeze on cold-start CLIs (claude/codex/gemini can be slow)
        content.mount(Static(""))
        content.mount(Static("[b]CLI tools:[/b]"))
        content.mount(Static("[yellow]Checking CLIs...[/yellow]", id="health-cli-result"))
        self._check_clis_async()

    @work(thread=True, exclusive=True)
    def _check_clis_async(self) -> None:
        import shutil as _shutil
        npm_global = Path(os.environ.get("APPDATA", "")) / "npm"
        extra_paths = [str(npm_global)] if npm_global.exists() else []

        def _find_cli(name: str) -> str | None:
            found = _shutil.which(name)
            if found:
                return found
            for ext in (".cmd", ".ps1", ".exe", ""):
                for base in extra_paths:
                    candidate = Path(base) / f"{name}{ext}"
                    if candidate.exists():
                        return str(candidate)
            return None

        lines = []
        for cli in ("claude", "codex", "gemini", "git", "python"):
            cli_path = _find_cli(cli)
            if cli_path:
                try:
                    r = subprocess.run([cli_path, "--version"], capture_output=True,
                                       text=True, timeout=5)
                    ver = r.stdout.split("\n")[0][:60] if r.returncode == 0 else "(no version)"
                    lines.append(f"  [green]✓[/green] {cli:<10} [dim]{ver}[/dim]")
                except Exception as e:
                    lines.append(f"  [yellow]?[/yellow] {cli:<10} [dim]found but errored: {e}[/dim]")
            else:
                lines.append(f"  [red]✗[/red] {cli} [dim](not in PATH or %APPDATA%\\npm)[/dim]")

        self.call_from_thread(self._update_health_cli, "\n".join(lines))

    def _update_health_cli(self, text: str) -> None:
        try:
            self.query_one("#health-cli-result", Static).update(text)
        except Exception:
            pass

    # ── Actions on selection ─────────────────────────────────────────────────

    def _get_selected_project(self) -> dict | None:
        if self.current_view != "projects":
            return None
        try:
            tables = self.query(DataTable)
            for table in tables:
                if table.row_count == 0:
                    continue
                if table.cursor_row is None:
                    continue
                row = table.get_row_at(table.cursor_row)
                if not row:
                    continue
                project_id = str(row[0])
                for p in load_projects():
                    if p.get("id") == project_id:
                        return p
                break
        except Exception:
            return None
        return None

    def action_open_selected(self) -> None:
        if self.current_view != "projects":
            return
        proj = self._get_selected_project()
        if not proj:
            return
        # Use launch_project.py via subprocess
        script = Path(__file__).parent / "launch_project.py"
        subprocess.Popen([sys.executable, str(script), proj["id"]])

    def action_ask_persona(self) -> None:
        proj = self._get_selected_project() if self.current_view == "projects" else None
        self.push_screen(PersonaInvokerModal(project=proj))

    def action_triple_debate(self) -> None:
        proj = self._get_selected_project() if self.current_view == "projects" else None
        if not proj:
            return
        prompt = f'Ultron, /high /triple debate sobre el proyecto {proj.get("name")}'
        open_in_terminal(f'claude "{prompt}"', cwd=proj.get("path"))

    def action_claude_here(self) -> None:
        proj = self._get_selected_project() if self.current_view == "projects" else None
        if proj:
            open_in_terminal("claude", cwd=proj.get("path"))
        else:
            open_in_terminal("claude")

    # ── Scheduler actions ────────────────────────────────────────────────────

    def _get_selected_task(self) -> str | None:
        if self.current_view != "scheduler":
            return None
        try:
            tables = self.query(DataTable)
            for table in tables:
                if table.row_count == 0 or table.cursor_row is None:
                    continue
                row = table.get_row_at(table.cursor_row)
                if row:
                    return str(row[0])
        except Exception:
            return None
        return None

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle action buttons in News and Auth views (v10.4.4)."""
        bid = event.button.id or ""
        ult = Path(__file__).parent / "ultron.ps1"
        ps_prefix = f'powershell -NoProfile -ExecutionPolicy Bypass -File "{ult}"'
        # AutoUpdater actions
        if bid == "autoupd-full-ultron":
            open_in_terminal(f'{ps_prefix} self-improve full ultron')
            self.notify("🚀 Full pipeline ULTRON spawned (audit + propose + apply)",
                         severity="information")
            return
        if bid == "autoupd-scan":
            open_in_terminal(f'{ps_prefix} self-improve scan')
            self.notify("Scan spawned", severity="information")
            return
        if bid == "autoupd-audit":
            self.push_screen(KirkardoAuditModal())
            return
        if bid == "autoupd-propose":
            audits_dir = COCKPIT_DIR / "audits"
            audits = sorted(audits_dir.glob("*.md"),
                             key=lambda p: p.stat().st_mtime, reverse=True) \
                     if audits_dir.exists() else []
            if not audits:
                self.notify("No audits yet — run L1 first", severity="warning")
                return
            latest = audits[0]
            open_in_terminal(f'{ps_prefix} self-improve propose "{latest}"')
            self.notify(f"L2 propose spawned for {latest.stem}",
                         severity="information")
            return
        if bid == "autoupd-apply":
            self.action_autoupdater_apply()
            return
        if bid == "autoupd-apply-auto":
            # v10.5: mechanical L3 — finds latest pending proposals file and
            # spawns apply_proposals.py in a new terminal. No LLM, just deterministic
            # Edit application of unique-match proposals.
            proposals_dir = COCKPIT_DIR / "proposals"
            pending = []
            if proposals_dir.exists():
                for f in proposals_dir.glob("*.json"):
                    if f.stem.endswith(".applied"):
                        continue
                    try:
                        d = json.loads(f.read_text(encoding="utf-8"))
                        if d.get("status") == "consumed":
                            continue
                        pending.append(f)
                    except (OSError, json.JSONDecodeError):
                        continue
            if not pending:
                self.notify("No pending proposals (all consumed)",
                            severity="warning")
                return
            pending.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            latest = pending[0]
            apply_script = Path(__file__).parent / "apply_proposals.py"
            cmd = (f'python "{apply_script}" apply "{latest}"')
            open_in_terminal(cmd)
            self.notify(f"Mechanical L3 apply spawned for {latest.stem}",
                        severity="information")
            return
        if bid == "autoupd-newsflags":
            open_in_terminal(f'{ps_prefix} self-improve news-flags')
            self.notify("News-flags spawned", severity="information")
            return
        # Scheduler actions
        if bid == "sched-edit":
            self.push_screen(ScheduleEditModal())
            return
        if bid == "sched-install":
            open_in_terminal(f'{ps_prefix} schedule install')
            self.notify("Schedule install spawned", severity="information")
            return
        if bid == "sched-status":
            open_in_terminal(f'{ps_prefix} schedule status')
            return
        # MCPs actions
        if bid == "mcp-list":
            open_in_terminal(f'{ps_prefix} mcp list')
            return
        if bid == "mcp-install":
            self.push_screen(MCPActionModal(action="install"))
            return
        if bid == "mcp-uninstall":
            self.push_screen(MCPActionModal(action="uninstall"))
            return
        if bid == "mcp-validate":
            self.push_screen(MCPActionModal(action="validate"))
            return
        if bid == "mcp-scaffold":
            self.push_screen(MCPActionModal(action="scaffold"))
            return
        # News view
        if bid == "news-create-newsletter":
            self._do_create_newsletter()
        elif bid == "news-reset-newsletter":
            today = datetime.now().strftime("%Y-%m-%d")
            for ext in (".md", ".html"):
                p = NEWS_DIR / f"newsletter-{today}{ext}"
                if p.exists():
                    p.unlink()
            self.notify("Newsletter reiniciado", severity="information")
            self._render_news()
        # Skills market view
        elif bid == "skills-search-github":
            discover_script = Path(__file__).parent / "skill_discover.py"
            open_in_terminal(
                f'{sys.executable} "{discover_script}" search "claude code community skills"')
            self.notify("Búsqueda GitHub abierta en terminal", severity="information")
        elif bid == "skills-discover-gemini":
            self._do_discover_skills_gemini()
        elif bid == "skills-install-cache":
            self._do_install_all_cached_skills()
        elif bid == "skills-insert-routing":
            skills_dir = Path.home() / ".claude" / "skills"
            installed_names = sorted(
                d.name for d in skills_dir.iterdir()
                if d.is_dir() and (d / "SKILL.md").exists()
            ) if skills_dir.exists() else []
            routing_ctx = (
                "Eres ULTRON. Tarea: validar y actualizar el routing de skills en SKILL.md.\n"
                f"Skills instaladas en ~/.claude/skills/ ({len(installed_names)} total): "
                f"{', '.join(installed_names[:30])}\n"
                "1. Lee ~/.claude/skills/ultron/SKILL.md (Layer 2 — Plugin CC)\n"
                "2. Comprueba qué skills del routing NO están instaladas\n"
                "3. Para las que falten: instálalas con skill_discover.py si están en GitHub, "
                "o márcalas como 'NOT INSTALLED' en SKILL.md con comentario\n"
                "4. Para nuevas skills instaladas no en routing: añade entrada con señal\n"
                "5. Valida que los subagent_type en Layer 2 existen realmente"
            )
            open_in_terminal(f'claude --print --dangerously-skip-permissions "{routing_ctx}"')
            self.notify("Claude session abierta para insertar skills en routing",
                         severity="information")
        elif bid == "skills-clean-cache":
            discover_script = Path(__file__).parent / "skill_discover.py"
            open_in_terminal(f'{sys.executable} "{discover_script}" clean')
            self.notify("Cache clean abierto en terminal", severity="information")
            self._render_skills_market()
        # Auth view
        elif bid == "auth-new":
            # Wizard needs interactive Q&A — spawn in new terminal
            # No hardcoded service: script prompts interactively
            cmd = (f'{ps_prefix} auth wizard new')
            open_in_terminal(cmd)
            self.notify("Spawned auth wizard — enter service name in terminal",
                         severity="information")
        elif bid == "auth-switch":
            open_in_terminal(f'{ps_prefix} auth list')
            self.notify("Auth list spawned (manual switch via terminal)",
                         severity="information")
        elif bid == "auth-status":
            open_in_terminal(f'{ps_prefix} auth status')
    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        if self.current_view == "scheduler":
            task = self._get_selected_task()
            if task and task.startswith("Ultron"):
                if trigger_scheduled_task(task):
                    self.notify(f"Triggered {task}", severity="information")
                else:
                    self.notify(f"Failed to trigger {task}", severity="error")
        elif self.current_view == "personas":
            self.push_screen(PersonaInvokerModal(project=None))

    # ── v10.4 New view renderers ────────────────────────────────────────────

    def _render_mcps(self):
        content = self._clear_content()
        content.mount(Static("[b]MCPs[/b] [dim](catalog + installed + scaffold)[/dim]",
                              classes="title"))
        content.mount(Static("[dim]ultron mcp list/install/uninstall/validate · scaffold (Sonnet)[/dim]",
                              classes="subtitle"))
        # Catalog
        catalog_path = COCKPIT_DIR / "mcp-catalog.json"
        try:
            cat = json.loads(catalog_path.read_text(encoding="utf-8-sig"))
            mcps = cat.get("mcps", [])
            content.mount(Static(f"[b]Catalog ({len(mcps)} MCPs)[/b]", classes="title"))
            table = DataTable(cursor_type="row", zebra_stripes=True)
            table.add_columns("ID", "Category", "Name", "Multi-acc")
            for m in mcps:
                table.add_row(
                    m.get("id", "?"),
                    m.get("category", "?"),
                    m.get("name", "?")[:30],
                    "yes" if m.get("multi_account") else "no",
                )
            content.mount(table)
        except (OSError, json.JSONDecodeError) as e:
            content.mount(Static(f"[yellow]Catalog read error: {e}[/yellow]"))
        # Installed
        settings_path = Path(os.environ.get("USERPROFILE", "~")) / ".claude" / "settings.json"
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8-sig"))
            installed = list(settings.get("mcpServers", {}).keys())
            content.mount(Static(""))
            content.mount(Static(f"[b]Installed ({len(installed)})[/b]", classes="title"))
            for s in installed:
                content.mount(Static(f"  ✓ {s}"))
        except (OSError, json.JSONDecodeError):
            content.mount(Static("[dim]No MCPs in settings.json[/dim]"))
        content.mount(Static(""))
        content.mount(Static("[b]Commands:[/b]"))
        content.mount(Static("  [cyan]ultron mcp install <id>[/cyan]    install from catalog"))
        content.mount(Static("  [cyan]ultron mcp scaffold <idea>[/cyan] scaffold new MCP server (Sonnet)"))
        content.mount(Static("  [cyan]ultron mcp validate <id>[/cyan]   JSON-RPC handshake test"))

        # Action buttons (v10.4.9)
        content.mount(Static(""))
        content.mount(Static("[b]Actions:[/b]", classes="title"))
        for btn in [
            Button("List installed servers", id="mcp-list", variant="primary"),
            Button("Install server…", id="mcp-install", variant="warning"),
            Button("Uninstall server…", id="mcp-uninstall", variant="default"),
            Button("Validate server…", id="mcp-validate", variant="default"),
            Button("Scaffold new server…", id="mcp-scaffold", variant="primary"),
        ]:
            content.mount(btn)

    def _render_usage(self):
        content = self._clear_content()
        content.mount(Static("[b]Session Usage[/b] [dim](5h rolling + weekly subscription)[/dim]",
                              classes="title"))
        content.mount(Static("[dim]ultron usage [--json] · ultron usage live → /usage oficial[/dim]",
                              classes="subtitle"))
        script = Path(__file__).parent / "usage_tracker.py"
        try:
            r = subprocess.run([sys.executable, str(script), "--json"],
                                capture_output=True, text=True,
                                timeout=30, encoding="utf-8")
            data = json.loads(r.stdout)
        except Exception as e:
            content.mount(Static(f"[red]Usage tracker failed: {e}[/red]"))
            content.mount(Static("[dim]Run: ultron usage live  →  claude /usage (datos oficiales)[/dim]"))
            return

        for label, key in [("5h Rolling", "5h_rolling"), ("Weekly", "weekly")]:
            agg = data.get(key, {})
            t = agg.get("total", {})
            count = t.get("count", 0)
            load = t.get("load", 0)
            content.mount(Static(""))
            content.mount(Static(f"[b cyan]{label}[/b cyan]: {count} turns  "
                                  f"[dim](load index {load})[/dim]"))
            by_model = agg.get("by_model") or {}
            for model, bm in sorted(by_model.items(),
                                     key=lambda x: -x[1].get("load", 0)):
                mc = bm.get("count", 0)
                ml = bm.get("load", 0)
                content.mount(Static(f"  {_markup_escape(model):<28} {mc:>4} turns  "
                                      f"[dim](load {ml})[/dim]"))
            by_source = agg.get("by_source") or {}
            for src, bs in sorted(by_source.items()):
                sc = bs.get("count", 0)
                content.mount(Static(f"  [dim]via {_markup_escape(src):<24}[/dim]  {sc:>4} turns"))

        scanned = data.get("scanned_turns", 0)
        content.mount(Static(""))
        content.mount(Static(f"[dim]Scanned {scanned} turns from local JSONL files · "
                              f"Gemini: not tracked[/dim]"))
        content.mount(Static("[dim]Para datos oficiales: ultron usage live[/dim]"))

    def _render_apps(self):
        content = self._clear_content()
        content.mount(Static("[b]Apps[/b] [dim](GUI launcher)[/dim]",
                              classes="title"))
        content.mount(Static("[dim]ultron app <name> · ultron apps list/discover/add[/dim]",
                              classes="subtitle"))
        apps_path = COCKPIT_DIR / "apps.json"
        try:
            data = json.loads(apps_path.read_text(encoding="utf-8-sig"))
            apps = data.get("apps", {})
        except (OSError, json.JSONDecodeError):
            content.mount(Static("[yellow]No apps registered. "
                                  "Run: ultron apps discover[/yellow]"))
            return
        content.mount(Static(""))
        content.mount(Static(f"[b]Registered ({len(apps)})[/b]"))
        table = DataTable(cursor_type="row", zebra_stripes=True)
        table.add_columns("Name", "Label", "Path exists")
        for name in sorted(apps):
            a = apps[name]
            path = a.get("path", "")
            ok = "✓" if path and Path(path).exists() else "✗"
            table.add_row(name, a.get("label", "")[:30], ok)
        content.mount(table)
        content.mount(Static(""))
        content.mount(Static("[b]Launch:[/b] [cyan]ultron app <name>[/cyan] from terminal"))

    def _render_autoupdater(self):
        import re as _re
        content = self._clear_content()
        content.mount(Static("[b]AutoUpdater[/b] [dim](Kirkardo audits + L2 proposals + Skills status)[/dim]",
                              classes="title"))
        content.mount(Static("[dim]'k' Kirkardo audit · ultron self-improve scan/propose/proposals[/dim]",
                              classes="subtitle"))

        # ── A. ALL skills with latest audit score ─────────────────────────
        skills_dir = Path.home() / ".claude" / "skills"
        audits_dir = COCKPIT_DIR / "audits"
        content.mount(Static(""))
        content.mount(Static("[b]Skills Status (todas)[/b]"))

        # Build audit index: skill_name → (date, nota, veredicto, is_triple)
        audit_index: dict[str, tuple[str, str, str, bool]] = {}
        if audits_dir.exists():
            for af in audits_dir.glob("*.md"):
                m = _re.match(r"^(.+?)-(\d{4}-\d{2}-\d{2})\.md$", af.name)
                if not m:
                    continue
                skill_name = m.group(1)
                date_str = m.group(2)
                try:
                    head = af.read_text(encoding="utf-8")[:800]
                except OSError:
                    continue
                nm = _re.search(r"nota:\s*([\d.]+)/10", head)
                vm = _re.search(r"veredicto:\s*([^\n]+)", head)
                nota = nm.group(1) if nm else "?"
                ver = vm.group(1).strip()[:25] if vm else "?"
                is_triple = "triple" in head.lower() or "codex" in head[:200].lower()
                # Keep most recent per skill
                if skill_name not in audit_index or date_str > audit_index[skill_name][0]:
                    audit_index[skill_name] = (date_str, nota, ver, is_triple)

        # Collect all skills
        skill_entries: list[tuple[str, str, str, str, bool, bool]] = []
        # (name, date, nota, ver, is_triple, is_new)
        cutoff_new = datetime.now() - timedelta(days=45)
        if skills_dir.exists():
            for sd in sorted(skills_dir.iterdir()):
                if not sd.is_dir():
                    continue
                skill_md = sd / "SKILL.md"
                if not skill_md.exists():
                    continue
                name = sd.name
                try:
                    ctime = datetime.fromtimestamp(skill_md.stat().st_ctime)
                    is_new = ctime >= cutoff_new
                except OSError:
                    is_new = False
                if name in audit_index:
                    date_str, nota, ver, is_triple = audit_index[name]
                else:
                    date_str, nota, ver, is_triple = ("never", "—", "no audit", False)
                skill_entries.append((name, date_str, nota, ver, is_triple, is_new))

        # Table: Name | Last Audit | Nota | Veredicto | Flags
        table = DataTable(cursor_type="row", zebra_stripes=True)
        table.add_columns("Skill", "Last Audit", "Nota", "Veredicto", "Flags")
        for name, date_str, nota, ver, is_triple, is_new in skill_entries:
            # Nota color
            if nota == "—":
                nota_str = "[dim]—[/dim]"
            else:
                try:
                    n_val = float(nota)
                    if n_val >= 9:
                        nota_str = f"[green]{nota}/10[/green]"
                    elif n_val >= 7:
                        nota_str = f"[yellow]{nota}/10[/yellow]"
                    else:
                        nota_str = f"[red]{nota}/10[/red]"
                except ValueError:
                    nota_str = nota
            flags = []
            if is_new:
                flags.append("[#ffd089]NEW[/#ffd089]")
            if is_triple:
                flags.append("[cyan]3x[/cyan]")
            if date_str == "never":
                flags.append("[red]⚠ unaudited[/red]")
            table.add_row(
                name[:28],
                date_str,
                nota_str,
                ver[:22],
                " ".join(flags) if flags else "",
            )
        content.mount(table)

        # ── B. Alignment check: newly added skills ────────────────────────
        new_skills = [e for e in skill_entries if e[5]]
        if new_skills:
            content.mount(Static(""))
            content.mount(Static(f"[b #ffd089]⚡ Nuevas skills (últimos 45d): {len(new_skills)}[/b #ffd089]"))
            unaudited_new = [e for e in new_skills if e[1] == "never"]
            if unaudited_new:
                content.mount(Static(
                    f"  [red]⚠ {len(unaudited_new)} sin auditar:[/red] "
                    f"{', '.join(e[0] for e in unaudited_new[:8])}"
                ))
            else:
                content.mount(Static(
                    f"  [green]✓ Todas auditadas[/green]"
                ))

        # ── C. Recent audits (last 10, compacto) ─────────────────────────
        if audits_dir.exists():
            audits = sorted(audits_dir.glob("*.md"),
                             key=lambda p: p.stat().st_mtime, reverse=True)
            if audits:
                content.mount(Static(""))
                content.mount(Static(f"[b]Últimas valoraciones ({min(len(audits), 10)})[/b]"))
                for a in audits[:10]:
                    try:
                        head = a.read_text(encoding="utf-8")[:800]
                    except OSError:
                        continue
                    nm = _re.search(r"nota:\s*([\d.]+)/10", head)
                    vm = _re.search(r"veredicto:\s*([^\n]+)", head)
                    nota = nm.group(1) if nm else "?"
                    ver = vm.group(1).strip()[:28] if vm else "?"
                    mtime = datetime.fromtimestamp(a.stat().st_mtime)
                    is_triple = "triple" in head.lower()
                    mode_badge = " [cyan][3x][/cyan]" if is_triple else ""
                    try:
                        n_val = float(nota)
                        color = "green" if n_val >= 9 else "yellow" if n_val >= 7 else "red"
                    except ValueError:
                        color = "dim"
                    content.mount(Static(
                        f"  {mtime.strftime('%m-%d %H:%M')}  "
                        f"[b]{_markup_escape(a.stem[:30])}[/b]{mode_badge}  "
                        f"[{color}]{nota}/10[/{color}]  "
                        f"[dim]{_markup_escape(ver)}[/dim]"
                    ))

        # ── D. L2 Proposals ───────────────────────────────────────────────
        proposals_dir = COCKPIT_DIR / "proposals"
        if proposals_dir and proposals_dir.exists():
            props = sorted(proposals_dir.glob("*.json"),
                            key=lambda p: p.stat().st_mtime, reverse=True)
            if props:
                content.mount(Static(""))
                content.mount(Static(f"[b]L2 Proposals ({len(props)})[/b]"))
                pending_count = actionable_total = 0
                for f in props[:5]:
                    try:
                        d = json.loads(f.read_text(encoding="utf-8"))
                        plist = d.get("proposals", [])
                        fp_high = sum(1 for p in plist if p.get("false_positive_risk") == "high")
                        actionable = sum(
                            1 for p in plist
                            if p.get("old_string") and
                            p.get("false_positive_risk") in (None, "none", "low"))
                        status = d.get("status", "pending")
                        color = "dim" if status == "consumed" else "yellow"
                        content.mount(Static(
                            f"  [{color}]{_markup_escape(f.stem[:32])}[/{color}]  "
                            f"{len(plist)} props · {actionable} ok · {fp_high} FP  "
                            f"[dim]{status}[/dim]"
                        ))
                        if status != "consumed":
                            pending_count += 1
                            actionable_total += actionable
                    except (OSError, json.JSONDecodeError):
                        continue
                if pending_count > 0:
                    content.mount(Static(
                        f"  [b yellow]⚠ {pending_count} file(s) · "
                        f"{actionable_total} actionable patches pending[/b yellow]"))

        # Action buttons (v10.4.8 + v10.5 mechanical L3)
        content.mount(Static(""))
        content.mount(Static("[b]Actions:[/b]", classes="title"))
        for btn in [
            Button("◆ Full pipeline on ULTRON (audit→propose→apply)", id="autoupd-full-ultron", variant="warning"),
            Button("L1  Scan: rank skills by audit need", id="autoupd-scan", variant="primary"),
            Button("L1  Audit a skill (Kirkardo)…", id="autoupd-audit", variant="primary"),
            Button("L2  Propose patches (latest audit)", id="autoupd-propose", variant="default"),
            Button("L3  Apply mechanically (no LLM) ⚡", id="autoupd-apply-auto", variant="success"),
            Button("L3  Apply via Claude review", id="autoupd-apply", variant="warning"),
            Button("News-driven audit flags", id="autoupd-newsflags", variant="default"),
        ]:
            content.mount(btn)

    def _render_jobs(self) -> None:
        content = self._clear_content()
        content.mount(Static("[b]Background Jobs[/b]", classes="title"))
        content.mount(Static(
            "[dim]j=refresh · ultron jobs submit|logs|cancel|clean[/dim]",
            classes="subtitle",
        ))
        jobs_dir = COCKPIT_DIR / "jobs"
        if not jobs_dir.exists():
            content.mount(Static(""))
            content.mount(Static("[dim]No jobs yet — run: ultron jobs submit <label> -- <cmd>[/dim]"))
            return
        entries = []
        for d in sorted(jobs_dir.iterdir(), reverse=True):
            mp = d / "meta.json"
            if not mp.exists():
                continue
            try:
                meta = json.loads(mp.read_text(encoding="utf-8"))
            except Exception:
                continue
            # Auto-refresh status if running but PID gone
            if meta.get("status") == "running":
                pid = meta.get("pid")
                if pid:
                    try:
                        if os.name == "nt":
                            import ctypes as _ct
                            h = _ct.windll.kernel32.OpenProcess(0x00100000, False, pid)
                            alive = bool(h) and _ct.windll.kernel32.WaitForSingleObject(h, 0) != 0
                            if h:
                                _ct.windll.kernel32.CloseHandle(h)
                        else:
                            os.kill(pid, 0)
                            alive = True
                    except (OSError, PermissionError):
                        alive = False
                    except Exception:
                        alive = False
                    if not alive:
                        meta["status"] = "done"
                        meta["finished_at"] = datetime.now().isoformat(timespec="seconds")
                        mp.write_text(
                            json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
                        )
            entries.append(meta)
        if not entries:
            content.mount(Static(""))
            content.mount(Static("[dim]No jobs recorded[/dim]"))
            return
        running  = [m for m in entries if m.get("status") == "running"]
        finished = [m for m in entries if m.get("status") != "running"]
        def _rt(m):
            try:
                s = datetime.fromisoformat(m["started_at"])
                e_str = m.get("finished_at")
                e = datetime.fromisoformat(e_str) if e_str else datetime.now()
                sec = int((e - s).total_seconds())
                if sec < 60: return f"{sec}s"
                mn, sc = divmod(sec, 60)
                return f"{mn}m{sc:02d}s" if mn < 60 else f"{mn//60}h{mn%60:02d}m"
            except Exception:
                return "?"
        # Running section
        if running:
            content.mount(Static(""))
            content.mount(Static(f"[b][yellow]● RUNNING ({len(running)})[/yellow][/b]"))
            for m in running:
                ec_str = f"ec={m['exit_code']}" if m.get("exit_code") is not None else ""
                content.mount(Static(
                    f"  [yellow]▶[/yellow] {m['job_id']}  [b]{m.get('label','')[:40]}[/b]"
                    f"  [dim]{_rt(m)}  pid={m.get('pid','?')}  {ec_str}[/dim]"
                ))
        # Recent finished (last 15)
        content.mount(Static(""))
        content.mount(Static(f"[b]Recent ({min(len(finished),15)} of {len(finished)})[/b]"))
        for m in finished[:15]:
            st = m.get("status", "?")
            ec = m.get("exit_code")
            if st == "done":
                icon = "[green]✓[/green]"
                ec_col = "[green]" if ec == 0 else "[yellow]"
                ec_end = "[/green]" if ec == 0 else "[/yellow]"
            elif st == "failed":
                icon = "[red]✗[/red]"
                ec_col = "[red]"; ec_end = "[/red]"
            else:
                icon = "[dim]○[/dim]"
                ec_col = "[dim]"; ec_end = "[/dim]"
            ec_str = f"  {ec_col}ec={ec}{ec_end}" if ec is not None else ""
            ts = m.get("finished_at", m.get("started_at", ""))[:16]
            content.mount(Static(
                f"  {icon} {m['job_id']}  {m.get('label','')[:38]:<38}"
                f"  [dim]{_rt(m):<6}  {ts}[/dim]{ec_str}"
            ))
        content.mount(Static(""))
        content.mount(Static(
            f"[dim]Total: {len(entries)}  "
            f"Running: {len(running)}  "
            f"Done: {sum(1 for m in entries if m.get('status')=='done')}  "
            f"Failed: {sum(1 for m in entries if m.get('status')=='failed')}[/dim]"
        ))

    def _render_changelog(self) -> None:
        content = self._clear_content()
        content.mount(Static("[b]Changelog[/b]", classes="title"))
        content.mount(Static("[dim]ULTRON version history[/dim]", classes="subtitle"))
        changelog_path = ULTRON_ROOT / "references" / "changelog.md"
        if not changelog_path.exists():
            content.mount(Static(""))
            content.mount(Static(f"[red]changelog.md not found:[/red] {changelog_path}"))
            return
        try:
            text = changelog_path.read_text(encoding="utf-8")
        except Exception as e:
            content.mount(Static(f"[red]Error reading changelog:[/red] {e}"))
            return
        content.mount(Static(""))
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped:
                content.mount(Static(""))
                continue
            safe = _markup_escape(stripped)
            if stripped.startswith("### "):
                content.mount(Static(f"[b][#ffd089]{safe}[/#ffd089][/b]"))
            elif stripped.startswith("#### "):
                content.mount(Static(f"  [b]{_markup_escape(stripped[5:])}[/b]"))
            elif stripped.startswith("**Tipo:**") or stripped.startswith("**Disparado"):
                content.mount(Static(f"  [dim]{safe}[/dim]"))
            elif stripped.startswith("# "):
                content.mount(Static(f"[b]{_markup_escape(stripped[2:])}[/b]"))
            elif stripped.startswith("- ") or stripped.startswith("* "):
                content.mount(Static(f"  [cyan]·[/cyan] {_markup_escape(stripped[2:])}"))
            elif stripped.startswith("1.") or stripped.startswith("2.") or stripped.startswith("3."):
                content.mount(Static(f"  [cyan]{safe}[/cyan]"))
            else:
                content.mount(Static(f"  {safe}"))

    def _render_notes(self) -> None:
        content = self._clear_content()
        content.mount(Static("[b]Project Notes[/b]", classes="title"))
        content.mount(Static(
            "[dim]s=refresh · ultron notes <id> save|list|delete[/dim]",
            classes="subtitle",
        ))
        notes_dir = COCKPIT_DIR / "notes"
        if not notes_dir.exists():
            content.mount(Static(""))
            content.mount(Static(
                "[dim]No notes yet — run: ultron notes <project_id> save <text>[/dim]"
            ))
            return
        note_files = sorted(
            notes_dir.glob("*.md"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        if not note_files:
            content.mount(Static(""))
            content.mount(Static("[dim]No notes yet[/dim]"))
            return

        def _parse(text: str) -> list[tuple[str, str]]:
            entries: list[tuple[str, str]] = []
            cur_ts = ""
            cur_lines: list[str] = []
            for line in text.splitlines():
                if line.startswith("**") and "**" in line[2:] and "—" in line:
                    if cur_ts:
                        entries.append((cur_ts, "\n".join(cur_lines).strip()))
                    cur_ts = line
                    cur_lines = []
                elif line == "---":
                    continue
                else:
                    cur_lines.append(line)
            if cur_ts:
                entries.append((cur_ts, "\n".join(cur_lines).strip()))
            return entries

        total_notes = 0
        for nf in note_files[:20]:
            project_id = nf.stem
            try:
                text = nf.read_text(encoding="utf-8")
            except Exception:
                continue
            entries = _parse(text)
            if not entries:
                continue
            total_notes += len(entries)
            mtime = datetime.fromtimestamp(nf.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
            content.mount(Static(""))
            content.mount(Static(
                f"[b][#ffd089]{project_id}[/#ffd089][/b]  "
                f"[dim]{len(entries)} note(s) · last {mtime}[/dim]"
            ))
            for i, (ts, body) in enumerate(entries[-3:], start=max(1, len(entries) - 2)):
                # Show index for delete reference
                ts_short = ts[2:ts.index("**", 2)] if "**" in ts[2:] else ts
                content.mount(Static(f"  [dim][{i}][/dim] {ts_short}"))
                if body:
                    content.mount(Static(f"      [dim]{body[:90]}[/dim]"))
        content.mount(Static(""))
        content.mount(Static(
            f"[dim]{len(note_files)} project(s) with notes · {total_notes} total[/dim]"
        ))


    def action_refresh(self) -> None:
        # Re-render current view
        method = getattr(self, f"_render_{self.current_view}", None)
        if method:
            method()
        self.notify("Refreshed", severity="information")

    def action_help(self) -> None:
        self.push_screen(HelpModal())


def main():
    app = UltronTUI()
    app.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
