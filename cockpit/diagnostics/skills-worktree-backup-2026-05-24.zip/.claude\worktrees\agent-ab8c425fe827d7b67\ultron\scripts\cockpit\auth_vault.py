"""
ULTRON v10.0 Cockpit — Auth Vault Python orchestration.

Thin wrapper around auth-vault.ps1 (which does the DPAPI encryption).
Used by Claude when it wants to:
  - List available profiles for a service
  - Get the active profile for a service (for "I'm using account X" awareness)
  - Trigger a switch (delegates to PowerShell with confirmation)

Claude-as-proxy reminder: this module NEVER sends decrypted blobs to peers.
Decrypted profile content stays inside Claude's own process; Codex/Gemini
receive only sanitized data via prompt.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Optional

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

sys.path.insert(0, str(Path(__file__).parent))
from cockpit_base import COCKPIT_DIR, AUTH_VAULT  # noqa: E402


VAULT_PS1 = Path(__file__).parent / "auth-vault.ps1"


def _run_ps(args: list[str], capture: bool = True) -> subprocess.CompletedProcess:
    """Run auth-vault.ps1 with given args. Returns CompletedProcess."""
    cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
           "-File", str(VAULT_PS1)] + args
    return subprocess.run(cmd, capture_output=capture, text=True, encoding="utf-8")


def list_profiles() -> dict[str, Any]:
    """Read vault JSON directly (just the metadata, no decryption).

    Returns dict shaped like:
        {service: {"active": "personal", "profiles": {"personal": {...}, ...}}, ...}
    Does NOT decrypt - just returns the metadata (label, added, active marker).
    """
    if not AUTH_VAULT.exists():
        return {}
    try:
        # utf-8-sig strips the UTF-8 BOM that PS 5.1 Set-Content -Encoding UTF8 writes
        data = json.loads(AUTH_VAULT.read_text(encoding="utf-8-sig"))
        return data.get("services", {})
    except (json.JSONDecodeError, OSError) as e:
        print(f"[auth_vault] WARNING: vault unreadable: {e}", file=sys.stderr)
        return {}


def active_profile(service: str) -> Optional[str]:
    """Return the active profile name for a service, or None."""
    services = list_profiles()
    svc = services.get(service)
    if svc:
        return svc.get("active")
    return None


def status_summary() -> str:
    """Human-readable summary (used by /proyecto-status, dashboard, etc.)."""
    services = list_profiles()
    if not services:
        return "[auth-vault] empty (no profiles)"
    lines = ["[auth-vault]"]
    for svc_name, svc_data in sorted(services.items()):
        active = svc_data.get("active") or "(none)"
        profiles = svc_data.get("profiles") or {}
        profile_count = len(profiles)
        lines.append(f"  {svc_name:<12} active={active:<14} profiles={profile_count}")
    return "\n".join(lines)


def get_profile_decrypted(service: str, profile_name: str) -> Optional[dict]:
    """Decrypt and return a profile's JSON config. Internal use only — never pass
    the result to peers (Codex/Gemini). Use only inside Claude's own process for
    awareness (e.g., 'which Gmail account is configured right now')."""
    result = _run_ps(["-Action", "Get", "-Service", service, "-ProfileName", profile_name])
    if result.returncode != 0:
        print(f"[auth_vault] Get failed: {result.stderr}", file=sys.stderr)
        return None
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        print(f"[auth_vault] Get returned non-JSON: {result.stdout[:200]}", file=sys.stderr)
        return None


def switch_profile(service: str, profile_name: str, force: bool = False) -> bool:
    """Trigger a Switch via PowerShell. Returns True on success.

    NOTE: Switch is destructive (modifies settings.json). Default behavior
    requires interactive confirmation unless force=True.
    """
    args = ["-Action", "Switch", "-Service", service, "-ProfileName", profile_name]
    if force:
        args.append("-Force")
    result = _run_ps(args, capture=False)
    return result.returncode == 0


# ── CLI for quick inspection ─────────────────────────────────────────────────

def main():
    import argparse
    p = argparse.ArgumentParser(description="ULTRON Auth Vault Python wrapper")
    p.add_argument("action", choices=["status", "list", "active"],
                   help="status (summary) | list (full metadata) | active <service>")
    p.add_argument("service", nargs="?", help="for 'active' action")
    args = p.parse_args()

    if args.action == "status":
        print(status_summary())
    elif args.action == "list":
        services = list_profiles()
        print(json.dumps(services, indent=2, ensure_ascii=False, default=str))
    elif args.action == "active":
        if not args.service:
            print("Usage: auth_vault.py active <service>", file=sys.stderr)
            return 1
        active = active_profile(args.service)
        print(active or "(none)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
