#!/usr/bin/env python3
"""
ULTRON HOOK · block-dangerous-bash · v1.0
Bloquea comandos bash destructivos sin confirmación explícita en el prompt.

Bloquea:
  - rm -rf <root paths>
  - git push --force a main/master
  - git reset --hard sin tag de seguridad
  - DROP DATABASE / DROP TABLE en SQL inline
  - chmod 777 recursivo

Uso en ~/.claude/settings.json:
{
  "hooks": {
    "PreToolUse": [{
      "matcher": "Bash",
      "hooks": [{
        "type": "command",
        "command": "python C:/Users/Rodrigo/.claude/skills/ultron/hooks/block-dangerous-bash.py"
      }]
    }]
  }
}
"""
import json
import re
import sys


DANGEROUS_PATTERNS = [
    (r"rm\s+(-rf?|-fr|-r\s+-f|-f\s+-r)\s+[/~]", "rm -rf en root o home"),
    (r"rm\s+(-rf?|-fr)\s+\.\s*$", "rm -rf en cwd"),
    (r"git\s+push\s+(-f|--force)\s+.*\s+(main|master)\b", "git push --force a main/master"),
    (r"git\s+reset\s+--hard\s+(?!HEAD\s|origin/)", "git reset --hard sin HEAD/origin"),
    (r"(?i)DROP\s+(DATABASE|TABLE|SCHEMA)\s", "DROP destructivo en SQL"),
    (r"chmod\s+-R\s+777", "chmod 777 recursivo"),
    (r":\(\)\s*\{[^}]*\|\s*:[^}]*\};\s*:", "fork bomb"),
]


def main():
    try:
        input_data = json.loads(sys.stdin.read())
    except (json.JSONDecodeError, ValueError):
        sys.exit(0)

    if input_data.get("hook_event_name") != "PreToolUse":
        sys.exit(0)

    if input_data.get("tool_name") != "Bash":
        sys.exit(0)

    command = input_data.get("tool_input", {}).get("command", "")

    for pattern, reason in DANGEROUS_PATTERNS:
        if re.search(pattern, command):
            print(json.dumps({
                "systemMessage": f"ULTRON hook blocked: {reason}. "
                                 f"Si era intencional, hazlo manualmente desde shell.",
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": f"BLOCKED: {reason}"
                }
            }))
            sys.exit(0)


if __name__ == "__main__":
    main()
