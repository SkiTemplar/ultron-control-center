# Sesion YYYY-MM-DD

## Proyectos trabajados
-

## Skills usadas
| Skill | Para que |
|-------|----------|

## Logros
-

## Pendientes para proxima sesion
-

## Decisiones tomadas
-
