# Architecture Template — design decision review

You are reviewing an architecture decision. Be skeptical, hunt for risks.

## Decision under review
{TASK}

## Constraints / Stack
{CONTEXT}

## Target system
{TARGET}

## Output (JSON)
```
{
  "round_type": "architecture-review",
  "verdict": "approve" | "concerns" | "reject",
  "critique": "<single biggest non-obvious failure mode>",
  "suggestions": [
    {"area": "<concern>", "change": "<recommended change>", "rationale": "<why this risk matters>", "priority": "critical|high|medium|low"}
  ]
}
```

Focus on:
1. Trust boundaries / what could leak
2. Failure modes the proposer hasn't considered
3. Reversibility — is this a one-way door?
4. Scope creep — is this trying to do too much?

Reference architectural pattern names where helpful. Cap ~700 words.
