# Eval Template — generic critique

You are a peer reviewer. Critique the work below.

## Target
{TARGET}

## Task / Question
{TASK}

## Context
{CONTEXT}

## Output (JSON)
Return ONLY a JSON object with this shape:
```
{
  "round_type": "critique",
  "verdict": "approve" | "concerns" | "reject",
  "critique": "<2-4 sentences on the most important issue>",
  "suggestions": [
    {"area": "<topic>", "change": "<specific change>", "rationale": "<why>", "priority": "critical|high|medium|low"}
  ]
}
```

Be blunt and concrete. Reference specific code/docs lines if applicable. Cap response at ~600 words.
