# [Nombre del Proyecto / Cliente]
Estado: ACTIVO
Iniciado: YYYY-MM-DD
Ultima actualizacion: YYYY-MM-DD
Tipo: FREELANCE

## Cliente
- Nombre: [nombre del cliente o empresa]
- Contacto: [email / teléfono]
- Contexto: [sector, tamaño, qué necesitan]

## Objetivo del Proyecto
[Qué entrego yo. Qué problema resuelvo al cliente.]

## Entregables
- [ ] [entregable 1] — [fecha]
- [ ] [entregable 2] — [fecha]

## Pricing
- Modelo: [ ] Fixed price  [ ] Por hora  [ ] Retainer mensual
- Precio acordado: [€ o "por definir"]
- Forma de pago: [transferencia / PayPal / otro]
- Facturación: [cuándo y cómo]

## Deadline
[fecha de entrega final o "negociando"]

## Stack / Tecnología
[si aplica: qué se usa para construir el entregable]

## Comunicación
- Canal principal: [email / WhatsApp / Slack]
- Frecuencia de updates: [semanal / por hito / bajo demanda]

## Estado Actual
Proyecto inicializado. Sin trabajo ejecutado todavía.

## Proximos Pasos
- [ ] Confirmar scope y pricing
- [ ] Primer entregable / prototipo
- [ ] Revisión con cliente

## Riesgos
- [riesgo potencial 1]: [mitigación]

## Notas
[acuerdos verbales, restricciones, contexto importante]
