#!/usr/bin/env python3
"""
ULTRON v10.0 Cockpit - AI Standup generator.

Generates a daily morning briefing markdown:
    ~/.ultron/cockpit/standup/YYYY-MM-DD.md

Reads:
  - activity.jsonl (last 24h)
  - projects.json
  - deadlines.json (4.J output)
  - news/ALERTS.md
  - git log of top active projects (last 24h commits)

Output sections:
  - Yesterday: where Rodrigo was active, with commit count per project
  - Today: upcoming deadlines (next 7d)
  - Recommendation: top project to focus on (deadline pressure + recent inactivity)
  - Alerts: any breaking changes from news scraper
  - Pulse: last seen activity timestamp

Designed to be a STARTING POINT for the day. Uses NO external LLM calls
(deterministic markdown). For richer Gemini-summarized version, run with --gemini.

Cron: weekday 8AM via Task Scheduler.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

sys.path.insert(0, str(Path(__file__).parent))
from cockpit_base import (  # noqa: E402
    Cockpit, COCKPIT_DIR, PROJECTS_JSON, ACTIVITY_JSONL,
    DEADLINES_JSON, NEWS_ALERTS,
)


STANDUP_DIR = COCKPIT_DIR / "standup"


# ── Data loaders ─────────────────────────────────────────────────────────────

def load_projects() -> list[dict]:
    return Cockpit.read_json(PROJECTS_JSON, default={"projects": []}).get("projects", [])


def load_activity_last_24h() -> list[dict]:
    if not ACTIVITY_JSONL.exists():
        return []
    cutoff = datetime.now() - timedelta(days=1)
    out = []
    for line in ACTIVITY_JSONL.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            entry = json.loads(line)
            ts = datetime.fromisoformat(entry.get("ts", ""))
            if ts >= cutoff:
                out.append(entry)
        except (ValueError, json.JSONDecodeError):
            continue
    return out


def load_deadlines() -> dict:
    return Cockpit.read_json(DEADLINES_JSON, default={"matches": []})


def load_alerts_head(max_lines: int = 25) -> list[str]:
    if not NEWS_ALERTS.exists():
        return []
    return NEWS_ALERTS.read_text(encoding="utf-8").splitlines()[:max_lines]


# ── Git helper ───────────────────────────────────────────────────────────────

def git_commits_since_24h(repo_path: str, max_count: int = 5) -> list[str]:
    """Return up to max_count one-liners of commits in the last 24h."""
    if not shutil.which("git"):
        return []
    try:
        result = subprocess.run(
            ["git", "-C", repo_path, "log", "--since=24.hours", "--oneline",
             f"-n", str(max_count)],
            capture_output=True, text=True, timeout=8, encoding="utf-8",
        )
        if result.returncode == 0:
            return [l for l in result.stdout.splitlines() if l.strip()]
    except Exception:
        pass
    return []


# ── Sections ─────────────────────────────────────────────────────────────────

def section_yesterday(activity: list[dict], projects: list[dict]) -> list[str]:
    if not activity:
        return [
            "## Yesterday",
            "",
            "_No activity samples in the last 24h. (Activity tracker may be off."
            " Run: `ultron schedule install`.)_",
            "",
        ]

    # v10.5: skip idle entries (project_id=None) for the "where you worked"
    # rollup — they belong in a separate Pulse line, not as a project bucket.
    counts = Counter(e.get("project_id") for e in activity if e.get("project_id"))
    pmap = {p["id"]: p for p in projects}
    lines = ["## Yesterday", "", f"Tracked **{sum(counts.values())} samples** across {len(counts)} projects:", ""]

    for pid, count in counts.most_common(5):
        proj = pmap.get(pid)
        name = proj.get("name", pid) if proj else pid
        commits = []
        if proj and proj.get("path"):
            commits = git_commits_since_24h(proj["path"], max_count=3)
        line = f"- **{name}** (`{pid}`) - {count} samples"
        if commits:
            line += f", **{len(commits)} commits**"
        lines.append(line)
        for c in commits:
            lines.append(f"    - `{c}`")
    lines.append("")
    return lines


def section_today(projects: list[dict], deadlines: dict) -> list[str]:
    today = datetime.now().date()
    horizon = today + timedelta(days=7)

    upcoming = []
    # From projects.json deadlines (manual)
    for p in projects:
        dl = p.get("deadline")
        if not dl:
            continue
        try:
            d = datetime.fromisoformat(dl).date()
            if today <= d <= horizon:
                upcoming.append((d, p["id"], "manual", p.get("name", "")))
        except (ValueError, TypeError):
            continue
    # From Calendar matches
    for m in deadlines.get("matches", []):
        try:
            d = datetime.fromisoformat(m.get("date", "")).date()
            if today <= d <= horizon:
                upcoming.append((d, m.get("project_id", "?"),
                                 f"calendar (score={m.get('score')})",
                                 m.get("event_title", "")))
        except (ValueError, TypeError):
            continue

    if not upcoming:
        return ["## Today / next 7 days", "",
                "_No deadlines in the next 7 days._", ""]

    upcoming.sort(key=lambda x: x[0])
    lines = ["## Today / next 7 days", ""]
    for d, pid, source, title in upcoming:
        days_left = (d - today).days
        tag = "**TODAY**" if days_left == 0 else f"**{days_left}d**"
        lines.append(f"- {tag} `{pid}` - {title} _({source}, {d})_")
    lines.append("")
    return lines


def section_recommendation(projects: list[dict], activity: list[dict],
                           deadlines: dict) -> list[str]:
    """Recommend a focus project: weighted by deadline pressure - recent activity."""
    today = datetime.now().date()
    counts = Counter(e.get("project_id") for e in activity if e.get("project_id"))

    candidates = []  # list of (urgency_score, project_id, reason)
    for p in projects:
        if p.get("status") not in ("active", "auto-detected"):
            continue
        pid = p["id"]
        urgency = 0.0

        # Deadline pressure (closer = higher)
        dl = p.get("deadline")
        if dl:
            try:
                d = datetime.fromisoformat(dl).date()
                days_left = (d - today).days
                if 0 <= days_left <= 14:
                    urgency += (15 - days_left) * 1.5  # 0d=22.5, 14d=1.5
            except (ValueError, TypeError):
                pass

        for m in deadlines.get("matches", []):
            if m.get("project_id") != pid:
                continue
            try:
                d = datetime.fromisoformat(m.get("date", "")).date()
                days_left = (d - today).days
                if 0 <= days_left <= 14:
                    urgency += (15 - days_left) * 1.5 * float(m.get("score", 0.5))
            except (ValueError, TypeError):
                continue

        # Penalize recent activity (already worked on it)
        urgency -= counts.get(pid, 0) * 0.3

        if urgency > 0:
            candidates.append((urgency, pid, p.get("name", pid)))

    if not candidates:
        return [
            "## Recommendation",
            "",
            "_No clear focus today. No active deadlines in the next 14 days._",
            "_Consider catching up on tech debt or refreshing knowledge._",
            "",
        ]

    candidates.sort(reverse=True)
    top_score, top_pid, top_name = candidates[0]
    runners = candidates[1:3]

    lines = ["## Recommendation", "",
             f"**Focus today: `{top_pid}`** ({top_name})", "",
             f"_Urgency score: {top_score:.1f}_", ""]
    if runners:
        lines.append("**Runner-ups:**")
        for s, pid, name in runners:
            lines.append(f"- `{pid}` (score {s:.1f}) - {name}")
        lines.append("")
    return lines


def section_alerts() -> list[str]:
    head = load_alerts_head()
    if not head:
        return ["## News alerts", "", "_No breaking changes in queue._", ""]
    return ["## News alerts", "", "```"] + head + ["```", ""]


def section_pulse(activity: list[dict]) -> list[str]:
    if not activity:
        return ["## Pulse", "", "_Activity tracker has no recent samples._", ""]
    activity.sort(key=lambda e: e.get("ts", ""), reverse=True)
    last = activity[0]
    return [
        "## Pulse",
        "",
        f"Last seen: **{last.get('ts')}** on `{last.get('project_id')}` "
        f"({last.get('ide') or 'no IDE'}, src={last.get('source')})",
        "",
    ]


def section_header() -> list[str]:
    today = datetime.now().date()
    return [
        f"# Standup - {today.isoformat()} ({today.strftime('%A')})",
        "",
        f"_Auto-generated {datetime.now().isoformat(timespec='seconds')}_",
        "",
    ]


# ── Optional Gemini polish ───────────────────────────────────────────────────

def gemini_polish(markdown: str) -> str | None:
    if not shutil.which("gemini"):
        return None
    prompt = (
        "You are a no-bullshit productivity coach. Rewrite this morning standup "
        "to be punchier and add a single 1-line insight or warning at the top. "
        "Keep all bullet points and structure intact. Output markdown only.\n\n"
        + markdown
    )
    try:
        result = subprocess.run(
            ["gemini", "-p", prompt, "-m", "flash", "--approval-mode", "plan",
             "-o", "json", "--skip-trust"],
            capture_output=True, text=True, timeout=60, encoding="utf-8",
        )
        # v10.4.5 fix: Gemini JSON output can span multiple lines.
        # Find first '{' and walk to matching closing brace (depth tracking).
        raw = result.stdout or ""
        first = raw.find("{")
        if first < 0:
            return None
        payload = _extract_json_object(raw[first:])
        if not payload:
            return None
        data = json.loads(payload)
        response = data.get("response", "")
        response = re.sub(r"^```(?:markdown)?\s*", "", response.strip())
        response = re.sub(r"\s*```$", "", response)
        return response or None
    except Exception:
        return None
    return None


def _extract_json_object(text: str) -> str | None:
    """Walk text from first char (assumed '{') to matching '}'."""
    depth = 0
    in_string = False
    escape = False
    for i, ch in enumerate(text):
        if escape:
            escape = False
            continue
        if ch == "\\" and in_string:
            escape = True
            continue
        if ch == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[: i + 1]
    return None


# ── Build ────────────────────────────────────────────────────────────────────

def build(use_gemini: bool = False) -> Path:
    projects = load_projects()
    activity = load_activity_last_24h()
    deadlines = load_deadlines()

    lines: list[str] = []
    lines += section_header()
    lines += section_yesterday(activity, projects)
    lines += section_today(projects, deadlines)
    lines += section_recommendation(projects, activity, deadlines)
    lines += section_alerts()
    lines += section_pulse(activity)

    md = "\n".join(lines)

    if use_gemini:
        polished = gemini_polish(md)
        if polished:
            md = polished

    STANDUP_DIR.mkdir(parents=True, exist_ok=True)
    today = datetime.now().strftime("%Y-%m-%d")
    out = STANDUP_DIR / f"{today}.md"
    out.write_text(md, encoding="utf-8")
    return out


def main():
    p = argparse.ArgumentParser(description="ULTRON Cockpit AI standup")
    p.add_argument("--gemini", action="store_true", help="Polish with Gemini flash (uses tokens)")
    p.add_argument("--print", action="store_true", help="Print today's standup if it exists")
    p.add_argument("--from-cron", action="store_true",
                   help="(Internal) Apply weekday + daily skip-guard. Manual runs always execute.")
    args = p.parse_args()

    today = datetime.now().strftime("%Y-%m-%d")
    out = STANDUP_DIR / f"{today}.md"

    if args.print:
        if out.exists():
            print(out.read_text(encoding="utf-8"))
        else:
            print("(no standup for today; run without --print to generate)")
        return 0

    # Weekday + daily guard ONLY from cron. Manual runs always execute.
    if args.from_cron:
        from should_run import should_run_weekday
        if not should_run_weekday("standup"):
            wd = datetime.now().weekday()
            reason = "weekend" if wd >= 5 else "already ran today"
            print(f"[standup] Cron skip ({reason})")
            return 0

    path = build(use_gemini=args.gemini)
    print(f"[standup] Wrote {path} ({path.stat().st_size} bytes)")
    if args.from_cron:
        from should_run import mark_ran_today
        mark_ran_today("standup")
    return 0


if __name__ == "__main__":
    sys.exit(main())
