#!/usr/bin/env python3
"""
ULTRON v10.6 - Usage tracker (subscription windows, NOT per-token cost).

Rodrigo's plans:
  - Claude Code Pro Max     → 5-hour rolling window + weekly window
  - ChatGPT (Codex)         → 5-hour rolling window + weekly window
  - Gemini Pro              → daily quota
Usage is NOT billed per-token. We track ACTIVITY in each window so Rodrigo
knows how heavily he's using each subscription before hitting limits.

Sources:
  - Claude Code: ~/.claude/projects/<encoded-cwd>/<session-uuid>.jsonl
                 Each `type=assistant` turn has timestamp ISO8601 + model name.
  - Codex:       ~/.codex/sessions/YYYY/MM/DD/rollout-<ts>-<uuid>.jsonl
                 Filename has start timestamp.
  - Gemini:      not tracked (CLI does not write per-session metadata to disk).

Output: window-aware activity counts (turns per model, per source) — no money,
no token aggregates surfaced. Internal token counters are kept ONLY to detect
heavy turns (relative-load indicator), never displayed as cost.

NO external deps.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

CC_PROJECTS_DIR = Path.home() / ".claude" / "projects"
CODEX_SESSIONS_DIR = Path.home() / ".codex" / "sessions"

CODEX_FILENAME_RE = re.compile(
    r"rollout-(\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2})-[0-9a-f-]+\.jsonl$"
)

# Subscription windows (Rodrigo's plans, 2026)
WINDOW_5H = timedelta(hours=5)
WINDOW_WEEK = timedelta(days=7)


def _parse_iso(ts: str) -> datetime | None:
    if not ts:
        return None
    try:
        if ts.endswith("Z"):
            return datetime.fromisoformat(ts[:-1] + "+00:00")
        return datetime.fromisoformat(ts)
    except (ValueError, TypeError):
        return None


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def scan_claude_code(cutoff: datetime) -> list[dict]:
    """Returns turn records: {ts, model, source, weight}.
    `weight` is a rough load indicator (1=light, 2=mid, 3=heavy) derived from
    Opus vs Sonnet vs Haiku model — used internally for visualization, NOT $."""
    if not CC_PROJECTS_DIR.exists():
        return []
    out: list[dict] = []
    cutoff_ts = cutoff.timestamp()
    for project_dir in CC_PROJECTS_DIR.iterdir():
        if not project_dir.is_dir():
            continue
        for jsonl in project_dir.glob("*.jsonl"):
            try:
                if jsonl.stat().st_mtime < cutoff_ts:
                    continue
            except OSError:
                continue
            try:
                with jsonl.open("r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line or '"type":"assistant"' not in line:
                            continue
                        try:
                            d = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        ts = _parse_iso(d.get("timestamp", ""))
                        if not ts or ts < cutoff:
                            continue
                        msg = d.get("message", {}) or {}
                        model = (msg.get("model") or "unknown").lower()
                        out.append({
                            "ts": ts,
                            "model": msg.get("model", "unknown"),
                            "source": "claude-code",
                            "weight": _model_weight(model),
                        })
            except OSError:
                continue
    return out


def scan_codex(cutoff: datetime) -> list[dict]:
    if not CODEX_SESSIONS_DIR.exists():
        return []
    out: list[dict] = []
    cutoff_ts = cutoff.timestamp()
    for jsonl in CODEX_SESSIONS_DIR.rglob("rollout-*.jsonl"):
        try:
            if jsonl.stat().st_mtime < cutoff_ts:
                continue
        except OSError:
            continue
        m = CODEX_FILENAME_RE.search(jsonl.name)
        if not m:
            continue
        try:
            file_ts = datetime.strptime(m.group(1), "%Y-%m-%dT%H-%M-%S")
            file_ts = file_ts.replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        if file_ts < cutoff:
            continue
        # Each turn in the rollout = one entry. We approximate per-turn count
        # by counting lines with usage info; weight 2 (Codex is a mid-tier
        # peer in our taxonomy).
        try:
            count = 0
            with jsonl.open("r", encoding="utf-8") as f:
                for line in f:
                    if '"usage"' in line:
                        count += 1
            for _ in range(max(count, 1)):
                out.append({
                    "ts": file_ts,
                    "model": "gpt-5.5",
                    "source": "codex",
                    "weight": 2,
                })
        except OSError:
            continue
    return out


def _model_weight(model_lower: str) -> int:
    if "haiku" in model_lower:
        return 1
    if "sonnet" in model_lower:
        return 2
    if "opus" in model_lower:
        return 3
    return 2


def aggregate_window(turns: list[dict], window: timedelta) -> dict[str, Any]:
    cutoff = _now_utc() - window
    by_model: defaultdict[str, dict] = defaultdict(
        lambda: {"count": 0, "load": 0}
    )
    by_source: defaultdict[str, dict] = defaultdict(
        lambda: {"count": 0, "load": 0}
    )
    total = {"count": 0, "load": 0}
    for t in turns:
        if t["ts"] < cutoff:
            continue
        m = t["model"]
        s = t["source"]
        w = t["weight"]
        by_model[m]["count"] += 1
        by_model[m]["load"] += w
        by_source[s]["count"] += 1
        by_source[s]["load"] += w
        total["count"] += 1
        total["load"] += w
    return {
        "window_label": _fmt_window(window),
        "total": total,
        "by_model": dict(by_model),
        "by_source": dict(by_source),
    }


def _fmt_window(w: timedelta) -> str:
    if w == WINDOW_5H:
        return "5h rolling"
    if w == WINDOW_WEEK:
        return "weekly"
    return f"{w}"


def hourly_buckets(turns: list[dict], hours: int = 24) -> list[tuple[datetime, int]]:
    now = _now_utc().replace(minute=0, second=0, microsecond=0)
    buckets: dict[datetime, int] = {}
    for i in range(hours):
        buckets[now - timedelta(hours=hours - 1 - i)] = 0
    cutoff = now - timedelta(hours=hours)
    for t in turns:
        if t["ts"] < cutoff:
            continue
        bucket = t["ts"].replace(minute=0, second=0, microsecond=0)
        if bucket in buckets:
            buckets[bucket] += 1  # turn count, not tokens
    return sorted(buckets.items())


def render_report(turns: list[dict], json_out: bool) -> int:
    if not turns:
        print("[usage] No sessions found in scan window")
        return 0

    win_5h = aggregate_window(turns, WINDOW_5H)
    win_week = aggregate_window(turns, WINDOW_WEEK)

    if json_out:
        print(json.dumps({
            "5h_rolling": win_5h,
            "weekly": win_week,
            "scanned_turns": len(turns),
        }, default=str, indent=2))
        return 0

    print()
    print("ULTRON USAGE — subscription windows")
    print("=" * 60)
    print("Tracking ACTIVITY (turns + relative load), not money.")
    print()

    for label, agg in [
        ("5-HOUR ROLLING", win_5h),
        ("WEEKLY", win_week),
    ]:
        t = agg["total"]
        if t["count"] == 0:
            print(f"[{label}] (no activity)")
            print()
            continue
        print(f"[{label}]")
        print(f"  {t['count']} turns · load index {t['load']}")
        # By model
        models_sorted = sorted(
            agg["by_model"].items(),
            key=lambda x: -x[1]["load"],
        )
        for model, bm in models_sorted:
            print(f"    {model:<28} {bm['count']:>4} turns  (load {bm['load']})")
        # By source
        for src, bs in sorted(agg["by_source"].items()):
            print(f"    via {src:<24} {bs['count']:>4} turns  (load {bs['load']})")
        print()

    # 24h hourly bar (turn count, not tokens)
    print("Activity by hour (last 24h, UTC, turns):")
    buckets = hourly_buckets(turns, hours=24)
    if buckets:
        peak = max((v for _, v in buckets), default=1) or 1
        for hour, total in buckets:
            bar_len = int((total / peak) * 30)
            bar = "█" * bar_len if total > 0 else ""
            label = hour.strftime("%H:00")
            print(f"  {label}  {bar:<30}  {total if total else '·'}")
    print()
    return 0


def cmd_live(_args) -> int:
    """v10.6.1: spawn an interactive Claude Code session that runs `/usage`.

    Why: `/usage` is a CLIENT-SIDE slash command (handled by the Claude Code
    interface, not the model). It cannot be invoked via `--print` because it
    never reaches the model. We open a new Windows Terminal tab where the user
    sees the real subscription window stats (5h rolling + weekly) directly
    from Anthropic's accounting, not our local approximation.

    Falls back to a Python subprocess hint if wt.exe is unavailable.
    """
    import shutil as _shutil
    import subprocess as _subprocess
    wt = _shutil.which("wt.exe")
    if wt:
        try:
            _subprocess.Popen(
                [wt, "new-tab", "--title", "ULTRON · /usage",
                 "claude", "--dangerously-skip-permissions", "/usage"],
                creationflags=getattr(_subprocess, "DETACHED_PROCESS", 0),
            )
            print("[usage-live] Spawned Windows Terminal tab with `claude /usage`.")
            print("[usage-live] Read the 5h rolling + weekly windows in the new tab.")
            return 0
        except OSError as e:
            print(f"[usage-live] failed to spawn: {e}", file=sys.stderr)
    print("[usage-live] wt.exe not available; run manually:")
    print("            claude       (then type)   /usage")
    return 0


def main():
    p = argparse.ArgumentParser(
        description="ULTRON usage tracker (subscription window awareness)")
    sub = p.add_subparsers(dest="cmd")

    # Default behavior is the local approximation report
    p.add_argument("--json", action="store_true", help="JSON output")
    p.add_argument("--days", type=int, default=7,
                   help="Scan history window (default 7d)")

    # v10.6.1: explicit subcommand `live` opens Anthropic's official /usage
    sp = sub.add_parser("live",
                         help="Spawn interactive `claude /usage` for the "
                              "real subscription window stats")
    sp.set_defaults(func=cmd_live)

    args = p.parse_args()
    if getattr(args, "func", None):
        return args.func(args)

    cutoff = _now_utc() - timedelta(days=args.days)
    all_turns = scan_claude_code(cutoff) + scan_codex(cutoff)
    return render_report(all_turns, args.json)


if __name__ == "__main__":
    sys.exit(main())
