# ULTRON — ROUTING TESTS · v1.2
> Test suite declarativo. Verificar manualmente en cada sesión ULTRA que modifique FAST PATH, tiebreaks o personas.
> Formato: Input → Expected routing · Rule que aplica
> Si algún caso produce routing distinto al Expected: BUG en FAST PATH → fix antes de cerrar sesión.

---

## CATEGORÍAS

- [Layer 1 — Señales claras](#layer-1--señales-claras) (9 casos)
- [Tiebreaks](#tiebreaks) (7 casos — los más críticos)
- [Layer 2 — Plugins](#layer-2--plugins) (5 casos)
- [Persona + Plugin combos](#persona--plugin-combos) (4 casos)
- [Selección de modo](#selección-de-modo) (3 casos)
- [Overlays](#overlays) (5 casos)
- [Confidence reporting](#confidence-reporting) (2 casos)

---

## Layer 1 — Señales claras

Casos con señal única e inequívoca. Si falla alguno, el FAST PATH Layer 1 tiene un bug básico.

### T-01
**Input:** `"tengo un bug en mi archivo .ts"`
**Expected:** terry-davis
**Rule:** FAST PATH L1 — `.ts` → terry-davis (sin tiebreak)

### T-02
**Input:** `"cómo funciona el Game Ability System en UE5"`
**Expected:** don-claudio
**Rule:** FAST PATH L1 — `UE5 · GAS` → don-claudio

### T-03
**Input:** `"diseña el layout de la pantalla de inventario"`
**Expected:** mike-tyson
**Rule:** FAST PATH L1 — `diseño · layout` → mike-tyson

### T-04
**Input:** `"quiero monetizar mi app, qué modelo de pricing uso"`
**Expected:** jordan-belfort
**Rule:** FAST PATH L1 — `monetizar · pricing` → jordan-belfort

### T-05
**Input:** `"explícame qué es un transformer y cómo funciona la atención"`
**Expected:** einstein
**Rule:** FAST PATH L1 — `explica · concepto` → einstein (transformer conceptual, no implementación técnica)

### T-06
**Input:** `"ponme un recordatorio en Google Calendar para mañana"`
**Expected:** pana
**Rule:** FAST PATH L1 — `agenda · Calendar` → pana

### T-07
**Input:** `"cuánto gasté en KutxaBank este mes"`
**Expected:** tio-gilito
**Rule:** FAST PATH L1 — `gasto · KutxaBank` → tio-gilito

### T-08
**Input:** `"corrige mi entrega del proyecto de backend de la uni"`
**Expected:** repo-evaluator
**Rule:** FAST PATH L1 — `corrige · entrega` → repo-evaluator

### T-09
**Input:** `"cómo va el Barça en la Champions"`
**Expected:** manolo-lama
**Rule:** FAST PATH L1 — `Champions · fútbol` → manolo-lama

---

## Tiebreaks

Los casos más propensos a regresión. Un cambio en FAST PATH puede romper estos silenciosamente.

### T-10 — UE5 tiebreak sobre bug/código
**Input:** `"tengo un bug en mi Blueprint de UE5"`
**Expected:** don-claudio
**Rule:** FAST PATH L1 tiebreak — `UE5` tiene precedencia sobre `bug`. UE5+.cpp → don-claudio.

### T-11 — .cpp + UE5 simultáneo
**Input:** `"este .cpp de UE5 tiene un crash en la replicación"`
**Expected:** don-claudio
**Rule:** FAST PATH L1 — `.cpp + UE5` → don-claudio (tiebreak explícito en routing-matrix § INSTANT ROUTING)

### T-12 — .cs + Unity → terry, NO don-claudio
**Input:** `"este .cs de Unity no compila en Android"`
**Expected:** terry-davis
**Rule:** FAST PATH L1 tiebreak — `.cs + Unity` → terry-davis (don-claudio solo para Unity a nivel diseño/arquitectura sin código)

### T-13 — GPU/CUDA tiebreak sobre einstein
**Input:** `"investiga cómo funciona CUDA y los memory coalescing patterns"`
**Expected:** novalbos
**Rule:** FAST PATH L1 tiebreak einstein — `CUDA · GPU · bajo nivel` → novalbos, no einstein

### T-14 — shader de juego vs shader técnico
**Input:** `"necesito un shader de material PBR para UE5"`
**Expected:** don-claudio
**Rule:** FAST PATH L1 tiebreak novalbos — `shader de juego/material UE5` → don-claudio, no novalbos

### T-15 — bolsa + código (tiebreak nuevo v6.1)
**Input:** `"quiero construir un tracker de cartera en TypeScript"`
**Expected:** warren primero (valida/diseña), terry implementa · `[routing: ~70% warren→terry]`
**Rule:** FAST PATH L1 tiebreak warren — `bolsa + código` → warren primero, terry implementa

### T-16 — física + código (tiebreak nuevo v6.1)
**Input:** `"tengo que simular colisiones para el examen de Física y hacerlo en Python"`
**Expected:** profesor-fisica primero (define física), terry implementa
**Rule:** FAST PATH L1 tiebreak profesor-fisica — `física + código` → profesor-fisica primero, terry implementa

---

## Layer 2 — Plugins

Señales que activan plugins directamente, sin persona específica o junto a ella.

### T-17
**Input:** `"haz un code review de este PR"`
**Expected:** pr-review-toolkit:code-reviewer
**Rule:** FAST PATH L2 — `code review` → pr-review-toolkit:code-reviewer

### T-18
**Input:** `"quiero hacer TDD para esta feature nueva"`
**Expected:** superpowers:test-driven-development
**Rule:** FAST PATH L2 — `TDD · testing` → superpowers:test-driven-development

### T-19
**Input:** `"llevo 3 sesiones con este bug y no encuentro la causa"`
**Expected:** superpowers:systematic-debugging
**Rule:** FAST PATH L2 — `bug sin causa obvia · debug sistemático` → superpowers:systematic-debugging

### T-20
**Input:** `"quiero crear un MCP server para conectar con Notion"`
**Expected:** mcp-builder
**Rule:** FAST PATH L2 — `crear MCP · MCP server` → mcp-builder

### T-21
**Input:** `"diseña el schema de la base de datos para el proyecto"`
**Expected:** database-schema-designer
**Rule:** FAST PATH L2 — `schema DB` → database-schema-designer

---

## Persona + Plugin combos

Casos donde la tarea de dominio requiere ADEMÁS un proceso formal.

### T-22 — UI diseño + implementación
**Input:** `"diseña e implementa la pantalla de login con animaciones"`
**Expected:** mike-tyson + frontend-design:frontend-design
**Rule:** FAST PATH combos — `UI + código` → mike-tyson + frontend-design

### T-23 — Feature rota con código
**Input:** `"el sistema de guardado está completamente roto, ni sé por dónde empezar"`
**Expected:** terry-davis + focused-fix
**Rule:** FAST PATH combos — `feature rota · módulo con fallos en cascada` → terry-davis + focused-fix

### T-24 — Framerate profiling juego
**Input:** `"el nivel 3 va a 20fps y necesito saber por qué"`
**Expected:** don-claudio + performance-profiler
**Rule:** FAST PATH combos — `framerate · profiling de juego` → don-claudio + performance-profiler

### T-25 — Tracker financiero con código
**Input:** `"construye un dashboard de inversiones con React y Supabase"`
**Expected:** warren + terry-davis
**Rule:** FAST PATH combos v6.1 — warren valida/diseña, terry implementa

---

## Selección de modo

### T-26 — LOW mode inline
**Input:** `"qué es una función pura"` (o con `/low`)
**Expected:** LOW mode · respuesta ≤50 palabras · 0 cascade · 0 delegación
**Rule:** SELECTOR DE MODO — factual ≤2 pasos → LOW resuelto inline

### T-27 — Escalada a HIGH
**Input:** `"implementa el sistema de respawn para multijugador en UE5 con GAS"`
**Expected:** HIGH mode · don-claudio · Plan Mode antes de tocar código
**Rule:** SELECTOR DE MODO — feature HARD + multi-sistema → HIGH

### T-28 — ULTRA explícito
**Input:** `"diseña la arquitectura completa de mi juego desde cero"` con `/ultra`
**Expected:** ULTRA mode · THINKING · Plan Mode · dispatching-parallel-agents si >2 tareas
**Rule:** SELECTOR DE MODO — `/ultra` → ULTRA protocol completo

---

## Overlays

### T-29 — THINKING overlay
**Input:** `"pros y contras de usar ECS vs OOP para el sistema de entidades /thinking"`
**Expected:** novalbos/don-claudio + THINKING overlay · 3+ enfoques con trade-offs antes de responder
**Rule:** SKILL.md THINKING OVERLAY — apila sobre modo activo, 3+ enfoques primero

### T-30 — CONTRAST overlay
**Input:** `"siempre acabamos usando el mismo patrón de networking, quiero ver alternativas /contrast"`
**Expected:** don-claudio + CONTRAST overlay · 6 fases (FREEZE→BLANK→DIVERGE→DEVIL→INTEGRATE→DECIDE)
**Rule:** protocols.md § CONTRASTE COGNITIVO — romper anclaje cognitivo

### T-36 — CC WAKE-UP · "en qué estaba"
**Input:** `"Ultron, en qué estaba con el proyecto Tortunabo"`
**Expected:** Ejecutar `memory.md § CC WAKE-UP` → Glob `~/.claude/projects/*/MEMORY.md` → leer el que matchea "Tortunabo" → reportar `[PROYECTO ACTIVO: Tortunabo — última sesión: FECHA]` + resumen
**Rule:** SKILL.md Siempre disponibles — `en qué estaba / continua con X` → memory.md § CC WAKE-UP

### T-37 — ANTI-STUCK · bucle explícito
**Input:** `"no avanzamos, llevamos 4 mensajes dando vueltas"` (o bucle detectado internamente)
**Expected:** Ejecutar `protocols.md § ANTI-STUCK` → declarar `[ANTI-STUCK]` + METACOGNICIÓN + RESET + PIVOT con enfoque distinto
**Rule:** SKILL.md Auto-triggers + Siempre disponibles — `bucle / no avanzamos` → protocols.md § ANTI-STUCK

### T-38 — CONTRAST auto-trigger por lenguaje natural
**Input:** `"dame alternativas a cómo estamos gestionando la red en UE5, siempre acabamos en lo mismo"`
**Expected:** `/contrast` activado automáticamente sobre don-claudio · output con headers `[FASE 1: FREEZE]` ... `[FASE 6: DECIDE]` visibles
**Rule:** SKILL.md Auto-triggers — `"dame alternativas"` → activar /contrast sin comando explícito

---

## Confidence reporting

### T-31 — Señal genuinamente ambigua → preguntar
**Input:** `"revisa el código financiero"`
**Expected:** `[routing: ~65% terry-davis, 35% warren — señal ambigua]` → preguntar: "¿es una revisión técnica del código o del modelo financiero?"
**Rule:** SKILL.md Confidence reporting — señal encaja en >1 fila (código→terry, financiero→warren) con <60% confianza → preguntar

### T-32 — Multi-step secuencial → no ambiguo
**Input:** `"investiga los patrones de replicación de UE5 y luego impleméntalos"`
**Expected:** einstein/novalbos investiga → don-claudio/terry implementa (secuencial, no ambiguo)
**Rule:** Tareas secuenciales con dominio distinto → ULTRON orquesta en fases, no señal ambigua

---

## Cómo usar este archivo

**En sesión ULTRA después de cambiar FAST PATH:**
1. Leer este archivo
2. Para cada caso modificado por el cambio: verificar que el routing sigue siendo correcto
3. Si hay regresión: fix antes de cerrar sesión
4. Si hay nuevo tiebreak que no está cubierto: añadir caso nuevo al final

**En AUTO-MEJORA (protocolos.md § AUTO-MEJORA):**
> Después de añadir/eliminar persona o tiebreak: verificar T-10 a T-16 (sección Tiebreaks)

**Cuándo añadir casos:**
- Nuevo tiebreak → añadir caso en § Tiebreaks
- Nueva persona → añadir 1 caso en § Layer 1
- Nuevo combo → añadir caso en § Persona + Plugin combos
- Bug de routing detectado por Kirkardo → añadir el input exacto que falló

### T-33 — Frontmatter count
**Input:** (meta-test, no routing) — contar filas en FAST PATH Layer 1
**Expected:** 14 personas · frontmatter dice "14 personas" · JERARQUÍA dice "14 especialistas"
**Rule:** Si el count no coincide → actualizar frontmatter + JERARQUÍA antes de cerrar sesión

### T-34 — investiga + dominio específico NO va a einstein
**Input:** `"investiga cómo monetizar un plugin de UE5"`
**Expected:** jordan-belfort (monetizar > investiga)
**Rule:** FAST PATH L1 Regla de lectura — señal de dominio específico tiene precedencia sobre `investiga`

### T-35 — investiga puro SIN dominio → einstein
**Input:** `"investiga cómo funciona la mecánica cuántica"`
**Expected:** einstein
**Rule:** FAST PATH L1 — `investiga` sin señal de otro dominio → einstein

---

## Dual Mode overlays (v8.0)

### T-39 — `/minidual` en MEDIUM
**Input:** `"Ultron /minidual ¿es idiomático usar Result<T,E> en Rust para parseo?"`
**Expected:** MEDIUM mode + MiniDual overlay · 1 round Codex · output ≤500 tk · sin escalada de modo
**Rule:** SKILL.md DUAL MODE OVERLAY — MiniDual disponible en MEDIUM con trigger explícito

### T-40 — `/dual` rechazado en LOW
**Input:** `"Ultron /low /dual revisa esta función"`
**Expected:** rechazo + mensaje *"Dual no disponible en LOW. ¿Subo a MEDIUM (MiniDual) o HIGH (Dual completo)?"*
**Rule:** SKILL.md DUAL MODE OVERLAY — LOW prohíbe cualquier sub-modo Dual

### T-41 — `/maxdual` en HIGH requiere confirmación
**Input:** `"Ultron /high /maxdual diseña el sistema de billing"`
**Expected:** notificar *"MaxDual normalmente es ULTRA-only. ¿Confirmo invocación en HIGH?"* · esperar OK · si OK → ejecutar 5 rounds
**Rule:** SKILL.md DUAL MODE OVERLAY — MaxDual en HIGH solo si Rodrigo lo pide explícitamente

### T-42 — `/contrast --dual` integración
**Input:** `"Ultron /ultra /contrast --dual rediseña la auth"`
**Expected:** ULTRA mode · CONTRAST overlay · FASE 4 DEVIL ejecutada por Codex (header `[FASE 4: DEVIL — vía Codex Dual]`) · resto de fases por Claude
**Rule:** protocols.md § CONTRASTE COGNITIVO — flag `--dual` delega FASE 4 a Codex

### T-43 — `/dual --rounds=N` override
**Input:** `"Ultron /high /dual --rounds=2 refactor el módulo X"`
**Expected:** Dual con 2 rounds (no 3) · solo PROPOSE+CRITIQUE, sin REFINE explícito · Claude integra y ejecuta
**Rule:** SKILL.md DUAL MODE OVERLAY — `--rounds=N` valido para Dual (1-5) y MaxDual (3-8)

---
*v1.3 · 2026-04-27 · 43 casos · Fuente: Evaluación Kirkardo + sesión ULTRA v6.2 + Dual Mode v8.0.0*
