# [Nombre del Proyecto / Tema de Investigación]
Estado: ACTIVO
Iniciado: YYYY-MM-DD
Ultima actualizacion: YYYY-MM-DD
Tipo: PERSONAL | CARRERA

## Objetivo
[Qué quiero entender, demostrar o producir con esta investigación.]

## Pregunta Central
[La pregunta concreta que guía el trabajo.]

## Hipótesis Inicial
[Lo que creo que encontraré. Puede estar equivocado, eso está bien.]

## Fuentes Principales
- [Paper / libro / URL 1]: [por qué es relevante]
- [Paper / libro / URL 2]: [por qué es relevante]

## Metodología
[Cómo voy a investigar: lectura de papers, experimentos, síntesis, etc.]

## Herramientas
- Einstein: investigación y síntesis
- WebSearch / WebFetch: fuentes externas
- Bash sandbox: análisis de datos si aplica

## Estado Actual
Investigación inicializada. Sin conclusiones todavía.

## Hallazgos
[Se irá rellenando durante la investigación]

## Conclusiones Parciales
[Se irá rellenando]

## Proximos Pasos
- [ ] Búsqueda inicial de fuentes
- [ ] Síntesis de hallazgos principales
- [ ] Conclusión o entregable final

## Notas
[ideas sueltas, conexiones con otros proyectos]
