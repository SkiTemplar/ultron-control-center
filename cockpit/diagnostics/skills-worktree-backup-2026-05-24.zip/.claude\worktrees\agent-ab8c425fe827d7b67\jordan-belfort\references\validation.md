# Validación de Mercado — Jordan Belfort

## La Regla de Oro
> "No existe peor inversión que construir un producto perfecto que nadie quiere."

---

## Los 3 Niveles de Validación

### NIVEL 1: Validación del Problema (1-2 semanas, €0)
Objetivo: Confirmar que el dolor existe y es frecuente.

Script de entrevista (15 minutos):
1. "¿Cómo gestionas actualmente [el proceso X]?" → Escuchar, no interrumpir
2. "¿Cuánto tiempo te lleva eso a la semana?" → Cuantifica el dolor
3. "¿Qué es lo que más te frustra de ese proceso?" → Busca la emoción
4. "¿Has probado alguna herramienta para eso?" → Si sí: ¿por qué la dejaste?
5. "¿Cuánto te cuesta ese problema?" → Que el dueño lo cuantifique, no tú

Señales positivas: te interrumpe con más problemas, frustración real, "lo necesito desde hace años"
Señales de alerta: respuestas genéricas, no recuerda cuánto tiempo le lleva

### NIVEL 2: Validación de la Solución (2-4 semanas)
Objetivo: Confirmar que TU solución es la respuesta correcta.

Opción A — Landing page + lista de espera (€0, 2 días para montar)
Opción B — Mockups en Figma + entrevistas (€0, 1 semana diseño)
Opción C — Prototipo funcional mínimo (2-4 semanas de código mínimo)

Script para mostrar mockups:
1. "He estado trabajando en algo para [sector]. ¿Te importa verlo?"
2. Mostrar flujo principal sin explicar demasiado
3. "¿Qué es lo primero que se te pasa por la cabeza?"
4. "¿Resuelve el problema que me comentaste?"
5. "Si esto existiera hoy, ¿lo usarías? ¿Cuánto pagarías?"

### NIVEL 3: Validación de Mercado (4-8 semanas)
Objetivo: Dinero real sobre la mesa.

Conseguir 3-5 negocios que paguen (aunque sea 50% del precio final) o carta de intención firmada.

Script de cierre:
"Tenemos plazas limitadas para los primeros clientes a precio especial de lanzamiento.
Son €X/mes durante 12 meses garantizados. ¿Te apunto?"

---

## Matriz de Decisión Post-Validación

| Escenario | Acción |
|-----------|--------|
| N1+ N2+ 3 cartas de intención | ✅ Construir con Terry |
| N1+ N2+ 0 cartas de intención | ⚠️ Revisar pricing o ICP |
| N1+ N2 negativo | 🔄 Rediseñar solución |
| N1 negativo | ❌ Cambiar de nicho |

---

## Los 5 Errores Fatales de Validación

1. **Hablar solo con amigos/familia** → Tu madre siempre dice que es brillante. Habla con desconocidos reales.
2. **Preguntar "¿usarías esto?" en lugar de "¿comprarías esto?"** → Son preguntas completamente distintas.
3. **Mostrar el producto antes de entender el problema** → Primero el dolor, luego la solución.
4. **Construir durante la validación** → Mockups y conversaciones primero. Código al final.
5. **Ignorar señales negativas** → Si 5 dicen que no, escúchalos.
