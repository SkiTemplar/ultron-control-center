#!/usr/bin/env python3
"""
ULTRON v10.0 Cockpit - Activity tracker.

Detects which project Rodrigo is working on RIGHT NOW (foreground IDE window
or active git repo at cwd) and appends a snapshot to activity.jsonl.

Designed to run every ~10 minutes via Task Scheduler. Each entry:
    {"ts": "...", "project_id": "...", "ide": "...", "source": "window|cwd"}

Detection strategy (best-effort, always graceful):
1. Foreground window title via Windows API -> match against projects.json
2. Top processes (Rider, Webstorm, etc.) -> map to project they have open
3. Fallback: parse $PWD env / cwd of latest claude session

Used as input by 4.J' Schedule Learner: histogram of hour x day x project
predicts when Rodrigo typically works on each project.
"""
from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

sys.path.insert(0, str(Path(__file__).parent))
from cockpit_base import Cockpit, COCKPIT_DIR, ACTIVITY_JSONL, PROJECTS_JSON  # noqa: E402


# IDE process names -> friendly IDE label
IDE_PROCS = {
    "rider64.exe":          "Rider",
    "rider.exe":            "Rider",
    "webstorm64.exe":       "Webstorm",
    "webstorm.exe":         "Webstorm",
    "code.exe":             "VSCode",
    "code - insiders.exe":  "VSCode",
    "cursor.exe":           "Cursor",
    "studio64.exe":         "AndroidStudio",
    "devenv.exe":           "VisualStudio",
    "clion64.exe":          "CLion",
    "pycharm64.exe":        "PyCharm",
}


def load_projects() -> list[dict]:
    data = Cockpit.read_json(PROJECTS_JSON, default={"projects": []})
    return data.get("projects", [])


def get_foreground_window_title() -> str | None:
    """Best-effort: get the title of the foreground window via Windows API."""
    try:
        import ctypes
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return None
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return None
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        return buf.value
    except Exception:
        return None


def list_running_ides() -> list[tuple[str, str]]:
    """Returns list of (process_name, ide_label) for IDEs currently running."""
    found = []
    try:
        import subprocess
        result = subprocess.run(
            ["tasklist", "/FO", "CSV", "/NH"],
            capture_output=True, text=True, timeout=10,
        )
        for line in result.stdout.splitlines():
            # CSV: "name.exe","pid","sessionname","sessionnum","memory"
            if not line.startswith('"'):
                continue
            name = line.split('","')[0].lstrip('"').lower()
            if name in IDE_PROCS:
                found.append((name, IDE_PROCS[name]))
    except Exception:
        pass
    return found


def match_project_from_window_title(title: str, projects: list[dict]) -> dict | None:
    """If a project name appears in the window title, return that project."""
    if not title:
        return None
    title_lower = title.lower()
    # Sort by name length desc -> longer names match first (avoid "ia" matching "tortunabo")
    for proj in sorted(projects, key=lambda p: -len(p.get("name", ""))):
        name = proj.get("name", "").lower()
        if not name or len(name) < 3:
            continue
        if name in title_lower:
            return proj
    return None


def match_project_from_cwd(projects: list[dict]) -> dict | None:
    """If the current working directory is inside (or equal to) a project path, return it."""
    cwd = Path.cwd().resolve()
    best = None
    best_len = -1
    for proj in projects:
        try:
            ppath = Path(proj["path"]).resolve()
        except Exception:
            continue
        try:
            cwd.relative_to(ppath)
            # cwd is INSIDE the project. Prefer the longest match (deepest project root).
            if len(str(ppath)) > best_len:
                best = proj
                best_len = len(str(ppath))
        except ValueError:
            continue
    return best


def track(verbose: bool = False) -> dict | None:
    """Detect current activity and append to activity.jsonl. Returns the entry or None."""
    projects = load_projects()
    if not projects:
        if verbose:
            print("[track] No projects in registry, skipping")
        return None

    # 1. Try foreground window title
    title = get_foreground_window_title()
    proj = match_project_from_window_title(title or "", projects)
    source = "window"

    # 2. Fallback: cwd
    if not proj:
        proj = match_project_from_cwd(projects)
        source = "cwd"

    # 3. Detect any IDE running
    ides = list_running_ides()
    ide_label = None
    if proj:
        # Prefer the IDE the project expects, if it's running
        expected_ide = proj.get("ide")
        for _, label in ides:
            if label == expected_ide:
                ide_label = label
                break
        if not ide_label and ides:
            ide_label = ides[0][1]  # any running IDE

    if not proj:
        # v10.5: emit synthetic 'idle' entry instead of dropping. Without this,
        # activity.jsonl coverage was ~31% (gaps when foreground was browser/
        # game/terminal). Idle entries let the dashboard distinguish "PC was
        # off" from "PC was on but not on a tracked project".
        ide_running = ides[0][1] if ides else None
        entry = {
            "ts":           datetime.now().isoformat(timespec="seconds"),
            "project_id":   None,
            "project_name": None,
            "ide":          ide_running,
            "source":       "idle",
            "title_hint":   (title[:80] if title else None),
        }
        Cockpit.append_jsonl(ACTIVITY_JSONL, entry)
        if verbose:
            print(f"[track] idle entry. Title='{title}', CWD={os.getcwd()}, "
                  f"ide_running={ide_running}")
        return entry

    entry = {
        "ts":         datetime.now().isoformat(timespec="seconds"),
        "project_id": proj["id"],
        "project_name": proj["name"],
        "ide":        ide_label,
        "source":     source,
        "title_hint": (title[:80] if title else None),
    }
    Cockpit.append_jsonl(ACTIVITY_JSONL, entry)
    if verbose:
        print(f"[track] {entry['ts']} project={entry['project_id']} ide={ide_label} src={source}")
    return entry


def summary(days: int = 7) -> None:
    """Print top projects by activity count over the last N days."""
    if not ACTIVITY_JSONL.exists():
        print("[track] No activity log yet")
        return

    from collections import Counter
    from datetime import timedelta

    cutoff = datetime.now() - timedelta(days=days)
    counter: Counter = Counter()
    total = 0

    import json as _json
    for line in ACTIVITY_JSONL.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            entry = _json.loads(line)
            ts = datetime.fromisoformat(entry.get("ts", ""))
            if ts < cutoff:
                continue
            pid = entry.get("project_id")
            counter[pid if pid else "(idle)"] += 1
            total += 1
        except (ValueError, _json.JSONDecodeError):
            continue

    print(f"[track] Activity last {days} days: {total} samples")
    for pid, count in counter.most_common(10):
        bar = "#" * int(count * 30 / max(counter.values()))
        print(f"  {pid:<28} {count:>4}  {bar}")


def main():
    p = argparse.ArgumentParser(description="ULTRON Cockpit activity tracker")
    p.add_argument("--verbose", "-v", action="store_true")
    sub = p.add_subparsers(dest="cmd")
    snap = sub.add_parser("snapshot", help="Detect current activity and append to log (default)")
    snap.add_argument("--verbose", "-v", action="store_true", dest="verbose_sub")
    s = sub.add_parser("summary", help="Print top projects by activity")
    s.add_argument("--days", type=int, default=7)
    s.add_argument("--verbose", "-v", action="store_true", dest="verbose_sub")
    args = p.parse_args()
    # Merge: top-level OR subcommand-level verbose wins
    args.verbose = args.verbose or getattr(args, "verbose_sub", False)

    if args.cmd == "summary":
        summary(args.days)
        return 0

    # Default = snapshot
    entry = track(verbose=args.verbose)
    if not args.verbose:
        if entry:
            label = entry.get("project_id") or "(idle)"
            print(f"OK {label}")
        else:
            print("(no project detected)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
